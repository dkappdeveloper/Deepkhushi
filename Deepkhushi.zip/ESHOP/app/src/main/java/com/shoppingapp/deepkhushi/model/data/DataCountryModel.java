package com.shoppingapp.deepkhushi.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DataCountryModel implements Parcelable {

    public final static Creator<DataCountryModel> CREATOR = new Creator<DataCountryModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public DataCountryModel createFromParcel(Parcel in) {
            return new DataCountryModel(in);
        }

        public DataCountryModel[] newArray(int size) {
            return (new DataCountryModel[size]);
        }

    };
    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("states")
    @Expose
    private List<DataStateModel> dataStateModels = null;

    protected DataCountryModel(Parcel in) {
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        in.readList(this.dataStateModels, (DataStateModel.class.getClassLoader()));
    }

    /**
     * No args constructor for use in serialization
     */
    public DataCountryModel() {
    }

    /**
     * @param name
     * @param dataStateModels
     * @param code
     */
    public DataCountryModel(String code, String name, List<DataStateModel> dataStateModels) {
        super();
        this.code = code;
        this.name = name;
        this.dataStateModels = dataStateModels;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<DataStateModel> getDataStateModels() {
        return dataStateModels;
    }

    public void setDataStateModels(List<DataStateModel> dataStateModels) {
        this.dataStateModels = dataStateModels;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(code);
        dest.writeValue(name);
        dest.writeList(dataStateModels);
    }

    public int describeContents() {
        return 0;
    }

}
