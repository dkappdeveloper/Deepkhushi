package com.shoppingapp.deepkhushi.cache.constant;

/**
 * Created by Deepak Kumar on 20-Jan-19.
 */

public class AppConstants {

    /* Constant Value */
    public static final String EMPTY_STRING = "";
    public static final String DEFAULT_PASSWORD = "wpwc";
    public static final String US_CURRENCY = "$";
    public static final String PERCENTAGE_SYMBOLE = "%";
    public static final String VARIATION_FEATURED = "featured";
    public static final String VARIATION_CATEGORY = "category";


    /* Network Codes */
    public static final int EMPTY_RESULT = 600;
    public static final int BAD_REQUEST = 400;


    /* Request Codes */
    public static final int FB_REQUEST_CODE = 101;
    public static final int GP_REQUEST_CODE = 102;
    public static final int PAYPAL_REQUEST_CODE = 103;
    public static final int STRIPE_REQUEST_CODE = 104;
    public static final int PAYMENT_REQUEST_CODE = 105;


    /* Response Codes */
    public static final int RESPONSE_SUCCESS = 200;
    public static final int RESPONSE_UNAUTHORIZED = 401;
    public static final int RESPONSE_TRANSACTION = 2019;


    /* Paypal Request Type*/
    public static final String REQUEST_PAYPAL_TOKEN = "token";
    public static final String REQUEST_PAYPAL_PAYMENT = "payment";


    // date time format
    public static final String DATE_FORMAT_ISO8601 = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATE_FORMAT_DMY_SHORT = "dd/MM/yyyy";
    public static final String DATE_FORMAT_DMY_MEDIUM = "dd MMM, yyyy";
    public static final String DATE_FORMAT_YMD_SHORT = "yyyy-MM-dd";
    public static final String DATE_FORMAT_DMY_LONG = "dd/MM/yyyy HH:mm:ss";
    public static final String DATE_FORMAT_YMD_LONG = "yyyy-MM-dd HH:mm:ss";
    public static final int DEFAULT_DAYS_BEFORE = 30;


    // Search key
    public static final int PAGE_NUMBER = 1;
    public static final int PER_PAGE = 10;
    public static final int MAX_PER_PAGE = 20;
    public static final int CATEGORY_PER_PAGE = 99;
    public static final String SEARCH_KEY = "searchKey";
    public static final String KEY_TITLE = "title";
    public static final String KEY_DATE = "date";
    public static final String KEY_PRICE = "price";
    public static final String KEY_ASC = "asc";
    public static final String KEY_DESC = "desc";


    // bundle key
    public static final String BUNDLE_PAGE_TITLE = "page_title";
    public static final String BUNDLE_SEARCH_PRODUCT = "search_product";
    public static final String BUNDLE_VARIATION_TYPE = "variation_type";
    public static final String BUNDLE_PRODUCT_ID = "product_id";
    public static final String BUNDLE_CATEGORY_ID = "category_id";
    public static final String BUNDLE_PRODUCT_DETAIL = "product_detail";
    public static final String BUNDLE_ORDER_DETAIL = "order_detail";
    public static final String BUNDLE_ORDER_NOTES = "order_notes";
    public static final String BUNDLE_FROM_CONFIRM_ORDER = "from_confirm_order";
    public static final String BUNDLE_BILLING_ADDRESS = "billing_address";
    public static final String BUNDLE_SHIPPING_ADDRESS = "shipping_address";
    public static final String BUNDLE_CHECKOUT_LOGIN = "checkout_login";
    public static final String BUNDLE_UPDATE_ADDRESS = "update_address";
    public static final String BUNDLE_CHECKOUT_PRODUCTS = "checkout_products";
    public static final String BUNDLE_PAYMENT_TOTAL = "payment_total";
    public static final String BUNDLE_SHIPPING_ZONE = "shipping_zone";
    public static final String BUNDLE_BUY_NOW = "buy_now";
    public static final String BUNDLE_HOME_LOGIN = "home_login";
    public static final String BUNDLE_WEB_URL = "web_url";
    public static final String BUNDLE_FROM_NOTIFICATION = "from_notification";
    public static final String BUNDLE_NOTIFICATION_DETAIL = "notification_detail";
    public static final String BUNDLE_STRIPE_TOKEN = "stripe_token";
    public static final String BUNDLE_COUPON_LIST = "coupon_list";
    public static final String BUNDLE_PAYMENT_METHOD = "payment_method";
    public static final String BUNDLE_PAYMENT_METHOD_TITLE = "payment_method_title";
    public static final String BUNDLE_PAYMENT_CONFIRMED = "payment_confirmed";
    public static final String BUNDLE_TRANSACTION_ID = "transaction_id";


    // Notification type
    public static final String NOTIFICATION_MESSAGE = "notification_message";
    public static final String NOTIFICATION_PRODUCT = "notification_product";
    public static final String NOTIFICATION_URL = "notification_url";


    public enum ListLayoutType {
        GRID,
        LINEAR
    }

    public enum OrientationTypeShow {
        VERTICAL,
        HORIZONTAL
    }


    /* Checkout location flag code */
    public static final int CHECKOUT_ADDRESS_BILLING = 821;
    public static final int CHECKOUT_ADDRESS_SHIPPING = 822;


    public static final String PRODUCT_TYPE_SIMPLE = "simple";
    public static final String PRODUCT_TYPE_VARIABLE = "variable";


    public static final String PAYMENT_METHOD_BANK = "bacs";
    public static final String PAYMENT_METHOD_CHECK = "cheque";
    public static final String PAYMENT_METHOD_CASH = "cod";
    public static final String PAYMENT_METHOD_PAYPAL = "paypal";
    public static final String PAYMENT_METHOD_STRIPE = "stripe";
    public static final String PAYMENT_METHOD_RAZORPAY = "razorpay";


    public static final String ORDER_STATUS_PENDING = "pending";
    public static final String ORDER_STATUS_PROCESSING = "processing";
    public static final String ORDER_STATUS_ONHOLD = "on-hold";
    public static final String ORDER_STATUS_COMPLETED = "completed";
    public static final String ORDER_STATUS_CANCELLED = "cancelled";
    public static final String ORDER_STATUS_REFUNDED = "refunded";
    public static final String ORDER_STATUS_FAILED = "failed";


    public static final String COUPON_TYPE_PERCENT = "percent";
    public static final String COUPON_TYPE_FIXED_CART = "fixed_cart";
    public static final String COUPON_TYPE_FIXED_PRODUCT = "fixed_product";


    public static final String SHIPPING_TYPE_CONTINENT = "continent";
    public static final String SHIPPING_TYPE_COUNTRY = "country";
    public static final String SHIPPING_TYPE_STATE = "state";


    public static final String SHIPPING_METHOD_FLAT_RATE = "flat_rate";
    public static final String SHIPPING_METHOD_FREE_SHIPPING = "free_shipping";
    public static final String SHIPPING_METHOD_LOCAL_PICKUP = "local_pickup";


    public static final int SLIDER_DURATION = 5 * 1000;  //Increase value 5 to upper to slow down slider & decrease to faster slider load

    public static final String CSS_PROPERTIES = "<style>body{width:100%;margin:0;}img {max-width:100%;height:auto;} iframe{width:100%;height:auto;}</style>";
}
