package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.AttributeFilterAdapter;
import com.shoppingapp.deepkhushi.adapter.recycler.ProductListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.PrimaryFilterableListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.FilterItemClickCallbackListener;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductAttributeModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.shoppingapp.deepkhushi.model.product.ProductSearchModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.android.material.appbar.AppBarLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 09-Feb-19.
 */
public class ProductListActivity extends BaseActivity {

    PrimaryFilterableListLayoutBinding binding;

    AttributeFilterAdapter attributeFilterAdapter;
    ProductListAdapter productListAdapter;

    private List<ProductAttributeModel> attributeList;
    private List<ProductModel> productList;
    private ArrayAdapter<String> listOrderAdapter;
    private List<String> listOrder;
    private ProductSearchModel searchModel;

    private String pageTitle;
    private int pageNumber = AppConstants.PAGE_NUMBER;
    private Boolean listOrderSpinnerTouched = false;
    private Boolean isDataLoading = false;
    private Boolean canLoadMore = false;
    private Boolean viewLoadingFirstTime = true;
    private AppConstants.ListLayoutType currentLayoutType;

    private GridLayoutManager gridLayoutManager;
    private LinearLayoutManager linearLayoutManager;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        loadProductAttributes();
        loadProducts(AppConstants.PAGE_NUMBER);
    }

    @Override
    protected void onResume() {
        super.onResume();

        updateToolbarCartCount(binding.primaryToolbar.cartCounter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (this.binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
            this.binding.drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            finish();
        }
    }

    private void initVars() {
        //tempAttributeList = new ArrayList<>();
        attributeList = new ArrayList<>();
        productList = new ArrayList<>();
        searchModel = new ProductSearchModel();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            if (bundle.containsKey(AppConstants.BUNDLE_PAGE_TITLE))
                pageTitle = bundle.getString(AppConstants.BUNDLE_PAGE_TITLE);

            if (bundle.containsKey(AppConstants.BUNDLE_SEARCH_PRODUCT))
                searchModel = bundle.getParcelable(AppConstants.BUNDLE_SEARCH_PRODUCT);
        }
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.primary_filterable_list_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, AppHelper.fromHtml(pageTitle));
        binding.filterTitle.setText(pageTitle);

        initRecyclerView(AppConstants.ListLayoutType.GRID);
        initFilterSpinner();
        intFilterView(false);
        initRecyclerView();
    }

    private void initListener() {
        binding.primaryFilterbar.toggleListLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleListLayout();
            }
        });

        binding.primaryFilterbar.filterList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.drawerLayout.openDrawer(GravityCompat.END);
            }
        });

        binding.doneFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.drawerLayout.closeDrawer(GravityCompat.END);
            }
        });

        binding.resetFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (ProductAttributeModel attributeModel : attributeList)
                    for (ProductAttributeModel termModel : attributeModel.getAttributeTerms())
                        termModel.setSelected(false);
                attributeFilterAdapter.notifyDataSetChanged();

                searchModel.setAttribute(null);
                searchModel.setAttributeTerm(null);
                loadProductData();
            }
        });

        binding.primaryFilterbar.listOrderSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    listOrderSpinnerTouched = true;
                }
                return false;
            }
        });

        binding.primaryFilterbar.listOrderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (listOrderSpinnerTouched) {
                    setListOrderSpinnerSelection(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        attributeFilterAdapter.setFilterItemClickListener(new FilterItemClickCallbackListener() {
            @Override
            public void onFilterItemClickGetCallback(String termId, String attributeSlug) {
                searchModel.setAttribute(attributeSlug);
                searchModel.setAttributeTerm(termId);
                loadProductData();
            }
        });

        binding.primaryToolbar.toolbarMenuCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ProductListActivity.this, ProductCartActivity.class));
            }
        });

        binding.primaryToolbar.toolbarMenuSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ProductListActivity.this, SearchProductActivity.class));
            }
        });
    }

    private void initRecyclerView() {
        attributeFilterAdapter = new AttributeFilterAdapter(getApplicationContext(), attributeList);
        binding.attributeRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        binding.attributeRecyclerView.setNestedScrollingEnabled(false);
        binding.attributeRecyclerView.setAdapter(attributeFilterAdapter);
    }

    private void loadProductAttributes() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            ApiClient.getInstance().getApiInterface().getProductAttributes().enqueue(new Callback<List<ProductAttributeModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductAttributeModel>> call, @NonNull Response<List<ProductAttributeModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            attributeList.addAll(response.body());

                            if (attributeList != null && attributeList.size() > 0) {
                                for (int i = 0; i < attributeList.size(); i++) {
                                    loadAttributeTerms(attributeList.get(i).getId(), i);
                                }
                            }
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.server_failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductAttributeModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadAttributeTerms(Integer id, final Integer position) {

        ApiClient.getInstance().getApiInterface().getProductAttributesTerms(id).enqueue(new Callback<List<ProductAttributeModel>>() {
            @Override
            public void onResponse(@NonNull Call<List<ProductAttributeModel>> call, @NonNull Response<List<ProductAttributeModel>> response) {
                if (response.isSuccessful()) {
                    if (response.body() != null && response.body().size() > 0) {
                        ProductAttributeModel attributeModel = attributeList.get(position);
                        attributeModel.setAttributeTerms(response.body());
                    }
                    attributeFilterAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<ProductAttributeModel>> call, @NonNull Throwable t) {
            }
        });
    }

    private void loadProductData() {
        productList.clear();
        toggleShimmerLayout(false);
        binding.primaryRecycler.setVisibility(View.GONE);

        if (!isDataLoading) {
            isDataLoading = true;
            pageNumber = AppConstants.PAGE_NUMBER;
            loadProducts(pageNumber);
        }
    }

    private void loadProducts(int pageNumber) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            if (binding.emptyListLayout.getVisibility() == View.VISIBLE)
                binding.emptyListLayout.setVisibility(View.GONE);

            searchModel.setPage(pageNumber);
            searchModel.setPerPage(AppConstants.PER_PAGE);
            HashMap<String, String> featuredProduct = ApiRequests.buildProductList(searchModel);

            ApiClient.getInstance().getApiInterface().getProducts(featuredProduct).enqueue(new Callback<List<ProductModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductModel>> call, @NonNull Response<List<ProductModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            if (response.body().size() > 0) {
                                canLoadMore = true;

                                productList.addAll(response.body());
                                productListAdapter.notifyDataSetChanged();
                                toggleShimmerLayout(true);
                                binding.primaryRecycler.setVisibility(View.VISIBLE);

                                if (viewLoadingFirstTime) {
                                    viewLoadingFirstTime = false;
                                    intFilterView(true);
                                }
                            } else {
                                if (productList.size() == 0) {
                                    binding.emptyListLayout.removeAllViews();
                                    binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.no_data)));
                                    toggleShimmerLayout(true);
                                    binding.emptyListLayout.setVisibility(View.VISIBLE);
                                }
                                canLoadMore = false;
                            }

                            isDataLoading = false;
                            binding.progressBar.setVisibility(View.GONE);
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void intFilterView(Boolean showFilterLayout) {
        AppBarLayout.LayoutParams params = (AppBarLayout.LayoutParams) binding.primaryToolbar.toolbar.getLayoutParams();
        CoordinatorLayout.LayoutParams appBarLayoutParams = (CoordinatorLayout.LayoutParams) binding.appbarLayout.getLayoutParams();

        if (showFilterLayout) {
            params.setScrollFlags(AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL | AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS);
            appBarLayoutParams.setBehavior(new AppBarLayout.Behavior());
            binding.primaryFilterbar.filterListLayout.setVisibility(View.VISIBLE);
        } else {
            appBarLayoutParams.setBehavior(null);
            params.setScrollFlags(0);
            binding.primaryFilterbar.filterListLayout.setVisibility(View.GONE);
        }

        binding.appbarLayout.setLayoutParams(appBarLayoutParams);
    }

    private void initFilterSpinner() {
        listOrder = Arrays.asList(getResources().getStringArray(R.array.list_order_type));
        listOrderAdapter = spinnerAdapter(new ArrayList<String>(listOrder));
        binding.primaryFilterbar.listOrderSpinner.setPopupBackgroundResource(R.drawable.spinner_background);
        binding.primaryFilterbar.listOrderSpinner.setAdapter(listOrderAdapter);
    }

    private void initRecyclerView(AppConstants.ListLayoutType layoutManagerType) {
        productListAdapter = new ProductListAdapter(getApplicationContext(), productList, layoutManagerType);
        setRecyclerViewLayoutManager(binding.primaryRecycler, layoutManagerType);
        binding.primaryRecycler.setItemAnimator(new DefaultItemAnimator());
        binding.primaryRecycler.setNestedScrollingEnabled(false);
        binding.primaryRecycler.setAdapter(productListAdapter);
        binding.nestedScrollView.setOnScrollChangeListener(onNestedScrollChange());

        productListAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = productList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(ProductListActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });
    }

    private void setListOrderSpinnerSelection(int position) {

        switch (position) {
            case 0:
                searchModel.setOrder(AppConstants.KEY_ASC);
                searchModel.setOrderBy(AppConstants.KEY_DATE);
                break;
            case 1:
                searchModel.setOrder(AppConstants.KEY_ASC);
                searchModel.setOrderBy(AppConstants.KEY_TITLE);
                break;
            case 2:
                searchModel.setOrder(AppConstants.KEY_DESC);
                searchModel.setOrderBy(AppConstants.KEY_TITLE);
                break;
            case 3:
                searchModel.setOrder(AppConstants.KEY_ASC);
                searchModel.setOrderBy(AppConstants.KEY_PRICE);
                break;
            case 4:
                searchModel.setOrder(AppConstants.KEY_DESC);
                searchModel.setOrderBy(AppConstants.KEY_PRICE);
                break;
        }
        loadProductData();
    }

    public void setRecyclerViewLayoutManager(RecyclerView mRecyclerView, AppConstants.ListLayoutType layoutManagerType) {
        int scrollPosition = 0;

        if (mRecyclerView.getLayoutManager() != null) {
            scrollPosition = ((LinearLayoutManager) mRecyclerView.getLayoutManager())
                    .findFirstCompletelyVisibleItemPosition();
        }

        switch (layoutManagerType) {
            case GRID:
                gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
                mLayoutManager = gridLayoutManager;
                currentLayoutType = AppConstants.ListLayoutType.GRID;
                break;
            case LINEAR:
                linearLayoutManager = new LinearLayoutManager(getApplicationContext());
                mLayoutManager = linearLayoutManager;
                currentLayoutType = AppConstants.ListLayoutType.LINEAR;
                break;
            default:
                linearLayoutManager = new LinearLayoutManager(getApplicationContext());
                mLayoutManager = linearLayoutManager;
                currentLayoutType = AppConstants.ListLayoutType.LINEAR;
        }

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.scrollToPosition(scrollPosition);
    }

    private void toggleShimmerLayout(Boolean hide) {
        if (currentLayoutType == AppConstants.ListLayoutType.LINEAR) {
            if (hide)
                binding.listShimmerLayout.shimmerLinearLayout.setVisibility(View.GONE);
            else
                binding.listShimmerLayout.shimmerLinearLayout.setVisibility(View.VISIBLE);
        } else {
            if (hide)
                binding.gridShimmerLayout.shimmerGridLayout.setVisibility(View.GONE);
            else
                binding.gridShimmerLayout.shimmerGridLayout.setVisibility(View.VISIBLE);
        }
    }

    private void toggleListLayout() {
        if (currentLayoutType == AppConstants.ListLayoutType.LINEAR) {
            binding.primaryFilterbar.toggleListLayout.setImageResource(R.drawable.ic_list_menu);
            setRecyclerViewLayoutManager(binding.primaryRecycler, AppConstants.ListLayoutType.GRID);
            initRecyclerView(AppConstants.ListLayoutType.GRID);

        } else {
            binding.primaryFilterbar.toggleListLayout.setImageResource(R.drawable.ic_grid_menu);
            setRecyclerViewLayoutManager(binding.primaryRecycler, AppConstants.ListLayoutType.LINEAR);
            initRecyclerView(AppConstants.ListLayoutType.LINEAR);
        }
    }

    public ArrayAdapter<String> spinnerAdapter(ArrayList<String> arrayList) {
        return new ArrayAdapter<String>(this, R.layout.spinner_item_layout, arrayList) {
            @Override
            public boolean isEnabled(int position) {
                return position != -1;
            }

            @Override
            public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(getResources().getColor(R.color.colorBlack));

                return view;
            }
        };
    }

    private NestedScrollView.OnScrollChangeListener onNestedScrollChange() {
        return new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView scrollView, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY > 0) {
                    if (!scrollView.canScrollVertically(NestedScrollView.FOCUS_DOWN)) {
                        if (canLoadMore && !isDataLoading) {
                            isDataLoading = true;
                            binding.progressBar.setVisibility(View.VISIBLE);
                            pageNumber += 1;
                            loadProducts(pageNumber);
                        }
                    }
                }
            }
        };
    }
}
