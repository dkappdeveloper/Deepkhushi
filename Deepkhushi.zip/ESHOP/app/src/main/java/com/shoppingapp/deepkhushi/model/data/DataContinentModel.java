package com.shoppingapp.deepkhushi.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DataContinentModel implements Parcelable {

    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("countries")
    @Expose
    private List<DataCountryModel> countries = null;
    public final static Creator<DataContinentModel> CREATOR = new Creator<DataContinentModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public DataContinentModel createFromParcel(Parcel in) {
            return new DataContinentModel(in);
        }

        public DataContinentModel[] newArray(int size) {
            return (new DataContinentModel[size]);
        }

    };

    protected DataContinentModel(Parcel in) {
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        in.readList(this.countries, (DataCountryModel.class.getClassLoader()));
    }

    /**
     * No args constructor for use in serialization
     */
    public DataContinentModel() {
    }

    /**
     * @param code
     * @param name
     * @param countries
     */
    public DataContinentModel(String code, String name, List<DataCountryModel> countries) {
        super();
        this.code = code;
        this.name = name;
        this.countries = countries;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<DataCountryModel> getCountries() {
        return countries;
    }

    public void setCountries(List<DataCountryModel> countries) {
        this.countries = countries;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(code);
        dest.writeValue(name);
        dest.writeList(countries);
    }

    public int describeContents() {
        return 0;
    }

}
