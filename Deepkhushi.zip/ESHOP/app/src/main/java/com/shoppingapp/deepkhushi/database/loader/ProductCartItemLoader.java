package com.shoppingapp.deepkhushi.database.loader;

import android.content.Context;
import android.os.AsyncTask;

import com.shoppingapp.deepkhushi.database.helpers.AppDb;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class ProductCartItemLoader extends AsyncTask<Object, Void, Object> {

    private DbLoaderInterface dbLoaderInterface;
    private WeakReference<Context> weakContext;

    public ProductCartItemLoader(Context context) {
        weakContext = new WeakReference<>(context);
    }

    public void setDbLoaderInterface(DbLoaderInterface dbLoaderInterface) {
        this.dbLoaderInterface = dbLoaderInterface;
    }

    @Override
    protected Object doInBackground(Object... object) {
        Context context = weakContext.get();
        int query = (int) object[0];

        if (query == DaoHelper.INSERT) {
            ProductCartModel insertModel = (ProductCartModel) object[1];
            AppDb.getAppDb(context).getProductCartDao().insert(insertModel);
        } else if (query == DaoHelper.FETCH) {
            return AppDb.getAppDb(context).getProductCartDao().getProduct((int) object[1]);
        } else if (query == DaoHelper.FETCH_ALL) {
            return AppDb.getAppDb(context).getProductCartDao().getAll();
        } else if (query == DaoHelper.INSERT_ALL) {
            ArrayList<ProductCartModel> productCartModels = (ArrayList<ProductCartModel>) object[1];
            AppDb.getAppDb(context).getProductCartDao().insertAll(productCartModels);
        } else if (query == DaoHelper.UPDATE) {
            ProductCartModel updateModel = (ProductCartModel) object[1];
            AppDb.getAppDb(context).getProductCartDao().updateCartProduct(updateModel.getProductQuantity(), updateModel.getTotalPrice(), updateModel.getProductId());
        } else if (query == DaoHelper.DELETE) {
            AppDb.getAppDb(context).getProductCartDao().deleteCartProduct((int) object[1]);
        } else if (query == DaoHelper.DELETE_ALL) {
            AppDb.getAppDb(context).getProductCartDao().deleteAllCartItems();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);

        if (dbLoaderInterface != null) {
            dbLoaderInterface.onFinished(o);
        }
    }
}
