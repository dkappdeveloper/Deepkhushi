package com.shoppingapp.deepkhushi.app;

import android.app.Application;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.listener.NetworkChangeListener;
import com.shoppingapp.deepkhushi.notification.NotificationRecieverService;
import com.google.firebase.messaging.FirebaseMessaging;
import com.onesignal.OneSignal;


/**
 * Created by Deepak Kumar on 11/7/2016.
 */

public class BaseApplication extends Application {

    public static NetworkChangeListener networkChangeListener;
    private static BaseApplication baseApplication;

    @Override
    public void onCreate() {
        super.onCreate();
        baseApplication = this;

        if (AppPreference.getInstance(getApplicationContext()).isNotificationOn()) {
            FirebaseMessaging.getInstance().subscribeToTopic(getString(R.string.push_notification_topic));
            OneSignal.startInit(this)
                    .setNotificationOpenedHandler(new NotificationRecieverService())
                    .setNotificationReceivedHandler(new NotificationRecieverService())
                    .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                    .init();
        } else {
            FirebaseMessaging.getInstance().unsubscribeFromTopic(getString(R.string.push_notification_topic));
            OneSignal.setSubscription(false);
        }
    }

    public static synchronized BaseApplication getInstance() {
        return baseApplication;
    }

    public void setNetworkChangedListener(NetworkChangeListener listener) {
        networkChangeListener = listener;
    }
}
