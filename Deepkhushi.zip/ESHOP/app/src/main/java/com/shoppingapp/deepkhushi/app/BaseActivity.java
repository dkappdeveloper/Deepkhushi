package com.shoppingapp.deepkhushi.app;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.customview.RotateProgressDialog;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.NotificationItemLoader;
import com.shoppingapp.deepkhushi.database.loader.ProductCartItemLoader;
import com.shoppingapp.deepkhushi.databinding.EmptyListPrimaryLayoutBinding;
import com.shoppingapp.deepkhushi.helper.ADHelper;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.NotificationModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 22/12/2018.
 */

public abstract class BaseActivity extends SocialSigninActivity {

    public Context context;
    public RotateProgressDialog progressDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setAppLocality();
        context = getApplicationContext();
        progressDialog = new RotateProgressDialog(this);

     /*   ADHelper.getInstance(this).disableBannerAd();
        ADHelper.getInstance(this).disableInterstitialAd();*/
    }

    @Override
    protected void onResume() {
        super.onResume();

        ADHelper.getInstance(getApplicationContext()).loadFullScreenAd(this);
    }

    public void setToolbar(Toolbar toolbar, TextView titleView, CharSequence title) {
        toolbar.setTitleTextColor(Color.BLACK);
        toolbar.setSubtitleTextColor(Color.BLACK);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setTitle(title);
        titleView.setText(title);
    }

    public void updateToolbarCartCount(final TextView textView) {
        ProductCartItemLoader cartItemLoader = new ProductCartItemLoader(this);
        cartItemLoader.execute(DaoHelper.FETCH_ALL);
        cartItemLoader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {
                    List<ProductCartModel> modelList = (List<ProductCartModel>) object;

                    if (modelList.size() > 0) {
                        textView.setText(String.valueOf(modelList.size()));
                        textView.setVisibility(View.VISIBLE);
                    } else {
                        textView.setVisibility(View.GONE);
                    }
                }
            }
        });
    }

    public void updateToolbarNotificationCount(final TextView textView) {
        NotificationItemLoader notificationItemLoader = new NotificationItemLoader(this);
        notificationItemLoader.execute(DaoHelper.FETCH_UNSEEN);
        notificationItemLoader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {
                    List<NotificationModel> modelList = (List<NotificationModel>) object;

                    if (modelList.size() > 0) {
                        textView.setText(String.valueOf(modelList.size()));
                        textView.setVisibility(View.VISIBLE);
                    } else {
                        textView.setVisibility(View.GONE);
                    }
                }
            }
        });
    }

    public void sharePost(ProductModel productModel) {
        String productName = productModel.getName();
        String productUrl = productModel.getPermalink();

        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);

        sharingIntent.putExtra(Intent.EXTRA_TEXT, productName + "\n\nLink : " + productUrl);
        sharingIntent.setType("text/plain");

        startActivity(Intent.createChooser(sharingIntent, "Sharing via"));
    }

    public static View setEmptyLayout(Context context, String message) {
        EmptyListPrimaryLayoutBinding layoutBinding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.empty_list_primary_layout, null, false);
        layoutBinding.warningMessage.setText(message);
        return layoutBinding.getRoot();
    }

    public void setAppLocality() {
        int languageValue = AppPreference.getInstance(this).getInteger(getResources().getString(R.string.pref_language));
        String languageCode = getResources().getStringArray(R.array.app_locality)[languageValue];

        AppHelper.setAppLanguage(this, languageCode);
    }
}
