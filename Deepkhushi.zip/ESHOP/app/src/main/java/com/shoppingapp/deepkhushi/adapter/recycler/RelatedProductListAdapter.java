package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemRelatedProductListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductImageModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 30-Mar-19.
 */
public class RelatedProductListAdapter extends RecyclerView.Adapter<RelatedProductListAdapter.RelatedProductListViewHolder> {

    private Context context;
    private List<ProductModel> arrayList;

    private ItemClickListener itemClickListener;

    public RelatedProductListAdapter(Context context) {
        this.context = context;
    }

    public RelatedProductListAdapter(Context context, List<ProductModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public RelatedProductListAdapter.RelatedProductListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new RelatedProductListViewHolder((ItemRelatedProductListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_related_product_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RelatedProductListAdapter.RelatedProductListViewHolder holder, int position) {
        List<ProductImageModel> imageModel = arrayList.get(position).getProductImageModels();
        String type = arrayList.get(position).getType();
        String title = arrayList.get(position).getName();
        String basePrice = arrayList.get(position).getPrice();
        String salePrice = arrayList.get(position).getSalePrice();
        String regularPrice = arrayList.get(position).getRegularPrice();
        String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);

        if (imageModel.size() > 0) {
            String productImage = imageModel.get(0).getSrc();
            Picasso.get().load(productImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(holder.binding.productImage);
        }

        holder.binding.productTitle.setText(AppHelper.fromHtml(title));

        if (type.equals(AppConstants.PRODUCT_TYPE_VARIABLE)) {
            holder.binding.productSalePrice.setText(currencySymbol + basePrice);
            holder.binding.productRegularPrice.setVisibility(View.GONE);
        } else if (type.equals(AppConstants.PRODUCT_TYPE_SIMPLE)) {
            if (salePrice != null && !salePrice.isEmpty()) {
                holder.binding.productSalePrice.setText(currencySymbol + salePrice);
                holder.binding.productRegularPrice.setText(currencySymbol + regularPrice);
                holder.binding.productRegularPrice.setVisibility(View.VISIBLE);
            } else {
                holder.binding.productSalePrice.setText(currencySymbol + regularPrice);
                holder.binding.productRegularPrice.setVisibility(View.GONE);
            }
        }

        if (arrayList.get(position).getOnSale())
            holder.binding.productSaleBadge.setVisibility(View.VISIBLE);
        else
            holder.binding.productSaleBadge.setVisibility(View.GONE);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class RelatedProductListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemRelatedProductListLayoutBinding binding;

        RelatedProductListViewHolder(@NonNull ItemRelatedProductListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
