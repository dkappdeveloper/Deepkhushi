package com.shoppingapp.deepkhushi.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.ReviewListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ActivityProductReviewsLayoutBinding;
import com.shoppingapp.deepkhushi.databinding.DialogProductReviewLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.model.product.ProductReviewModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 03-Jul-19.
 */
public class ProductReviewActivity extends BaseActivity {

    ActivityProductReviewsLayoutBinding binding;
    DialogProductReviewLayoutBinding reviewLayoutBinding;

    Dialog reviewDialog;

    ReviewListAdapter reviewListAdapter;
    private List<ProductReviewModel> reviewModels;

    private int productId = 0;
    private int pageNumber = AppConstants.PAGE_NUMBER;
    private Boolean isDataLoading = false;
    private Boolean canLoadMore = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        initRecyclerView();
        loadPostComments(AppConstants.PAGE_NUMBER);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {
        reviewModels = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();

        if (bundle.containsKey(AppConstants.BUNDLE_PRODUCT_ID))
            productId = bundle.getInt(AppConstants.BUNDLE_PRODUCT_ID);
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_product_reviews_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_reviews));
    }

    private void initListener() {
        binding.fabWriteReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadReviewDialog();
            }
        });
    }

    private void initRecyclerView() {
        reviewListAdapter = new ReviewListAdapter(this, reviewModels);
        binding.primaryRecycler.setLayoutManager(new LinearLayoutManager(this));
        binding.primaryRecycler.setItemAnimator(new DefaultItemAnimator());
        binding.primaryRecycler.setNestedScrollingEnabled(false);
        binding.primaryRecycler.setAdapter(reviewListAdapter);
        binding.nestedscrollView.setOnScrollChangeListener(onNestedScrollChange());
    }

    private void loadPostComments(int pageNumber) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            if (pageNumber == AppConstants.PAGE_NUMBER) {
                binding.fabWriteReview.setVisibility(View.GONE);
                binding.primaryRecycler.setVisibility(View.GONE);
                binding.emptyListLayout.setVisibility(View.GONE);
                binding.reviewShimmerView.shimmerView.setVisibility(View.VISIBLE);
                reviewModels.clear();
            }

            HashMap<String, String> postCommentsMap = ApiRequests.buildProductReviewList(productId, pageNumber);
            ApiClient.getInstance().getApiInterface().getProductReviews(postCommentsMap).enqueue(new Callback<List<ProductReviewModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductReviewModel>> call, @NonNull Response<List<ProductReviewModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            if (response.body().size() > 0) {
                                canLoadMore = true;

                                reviewModels.addAll(response.body());
                                reviewListAdapter.notifyDataSetChanged();
                                binding.primaryRecycler.setVisibility(View.VISIBLE);
                                binding.reviewShimmerView.shimmerView.setVisibility(View.GONE);
                            } else {
                                if (reviewModels.size() == 0) {
                                    binding.emptyListLayout.removeAllViews();
                                    binding.emptyListLayout.addView(setEmptyLayout(context, getString(R.string.no_review)));
                                    binding.emptyListLayout.setVisibility(View.VISIBLE);
                                    binding.reviewShimmerView.shimmerView.setVisibility(View.GONE);
                                    binding.primaryRecycler.setVisibility(View.GONE);
                                }
                                canLoadMore = false;
                            }
                            isDataLoading = false;
                            binding.progressBar.setVisibility(View.GONE);
                            binding.fabWriteReview.setVisibility(View.VISIBLE);
                        }
                    } else {
                        if (response.code() == AppConstants.EMPTY_RESULT) {
                            canLoadMore = false;
                            binding.progressBar.setVisibility(View.GONE);
                        } else {
                            AppHelper.showShortToast(context, getString(R.string.failed_msg));
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductReviewModel>> call, @NonNull Throwable t) {
                    binding.reviewShimmerView.shimmerView.setVisibility(View.GONE);
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private NestedScrollView.OnScrollChangeListener onNestedScrollChange() {
        return new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView scrollView, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY > 0) {
                    if (!scrollView.canScrollVertically(NestedScrollView.FOCUS_DOWN)) {
                        if (canLoadMore && !isDataLoading) {
                            isDataLoading = true;
                            binding.progressBar.setVisibility(View.VISIBLE);
                            pageNumber += 1;
                            loadPostComments(pageNumber);
                        }
                    }
                }
            }
        };
    }

    private void loadReviewDialog() {
        reviewDialog = new Dialog(this);
        reviewDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        reviewLayoutBinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.dialog_product_review_layout, null, false);
        reviewDialog.setContentView(reviewLayoutBinding.getRoot());
        reviewDialog.setCanceledOnTouchOutside(true);

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(reviewDialog.getWindow().getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -2;
        reviewDialog.getWindow().setAttributes(layoutParams);

        String prefFirstName = AppPreference.getInstance(getApplicationContext()).getString(PrefKey.FIRST_NAME);
        String prefLastName = AppPreference.getInstance(getApplicationContext()).getString(PrefKey.LAST_NAME);
        String prefEmail = AppPreference.getInstance(getApplicationContext()).getString(PrefKey.EMAIL);

        reviewLayoutBinding.reviewerName.setText(prefFirstName + prefLastName);
        reviewLayoutBinding.reviewerEmail.setText(prefEmail);

        reviewLayoutBinding.submitReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String reviewerName = reviewLayoutBinding.reviewerName.getText().toString().trim();
                String reviewerEmail = reviewLayoutBinding.reviewerEmail.getText().toString().trim();
                String reviewContent = reviewLayoutBinding.reviewContent.getText().toString().trim();
                String reviewRating = String.valueOf(reviewLayoutBinding.reviewRating.getRating());

                if (reviewerName.isEmpty() && reviewerName.length() == 0) {
                    reviewLayoutBinding.reviewerName.setError(getString(R.string.full_name_empty_msg));
                    reviewLayoutBinding.reviewerName.requestFocus();
                } else if (reviewerEmail.isEmpty() && reviewerEmail.length() == 0) {
                    reviewLayoutBinding.reviewerEmail.setError(getString(R.string.email_address_empty_msg));
                    reviewLayoutBinding.reviewerEmail.requestFocus();
                } else if (reviewRating.equals("0.0")) {
                    AppHelper.showShortToast(ProductReviewActivity.this, getString(R.string.rating_value_empty_msg));
                } else if (reviewContent.isEmpty() && reviewContent.length() == 0) {
                    reviewLayoutBinding.reviewContent.setError(getString(R.string.review_content_empty_msg));
                    reviewLayoutBinding.reviewContent.requestFocus();
                } else {
                    saveReview(reviewerName, reviewerEmail, reviewContent, reviewRating);
                }
            }
        });

        reviewLayoutBinding.cancelReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reviewDialog.dismiss();
            }
        });

        reviewDialog.show();
    }

    private void saveReview(String reviewer, String email, String review, String rating) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            HashMap<String, String> newReviewMap = ApiRequests.buildProductReview(productId, reviewer, email, rating, review);
            ApiClient.getInstance().getApiInterface().createProductReview(newReviewMap).enqueue(new Callback<ProductReviewModel>() {
                @Override
                public void onResponse(@NonNull Call<ProductReviewModel> call, @NonNull Response<ProductReviewModel> response) {
                    if (response.isSuccessful()) {
                        loadPostComments(AppConstants.PAGE_NUMBER);
                        AppHelper.showShortToast(ProductReviewActivity.this, getString(R.string.review_success_msg));
                    } else {
                        AppHelper.showShortToast(ProductReviewActivity.this, getString(R.string.failed_msg));
                    }
                    progressDialog.dismiss();
                    reviewDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<ProductReviewModel> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    reviewDialog.dismiss();
                    AppHelper.showShortToast(ProductReviewActivity.this, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }
}
