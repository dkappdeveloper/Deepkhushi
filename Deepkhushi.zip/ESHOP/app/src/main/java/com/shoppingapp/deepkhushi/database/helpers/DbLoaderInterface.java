package com.shoppingapp.deepkhushi.database.helpers;

public interface DbLoaderInterface {
    void onFinished(Object object);
}
