package com.shoppingapp.deepkhushi.listener;

/**
 * Created by Deepak Kumar on 06-May-19.
 */
public interface CheckoutLocationSelectedListener {
    void onCheckoutLocationSelected(int position, int addressType);
}
