package com.shoppingapp.deepkhushi.model.shipping;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ShippingLocationModel implements Parcelable {

    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("type")
    @Expose
    private String type;
    public final static Creator<ShippingLocationModel> CREATOR = new Creator<ShippingLocationModel>() {

        @SuppressWarnings({
                "unchecked"
        })
        public ShippingLocationModel createFromParcel(Parcel in) {
            return new ShippingLocationModel(in);
        }

        public ShippingLocationModel[] newArray(int size) {
            return (new ShippingLocationModel[size]);
        }

    };

    protected ShippingLocationModel(Parcel in) {
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.type = ((String) in.readValue((String.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     */
    public ShippingLocationModel() {
    }

    /**
     * @param code
     * @param type
     */
    public ShippingLocationModel(String code, String type) {
        super();
        this.code = code;
        this.type = type;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(code);
        dest.writeValue(type);
    }

    public int describeContents() {
        return 0;
    }

}
