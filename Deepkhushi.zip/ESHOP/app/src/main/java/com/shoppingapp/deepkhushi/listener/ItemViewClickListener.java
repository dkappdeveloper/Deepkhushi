package com.shoppingapp.deepkhushi.listener;

import android.view.View;

/**
 * Created by Deepak Kumar on 14-May-19.
 */
public interface ItemViewClickListener {
    void onItemViewClickGetPosition(int position, View view);
}
