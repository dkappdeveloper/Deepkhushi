
package com.shoppingapp.deepkhushi.model.order;

import java.util.ArrayList;
import java.util.List;
import android.os.Parcel;
import android.os.Parcelable;

import com.shoppingapp.deepkhushi.model.customer.BillingModel;
import com.shoppingapp.deepkhushi.model.customer.ShippingModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("parent_id")
    @Expose
    private Integer parentId;
    @SerializedName("number")
    @Expose
    private String number;
    @SerializedName("order_key")
    @Expose
    private String orderKey;
    @SerializedName("created_via")
    @Expose
    private String createdVia;
    @SerializedName("version")
    @Expose
    private String version;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("date_created")
    @Expose
    private String dateCreated;
    @SerializedName("date_created_gmt")
    @Expose
    private String dateCreatedGmt;
    @SerializedName("date_modified")
    @Expose
    private String dateModified;
    @SerializedName("date_modified_gmt")
    @Expose
    private String dateModifiedGmt;
    @SerializedName("discount_total")
    @Expose
    private String discountTotal;
    @SerializedName("discount_tax")
    @Expose
    private String discountTax;
    @SerializedName("shipping_total")
    @Expose
    private String shippingTotal;
    @SerializedName("shipping_tax")
    @Expose
    private String shippingTax;
    @SerializedName("cart_tax")
    @Expose
    private String cartTax;
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("total_tax")
    @Expose
    private String totalTax;
    @SerializedName("prices_include_tax")
    @Expose
    private Boolean pricesIncludeTax;
    @SerializedName("customer_id")
    @Expose
    private Integer customerId;
    @SerializedName("customer_ip_address")
    @Expose
    private String customerIpAddress;
    @SerializedName("customer_user_agent")
    @Expose
    private String customerUserAgent;
    @SerializedName("customer_note")
    @Expose
    private String customerNote;
    @SerializedName("billing")
    @Expose
    private BillingModel billingModel;
    @SerializedName("shipping")
    @Expose
    private ShippingModel shippingModel;
    @SerializedName("payment_method")
    @Expose
    private String paymentMethod;
    @SerializedName("payment_method_title")
    @Expose
    private String paymentMethodTitle;
    @SerializedName("transaction_id")
    @Expose
    private String transactionId;
    @SerializedName("date_paid")
    @Expose
    private String datePaid;
    @SerializedName("date_paid_gmt")
    @Expose
    private String datePaidGmt;
    @SerializedName("date_completed")
    @Expose
    private String dateCompleted;
    @SerializedName("date_completed_gmt")
    @Expose
    private String dateCompletedGmt;
    @SerializedName("cart_hash")
    @Expose
    private String cartHash;
    @SerializedName("line_items")
    @Expose
    private List<LineItemModel> lineItemModels = new ArrayList<>();

    public final static Creator<OrderModel> CREATOR = new Creator<OrderModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public OrderModel createFromParcel(Parcel in) {
            return new OrderModel(in);
        }

        public OrderModel[] newArray(int size) {
            return (new OrderModel[size]);
        }

    }
    ;

    protected OrderModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.parentId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.number = ((String) in.readValue((String.class.getClassLoader())));
        this.orderKey = ((String) in.readValue((String.class.getClassLoader())));
        this.createdVia = ((String) in.readValue((String.class.getClassLoader())));
        this.version = ((String) in.readValue((String.class.getClassLoader())));
        this.status = ((String) in.readValue((String.class.getClassLoader())));
        this.currency = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCreated = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCreatedGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.dateModified = ((String) in.readValue((String.class.getClassLoader())));
        this.dateModifiedGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.discountTotal = ((String) in.readValue((String.class.getClassLoader())));
        this.discountTax = ((String) in.readValue((String.class.getClassLoader())));
        this.shippingTotal = ((String) in.readValue((String.class.getClassLoader())));
        this.shippingTax = ((String) in.readValue((String.class.getClassLoader())));
        this.cartTax = ((String) in.readValue((String.class.getClassLoader())));
        this.total = ((String) in.readValue((String.class.getClassLoader())));
        this.totalTax = ((String) in.readValue((String.class.getClassLoader())));
        this.pricesIncludeTax = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        this.customerId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.customerIpAddress = ((String) in.readValue((String.class.getClassLoader())));
        this.customerUserAgent = ((String) in.readValue((String.class.getClassLoader())));
        this.customerNote = ((String) in.readValue((String.class.getClassLoader())));
        this.billingModel = ((BillingModel) in.readValue((BillingModel.class.getClassLoader())));
        this.shippingModel = ((ShippingModel) in.readValue((ShippingModel.class.getClassLoader())));
        this.paymentMethod = ((String) in.readValue((String.class.getClassLoader())));
        this.paymentMethodTitle = ((String) in.readValue((String.class.getClassLoader())));
        this.transactionId = ((String) in.readValue((String.class.getClassLoader())));
        this.datePaid = ((String) in.readValue((String.class.getClassLoader())));
        this.datePaidGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCompleted = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCompletedGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.cartHash = ((String) in.readValue((String.class.getClassLoader())));
        in.readList(this.lineItemModels, (LineItemModel.class.getClassLoader()));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public OrderModel() {
    }

    /**
     * 
     * @param total
     * @param customerUserAgent
     * @param dateModified
     * @param transactionId
     * @param datePaid
     * @param currency
     * @param version
     * @param id
     * @param shippingModel
     * @param parentId
     * @param dateModifiedGmt
     * @param customerId
     * @param shippingTax
     * @param lineItemModels
     * @param dateCreatedGmt
     * @param discountTax
     * @param status
     * @param number
     * @param paymentMethodTitle
     * @param customerIpAddress
     * @param dateCompleted
     * @param datePaidGmt
     * @param billingModel
     * @param pricesIncludeTax
     * @param customerNote
     * @param cartTax
     * @param dateCompletedGmt
     * @param cartHash
     * @param createdVia
     * @param discountTotal
     * @param dateCreated
     * @param shippingTotal
     * @param orderKey
     * @param totalTax
     * @param paymentMethod
     */
    public OrderModel(Integer id, Integer parentId, String number, String orderKey, String createdVia, String version, String status, String currency, String dateCreated, String dateCreatedGmt, String dateModified, String dateModifiedGmt, String discountTotal, String discountTax, String shippingTotal, String shippingTax, String cartTax, String total, String totalTax, Boolean pricesIncludeTax, Integer customerId, String customerIpAddress, String customerUserAgent, String customerNote, BillingModel billingModel, ShippingModel shippingModel, String paymentMethod, String paymentMethodTitle, String transactionId, String datePaid, String datePaidGmt, String dateCompleted, String dateCompletedGmt, String cartHash,  List<LineItemModel> lineItemModels) {
        super();
        this.id = id;
        this.parentId = parentId;
        this.number = number;
        this.orderKey = orderKey;
        this.createdVia = createdVia;
        this.version = version;
        this.status = status;
        this.currency = currency;
        this.dateCreated = dateCreated;
        this.dateCreatedGmt = dateCreatedGmt;
        this.dateModified = dateModified;
        this.dateModifiedGmt = dateModifiedGmt;
        this.discountTotal = discountTotal;
        this.discountTax = discountTax;
        this.shippingTotal = shippingTotal;
        this.shippingTax = shippingTax;
        this.cartTax = cartTax;
        this.total = total;
        this.totalTax = totalTax;
        this.pricesIncludeTax = pricesIncludeTax;
        this.customerId = customerId;
        this.customerIpAddress = customerIpAddress;
        this.customerUserAgent = customerUserAgent;
        this.customerNote = customerNote;
        this.billingModel = billingModel;
        this.shippingModel = shippingModel;
        this.paymentMethod = paymentMethod;
        this.paymentMethodTitle = paymentMethodTitle;
        this.transactionId = transactionId;
        this.datePaid = datePaid;
        this.datePaidGmt = datePaidGmt;
        this.dateCompleted = dateCompleted;
        this.dateCompletedGmt = dateCompletedGmt;
        this.cartHash = cartHash;
        this.lineItemModels = lineItemModels;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getOrderKey() {
        return orderKey;
    }

    public void setOrderKey(String orderKey) {
        this.orderKey = orderKey;
    }

    public String getCreatedVia() {
        return createdVia;
    }

    public void setCreatedVia(String createdVia) {
        this.createdVia = createdVia;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getDateCreatedGmt() {
        return dateCreatedGmt;
    }

    public void setDateCreatedGmt(String dateCreatedGmt) {
        this.dateCreatedGmt = dateCreatedGmt;
    }

    public String getDateModified() {
        return dateModified;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public String getDateModifiedGmt() {
        return dateModifiedGmt;
    }

    public void setDateModifiedGmt(String dateModifiedGmt) {
        this.dateModifiedGmt = dateModifiedGmt;
    }

    public String getDiscountTotal() {
        return discountTotal;
    }

    public void setDiscountTotal(String discountTotal) {
        this.discountTotal = discountTotal;
    }

    public String getDiscountTax() {
        return discountTax;
    }

    public void setDiscountTax(String discountTax) {
        this.discountTax = discountTax;
    }

    public String getShippingTotal() {
        return shippingTotal;
    }

    public void setShippingTotal(String shippingTotal) {
        this.shippingTotal = shippingTotal;
    }

    public String getShippingTax() {
        return shippingTax;
    }

    public void setShippingTax(String shippingTax) {
        this.shippingTax = shippingTax;
    }

    public String getCartTax() {
        return cartTax;
    }

    public void setCartTax(String cartTax) {
        this.cartTax = cartTax;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(String totalTax) {
        this.totalTax = totalTax;
    }

    public Boolean getPricesIncludeTax() {
        return pricesIncludeTax;
    }

    public void setPricesIncludeTax(Boolean pricesIncludeTax) {
        this.pricesIncludeTax = pricesIncludeTax;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getCustomerIpAddress() {
        return customerIpAddress;
    }

    public void setCustomerIpAddress(String customerIpAddress) {
        this.customerIpAddress = customerIpAddress;
    }

    public String getCustomerUserAgent() {
        return customerUserAgent;
    }

    public void setCustomerUserAgent(String customerUserAgent) {
        this.customerUserAgent = customerUserAgent;
    }

    public String getCustomerNote() {
        return customerNote;
    }

    public void setCustomerNote(String customerNote) {
        this.customerNote = customerNote;
    }

    public BillingModel getBilling() {
        return billingModel;
    }

    public void setBilling(BillingModel billingModel) {
        this.billingModel = billingModel;
    }

    public ShippingModel getShipping() {
        return shippingModel;
    }

    public void setShipping(ShippingModel shippingModel) {
        this.shippingModel = shippingModel;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentMethodTitle() {
        return paymentMethodTitle;
    }

    public void setPaymentMethodTitle(String paymentMethodTitle) {
        this.paymentMethodTitle = paymentMethodTitle;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getDatePaid() {
        return datePaid;
    }

    public void setDatePaid(String datePaid) {
        this.datePaid = datePaid;
    }

    public String getDatePaidGmt() {
        return datePaidGmt;
    }

    public void setDatePaidGmt(String datePaidGmt) {
        this.datePaidGmt = datePaidGmt;
    }

    public String getDateCompleted() {
        return dateCompleted;
    }

    public void setDateCompleted(String dateCompleted) {
        this.dateCompleted = dateCompleted;
    }

    public String getDateCompletedGmt() {
        return dateCompletedGmt;
    }

    public void setDateCompletedGmt(String dateCompletedGmt) {
        this.dateCompletedGmt = dateCompletedGmt;
    }

    public String getCartHash() {
        return cartHash;
    }

    public void setCartHash(String cartHash) {
        this.cartHash = cartHash;
    }

    public List<LineItemModel> getLineItemModels() {
        return lineItemModels;
    }

    public void setLineItemModels(List<LineItemModel> lineItemModels) {
        this.lineItemModels = lineItemModels;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(parentId);
        dest.writeValue(number);
        dest.writeValue(orderKey);
        dest.writeValue(createdVia);
        dest.writeValue(version);
        dest.writeValue(status);
        dest.writeValue(currency);
        dest.writeValue(dateCreated);
        dest.writeValue(dateCreatedGmt);
        dest.writeValue(dateModified);
        dest.writeValue(dateModifiedGmt);
        dest.writeValue(discountTotal);
        dest.writeValue(discountTax);
        dest.writeValue(shippingTotal);
        dest.writeValue(shippingTax);
        dest.writeValue(cartTax);
        dest.writeValue(total);
        dest.writeValue(totalTax);
        dest.writeValue(pricesIncludeTax);
        dest.writeValue(customerId);
        dest.writeValue(customerIpAddress);
        dest.writeValue(customerUserAgent);
        dest.writeValue(customerNote);
        dest.writeValue(billingModel);
        dest.writeValue(shippingModel);
        dest.writeValue(paymentMethod);
        dest.writeValue(paymentMethodTitle);
        dest.writeValue(transactionId);
        dest.writeValue(datePaid);
        dest.writeValue(datePaidGmt);
        dest.writeValue(dateCompleted);
        dest.writeValue(dateCompletedGmt);
        dest.writeValue(cartHash);
        dest.writeList(lineItemModels);
    }

    public int describeContents() {
        return  0;
    }

}
