package com.shoppingapp.deepkhushi.database.helpers;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.shoppingapp.deepkhushi.database.dao.FavouritesDao;
import com.shoppingapp.deepkhushi.database.dao.LocationDao;
import com.shoppingapp.deepkhushi.database.dao.NotificationDao;
import com.shoppingapp.deepkhushi.database.dao.ProductCartDao;
import com.shoppingapp.deepkhushi.model.dbEntity.FavouritesModel;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;
import com.shoppingapp.deepkhushi.model.dbEntity.NotificationModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;


@Database(entities = {
        FavouritesModel.class,
        ProductCartModel.class,
        NotificationModel.class,
        LocationModel.class
}, version = 2, exportSchema = false)

public abstract class DaoHelper extends RoomDatabase {


    /* Databse Name*/
    static final String DATABASE_NAME = "wp-commerce";


    /* Table Name*/
    public static final String FAVOURITE_PRODUCT_TBL = "favourite_products_tbl";
    public static final String PRODUCT_CART_TBL = "product_cart_tbl";
    public static final String NOTIFICATION_TBL = "notification_tbl";
    public static final String LOCATION_TBL = "location_tbl";


    /* Column Name*/
    public static final String COLUMN_AUTO_ID = "auto_id";
    public static final String COLUMN_PRODUCT_ID = "product_id";
    public static final String COLUMN_CATEGORY_ID = "category_id";
    public static final String COLUMN_PRODUCT_NAME = "product_name";
    public static final String COLUMN_SALE_PRICE = "sale_price";
    public static final String COLUMN_REGULAR_PRICE = "regular_price";
    public static final String COLUMN_PRODUCT_PRICE = "product_price";
    public static final String COLUMN_TOTAL_PRICE = "total_price";
    public static final String COLUMN_PRODUCT_IMAGE = "product_image";
    public static final String COLUMN_IS_SALE = "is_sale";
    public static final String COLUMN_PRODUCT_QUANTITY = "product_quantity";
    public static final String COLUMN_PRODUCT_ATTRIBUTE = "product_attribute";


    public static final String COLUMN_NOTIFICATION_TITLE = "notification_title";
    public static final String COLUMN_NOTIFICATION_MESSAGE = "notification_message";
    public static final String COLUMN_NOTIFICATION_IMAGE = "notification_image";
    public static final String COLUMN_NOTIFICATION_URL = "notification_url";
    public static final String COLUMN_NOTIFICATION_PRODUCT = "notification_product";
    public static final String COLUMN_NOTIFICATION_TYPE = "notification_type";
    public static final String COLUMN_NOTIFICATION_SEEN = "notification_seen";


    public static final String COLUMN_CONTINENT_CODE = "continent_code";
    public static final String COLUMN_CONTINENT_NAME = "continent_name";
    public static final String COLUMN_COUNTRY_CODE = "country_code";
    public static final String COLUMN_COUNTRY_NAME = "country_name";
    public static final String COLUMN_STATE_CODE = "state_code";
    public static final String COLUMN_STATE_NAME = "state_name";


    // Query
    public static final int INSERT = 1, FETCH = 2, UPDATE = 3, DELETE = 4,
            SEARCH_KEY = 5, INSERT_ALL = 6, FETCH_ALL = 7, UPDATE_ALL = 8,
            DELETE_ALL = 9, FETCH_UNSEEN = 10, ROW_COUNT = 11,
            FETCH_CONTINENT = 12, FETCH_COUNTRY = 13, FETCH_STATE = 14;


    public abstract ProductCartDao getProductCartDao();

    public abstract FavouritesDao getFavouritesDao();

    public abstract NotificationDao getNotificationDao();

    public abstract LocationDao getLocationDao();
}
