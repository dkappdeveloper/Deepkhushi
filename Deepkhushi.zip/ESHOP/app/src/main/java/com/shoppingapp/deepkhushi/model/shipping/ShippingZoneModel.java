
package com.shoppingapp.deepkhushi.model.shipping;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ShippingZoneModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;

    private List<ShippingLocationModel> locationList = new ArrayList<>();

    public ShippingZoneModel() {
    }

    public ShippingZoneModel(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public ShippingZoneModel(Integer id, String name, List<ShippingLocationModel> locationList) {
        this.id = id;
        this.name = name;
        this.locationList = locationList;
    }

    protected ShippingZoneModel(Parcel in) {
        if (in.readByte() == 0) {
            id = null;
        } else {
            id = in.readInt();
        }
        name = in.readString();
        locationList = in.createTypedArrayList(ShippingLocationModel.CREATOR);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (id == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(id);
        }
        dest.writeString(name);
        dest.writeTypedList(locationList);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ShippingZoneModel> CREATOR = new Creator<ShippingZoneModel>() {
        @Override
        public ShippingZoneModel createFromParcel(Parcel in) {
            return new ShippingZoneModel(in);
        }

        @Override
        public ShippingZoneModel[] newArray(int size) {
            return new ShippingZoneModel[size];
        }
    };

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ShippingLocationModel> getLocationList() {
        return locationList;
    }

    public void setLocationList(List<ShippingLocationModel> locationList) {
        this.locationList = locationList;
    }
}
