package com.shoppingapp.deepkhushi.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.CheckoutProductListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.loader.ProductCartItemLoader;
import com.shoppingapp.deepkhushi.databinding.ActivityPlaceOrderLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DataMapingHelper;
import com.shoppingapp.deepkhushi.helper.DateHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.model.order.OrderModel;
import com.shoppingapp.deepkhushi.model.product.ProductCouponModel;
import com.shoppingapp.deepkhushi.model.shipping.ShippingMethodModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.gson.JsonObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 11-May-19.
 */

public class PlaceOrderActivity extends BaseActivity {

    ActivityPlaceOrderLayoutBinding binding;

    CheckoutProductListAdapter productListAdapter;

    private List<HashMap> orderNotes;
    private List<ProductCartModel> orderList;
    private List<ProductCouponModel> couponList;
    private List<ShippingMethodModel> shippingMethodList;
    private HashMap<String, String> billingAddress, shippingAddress;

    private Boolean buyNow = false;
    private Boolean paymentConfirm = false;

    private String totalAmount, netTotalAmount;
    private String transactionId = "";
    private String paymentMethod, paymentTitle;
    private int shippingZone;

    private String currencySymbol;
    private ProductCouponModel couponModel;
    private ShippingMethodModel methodModel;
    private double subTotal = 0.0, totalDiscount = 0.0;
    private double shippingCost = 0.0;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();

        loadOrderView();
        loadCoupons();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        switch (requestCode) {
            case AppConstants.PAYMENT_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        paymentMethod = intent.getStringExtra(AppConstants.BUNDLE_PAYMENT_METHOD);
                        paymentTitle = intent.getStringExtra(AppConstants.BUNDLE_PAYMENT_METHOD_TITLE);
                        transactionId = intent.getStringExtra(AppConstants.BUNDLE_TRANSACTION_ID);
                        paymentConfirm = intent.getBooleanExtra(AppConstants.BUNDLE_PAYMENT_CONFIRMED, false);

                        if (!transactionId.isEmpty())
                            orderNotes.add(DataMapingHelper.getHashMap(paymentTitle, "TransactionId: " + transactionId));

                        placeOrder();
                        break;
                    case Activity.RESULT_CANCELED:
                        AppHelper.showShortToast(PlaceOrderActivity.this, getString(R.string.cancelled_msg));
                        break;
                }
                break;
        }
    }

    private void initVars() {
        couponList = new ArrayList<>();
        shippingMethodList = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            if (bundle.containsKey(AppConstants.BUNDLE_ORDER_NOTES))
                orderNotes = (List<HashMap>) bundle.getSerializable(AppConstants.BUNDLE_ORDER_NOTES);

            if (bundle.containsKey(AppConstants.BUNDLE_CHECKOUT_PRODUCTS))
                orderList = (List<ProductCartModel>) bundle.getSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS);

            if (bundle.containsKey(AppConstants.BUNDLE_BILLING_ADDRESS))
                billingAddress = (HashMap<String, String>) bundle.getSerializable(AppConstants.BUNDLE_BILLING_ADDRESS);

            if (bundle.containsKey(AppConstants.BUNDLE_SHIPPING_ADDRESS))
                shippingAddress = (HashMap<String, String>) bundle.getSerializable(AppConstants.BUNDLE_SHIPPING_ADDRESS);

            if (bundle.containsKey(AppConstants.BUNDLE_BUY_NOW))
                buyNow = bundle.getBoolean(AppConstants.BUNDLE_BUY_NOW);

            if (bundle.containsKey(AppConstants.BUNDLE_PAYMENT_TOTAL)) {
                netTotalAmount = totalAmount = bundle.getString(AppConstants.BUNDLE_PAYMENT_TOTAL);
            }

            if (bundle.containsKey(AppConstants.BUNDLE_SHIPPING_ZONE))
                shippingZone = bundle.getInt(AppConstants.BUNDLE_SHIPPING_ZONE);
        }

        currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_place_order_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_checkout));
    }

    private void initListener() {
        binding.makeOrderPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (shippingMethodList.size() > 0) {
                    if (methodModel != null) {
                        loadPaymentGateway();
                    } else {
                        AppHelper.showLongToast(getApplicationContext(), getString(R.string.choose_shipping));
                    }
                } else {
                    loadPaymentGateway();
                }
            }
        });

        binding.seeCoupons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(AppConstants.BUNDLE_COUPON_LIST, (Serializable) couponList);
                startActivity(new Intent(PlaceOrderActivity.this, CouponsActivity.class).putExtras(bundle));
            }
        });

        binding.applyCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyCoupon();
            }
        });

        binding.shippingMethods.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                subTotal = Double.parseDouble(totalAmount);

                if (shippingMethodList.get(checkedId).getMethodId().equals(AppConstants.SHIPPING_METHOD_FREE_SHIPPING)) {
                    double minAmount = Double.parseDouble(shippingMethodList.get(checkedId).getSettings().getMinAmount().getValue());
                    if (minAmount <= Double.parseDouble(totalAmount)) {
                        methodModel = shippingMethodList.get(checkedId);
                        double shippingTotal = subTotal - totalDiscount;

                        binding.shippingPrice.setText(getString(R.string.free));
                        binding.paymentTotalPrice.setText(currencySymbol + String.format("%.2f", shippingTotal));
                        binding.shippingTotalLayout.setVisibility(View.VISIBLE);
                    } else {
                        AppHelper.showLongToast(PlaceOrderActivity.this, getString(R.string.min_amount) + " " + currencySymbol + minAmount);
                    }
                } else if (shippingMethodList.get(checkedId).getSettings().getCost() != null) {
                    methodModel = shippingMethodList.get(checkedId);
                    shippingCost = Double.parseDouble(methodModel.getSettings().getCost().getValue());
                    double shippingTotal = subTotal + shippingCost - totalDiscount;
                    netTotalAmount = String.valueOf(shippingTotal);

                    binding.shippingPrice.setText("+" + currencySymbol + String.format("%.2f", shippingCost));
                    binding.shippingTotalLayout.setVisibility(View.VISIBLE);
                    binding.paymentTotalPrice.setText(currencySymbol + String.format("%.2f", shippingTotal));
                }
            }
        });
    }

    private void loadOrderView() {
        String billFirstName = billingAddress.get(DataMapingHelper.KEY_FIRST_NAME);
        String billLastName = billingAddress.get(DataMapingHelper.KEY_LAST_NAME);
        String billEmail = billingAddress.get(DataMapingHelper.KEY_EMAIL);
        String billPhone = billingAddress.get(DataMapingHelper.KEY_PHONE);
        String billAddress = billingAddress.get(DataMapingHelper.KEY_ADDRESS);
        String billCity = billingAddress.get(DataMapingHelper.KEY_CITY);
        String billState = billingAddress.get(DataMapingHelper.KEY_STATE_NAME);
        String billCountry = billingAddress.get(DataMapingHelper.KEY_COUNTRY_NAME);
        String billPostCode = billingAddress.get(DataMapingHelper.KEY_POST_CODE);

        binding.billingFullname.setText(AppHelper.fromHtml(getString(R.string.order_full_name) + billFirstName + ", " + billLastName));
        binding.billingPhone.setText(AppHelper.fromHtml(getString(R.string.order_phone) + billPhone));
        binding.billingEmail.setText(AppHelper.fromHtml(getString(R.string.order_email) + billEmail));
        binding.billingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + billState + ", " + billCountry));
        binding.billingPostalAddress.setText(AppHelper.fromHtml(getString(R.string.order_address) + billAddress + ", " + billCity + ", " + billPostCode));


        String shipFirstName = shippingAddress.get(DataMapingHelper.KEY_FIRST_NAME);
        String shipLastName = shippingAddress.get(DataMapingHelper.KEY_LAST_NAME);
        String shipAddress = shippingAddress.get(DataMapingHelper.KEY_ADDRESS);
        String shipCity = shippingAddress.get(DataMapingHelper.KEY_CITY);
        String shipState = shippingAddress.get(DataMapingHelper.KEY_STATE_NAME);
        String shipCountry = shippingAddress.get(DataMapingHelper.KEY_COUNTRY_NAME);
        String shipPostCode = shippingAddress.get(DataMapingHelper.KEY_POST_CODE);

        binding.shippingFullname.setText(AppHelper.fromHtml(getString(R.string.order_full_name) + shipFirstName + ", " + shipLastName));
        binding.shippingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + shipState + ", " + shipCountry));
        binding.shippingPostalAddress.setText(AppHelper.fromHtml(getString(R.string.order_address) + shipAddress + ", " + shipCity + ", " + shipPostCode));

        Double total = Double.parseDouble(netTotalAmount);

        binding.checkoutTotal.setText("Total: " + currencySymbol + String.format("%.2f", total));
        binding.productSubtotalPrice.setText(currencySymbol + String.format("%.2f", total));
        binding.paymentTotalPrice.setText(currencySymbol + String.format("%.2f", total));

        productListAdapter = new CheckoutProductListAdapter(this, orderList);
        binding.checkoutProducts.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        binding.checkoutProducts.setNestedScrollingEnabled(false);
        binding.checkoutProducts.setAdapter(productListAdapter);
    }

    private void loadCoupons() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();

            ApiClient.getInstance().getApiInterface().getCoupons().enqueue(new Callback<List<ProductCouponModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductCouponModel>> call, @NonNull Response<List<ProductCouponModel>> response) {
                    if (response.isSuccessful()) {
                        couponList.clear();
                        couponList.addAll(response.body());

                        if (couponList != null & couponList.size() > 0) {
                            binding.couponLayout.setVisibility(View.VISIBLE);
                        } else {
                            binding.couponLayout.setVisibility(View.GONE);
                        }

                        if (shippingZone >= 0) {
                            loadShippingMethods();
                        } else {
                            progressDialog.dismiss();
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductCouponModel>> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(PlaceOrderActivity.this, getString(R.string.failed_msg));
                }
            });
        }
    }

    private void loadShippingMethods() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            //progressDialog.show();
            ApiClient.getInstance().getApiInterface().getShippingZoneMethods(shippingZone).enqueue(new Callback<List<ShippingMethodModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ShippingMethodModel>> call, @NonNull Response<List<ShippingMethodModel>> response) {
                    if (response.body() != null) {
                        List<ShippingMethodModel> modelList = new ArrayList<>(response.body());

                        if (modelList.size() > 0) {
                            List<String> shippingMethods = Arrays.asList(getResources().getStringArray(R.array.shipping_methods));
                            shippingMethodList.clear();

                            for (ShippingMethodModel model : modelList) {
                                if (shippingMethods.contains(model.getMethodId())) {
                                    shippingMethodList.add(model);
                                }
                            }

                            for (int i = 0; i < shippingMethodList.size(); i++) {
                                String optionText = "";
                                if (shippingMethodList.get(i).getMethodId().equals(AppConstants.SHIPPING_METHOD_FREE_SHIPPING)) {
                                    optionText = shippingMethodList.get(i).getTitle();

                                } else if (shippingMethodList.get(i).getSettings().getCost() != null) {
                                    optionText = shippingMethodList.get(i).getTitle() + " (" + currencySymbol + shippingMethodList.get(i).getSettings().getCost().getValue() + ")";
                                }

                                RadioButton rbn = new RadioButton(PlaceOrderActivity.this);
                                rbn.setId(i);
                                rbn.setText(optionText);
                                binding.shippingMethods.addView(rbn);
                            }

                            binding.shippingMethodLayout.setVisibility(View.VISIBLE);
                        } else {
                            binding.shippingMethodLayout.setVisibility(View.GONE);
                        }
                    } else {
                        AppHelper.showShortToast(PlaceOrderActivity.this, getString(R.string.failed_msg));
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<List<ShippingMethodModel>> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(PlaceOrderActivity.this, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void applyCoupon() {
        String coupon = binding.couponCode.getText().toString().trim();

        if (!coupon.isEmpty()) {
            if (hasCoupon(coupon)) {
                couponModel = getCouponModel(coupon);

                if (couponModel != null && couponModel.getId() > 0) {
                    Double couponAmount = Double.valueOf(couponModel.getAmount());
                    Double minOrderAmount = Double.valueOf(couponModel.getMinimumAmount());
                    Double maxOrderAmount = Double.valueOf(couponModel.getMaximumAmount());
                    String type = couponModel.getDiscountType();
                    Boolean freeShipping = couponModel.getFreeShipping();
                    Boolean excludeSale = couponModel.getExcludeSaleItems();
                    String expiredDate = couponModel.getDateExpires();

                    List<Integer> productIdList = couponModel.getProductIds();
                    List<Integer> excludedProductIdList = couponModel.getExcludedProductIds();
                    List<Integer> categoryIdList = couponModel.getProductCategories();
                    List<Integer> excludedCategoryIdList = couponModel.getExcludedProductCategories();

                    Double totalAmount = 0.00, discountAbleAmount = 0.00, discountAmount = 0.00;
                    int totalQuantity = 0;
                    List<ProductCartModel> checkoutList = new ArrayList<ProductCartModel>(orderList);
                    String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);

                    if (expiredDate != null && DateHelper.isCouponExpired(expiredDate, true)) {
                        AppHelper.showShortToast(this, getString(R.string.msg_date_expired));
                    } else if (minOrderAmount > 0.0 && minOrderAmount > couponAmount) {
                        AppHelper.showShortToast(this, getString(R.string.msg_min_amount_coupon) + " " + currencySymbol + minOrderAmount);
                    } else if (maxOrderAmount > 0.0 && maxOrderAmount < couponAmount) {
                        AppHelper.showShortToast(this, getString(R.string.msg_max_amount_coupon) + " " + currencySymbol + maxOrderAmount);
                    } else {

                        for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                            if (model.getSale() && excludeSale) {
                                checkoutList.remove(model);
                            }
                        }

                        if (excludedProductIdList.size() > 0 || excludedCategoryIdList.size() > 0) {
                            if (excludedProductIdList.size() > 0) {
                                for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                    if (excludedProductIdList.contains(model.getProductId())) {
                                        checkoutList.remove(model);
                                    }
                                }
                            }

                            if (excludedCategoryIdList.size() > 0) {
                                for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                    for (int i = 0; i < model.getCategoryIds().size(); i++) {
                                        if (excludedCategoryIdList.contains(model.getCategoryIds().get(i))) {
                                            checkoutList.remove(model);
                                        }
                                    }
                                }
                            }
                        }

                        if (checkoutList.size() == 0) {
                            AppHelper.showShortToast(this, getString(R.string.msg_coupon_not_applicable));
                        } else {
                            for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                totalAmount += Integer.parseInt(model.getProductQuantity()) * Double.parseDouble(model.getProductPrice());
                            }

                            if (type.equals(AppConstants.COUPON_TYPE_PERCENT)) {
                                if (productIdList.size() == 0 && categoryIdList.size() == 0) {
                                    discountAbleAmount = totalAmount;
                                } else if (productIdList.size() > 0) {
                                    for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                        if (productIdList.contains(model.getProductId())) {
                                            discountAbleAmount += Integer.parseInt(model.getProductQuantity()) * Double.parseDouble(model.getProductPrice());
                                        }
                                    }
                                } else if (categoryIdList.size() > 0) {
                                    for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                        for (int i = 0; i < model.getCategoryIds().size(); i++) {
                                            if (categoryIdList.contains(model.getCategoryIds().get(i))) {
                                                discountAbleAmount += Integer.parseInt(model.getProductQuantity()) * Double.parseDouble(model.getProductPrice());
                                            }
                                        }
                                    }
                                } else {
                                    AppHelper.showShortToast(this, getString(R.string.msg_coupon_not_applicable));
                                }

                                if (discountAbleAmount > 0.00) {
                                    totalDiscount = discountAbleAmount * couponAmount / 100;
                                    double discountTotal = totalAmount - totalDiscount + shippingCost;
                                    netTotalAmount = String.valueOf(discountTotal);

                                    binding.discountPrice.setText("-" + currencySymbol + String.format("%.2f", totalDiscount));
                                    binding.discountTotalLayout.setVisibility(View.VISIBLE);
                                    binding.paymentTotalPrice.setText(currencySymbol + String.format("%.2f", discountTotal));
                                    AppHelper.showShortToast(this, getString(R.string.msg_success_coupon));
                                } else {
                                    AppHelper.showShortToast(this, getString(R.string.msg_coupon_not_applicable));
                                }

                            } else if (type.equals(AppConstants.COUPON_TYPE_FIXED_CART)) {
                                totalDiscount = couponAmount;
                                double discountTotal = totalAmount - totalDiscount + shippingCost;

                                binding.discountPrice.setText("-" + currencySymbol + String.format("%.2f", totalDiscount));
                                binding.discountTotalLayout.setVisibility(View.VISIBLE);
                                binding.paymentTotalPrice.setText(currencySymbol + String.format("%.2f", discountTotal));
                                AppHelper.showShortToast(this, getString(R.string.msg_success_coupon));

                            } else if (type.equals(AppConstants.COUPON_TYPE_FIXED_PRODUCT)) {
                                if (productIdList.size() == 0 && categoryIdList.size() == 0) {
                                    discountAbleAmount = totalAmount;
                                } else if (productIdList.size() > 0) {
                                    for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                        if (productIdList.contains(model.getProductId())) {
                                            totalQuantity += Integer.parseInt(model.getProductQuantity());
                                            discountAbleAmount += Integer.parseInt(model.getProductQuantity()) * Double.parseDouble(model.getProductPrice());
                                        }
                                    }
                                } else if (categoryIdList.size() > 0) {
                                    for (ProductCartModel model : new ArrayList<>(checkoutList)) {
                                        for (int i = 0; i < model.getCategoryIds().size(); i++) {
                                            if (categoryIdList.contains(model.getCategoryIds().get(i))) {
                                                totalQuantity += Integer.parseInt(model.getProductQuantity());
                                                discountAbleAmount += Integer.parseInt(model.getProductQuantity()) * Double.parseDouble(model.getProductPrice());
                                            }
                                        }
                                    }
                                } else {
                                    AppHelper.showShortToast(this, getString(R.string.msg_coupon_not_applicable));
                                }

                                if (discountAbleAmount > 0.00) {
                                    totalDiscount = totalQuantity * couponAmount;
                                    double discountTotal = totalAmount - totalDiscount + shippingCost;
                                    netTotalAmount = String.valueOf(discountTotal + shippingCost);

                                    binding.discountPrice.setText("-" + currencySymbol + String.format("%.2f", totalDiscount));
                                    binding.discountTotalLayout.setVisibility(View.VISIBLE);
                                    binding.paymentTotalPrice.setText(currencySymbol + String.format("%.2f", discountTotal));
                                    AppHelper.showShortToast(this, getString(R.string.msg_success_coupon));
                                } else {
                                    AppHelper.showShortToast(this, getString(R.string.msg_coupon_not_applicable));
                                }
                            }
                        }
                    }
                }
            } else {
                AppHelper.showShortToast(this, getString(R.string.msg_invalid_coupon));
            }
        } else {
            AppHelper.showShortToast(this, getString(R.string.msg_enter_coupon));
        }
    }

    private Boolean hasCoupon(String code) {
        for (ProductCouponModel model : couponList) {
            if (model.getCode().equals(code)) {
                return true;
            }
        }

        return false;
    }

    private ProductCouponModel getCouponModel(String code) {
        ProductCouponModel couponModel = new ProductCouponModel();
        for (ProductCouponModel model : couponList) {
            if (model.getCode().equals(code)) {
                couponModel = model;
            }
        }

        return couponModel;
    }

    private void loadPaymentGateway() {
        Bundle bundle = new Bundle();
        Intent intent = new Intent(PlaceOrderActivity.this, PaymentActivity.class);
        bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, netTotalAmount);
        bundle.putSerializable(AppConstants.BUNDLE_BILLING_ADDRESS, billingAddress);
        startActivityForResult(intent.putExtras(bundle), AppConstants.PAYMENT_REQUEST_CODE);
    }

    private void placeOrder() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            String customerId = AppPreference.getInstance(context).getString(PrefKey.CUSTOMER_ID);

            JsonObject newOrder = ApiRequests.buildOrderRequest(customerId, paymentMethod, paymentTitle, paymentConfirm,
                    billingAddress, shippingAddress, orderList, couponModel, methodModel, totalDiscount, Double.parseDouble(netTotalAmount), transactionId);
            ApiClient.getInstance().getApiInterface().createOrder(newOrder).enqueue(new Callback<OrderModel>() {
                @Override
                public void onResponse(@NonNull Call<OrderModel> call, @NonNull Response<OrderModel> response) {
                    if (response.isSuccessful()) {
                        OrderModel orderModel = response.body();

                        if (orderModel != null)
                            setOrderNote(orderModel.getId());

                        if (!buyNow)
                            clearCartProducts();

                        progressDialog.dismiss();

                        Intent intent = new Intent(PlaceOrderActivity.this, OrderConfirmedActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        progressDialog.dismiss();
                        AppHelper.showLongToast(getApplicationContext(), getString(R.string.failed_msg));
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<OrderModel> call, @NonNull Throwable t) {
                    AppHelper.showLongToast(getApplicationContext(), getString(R.string.failed_msg));
                    progressDialog.dismiss();
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void setOrderNote(Integer orderId) {
        if (NetworkChangeReceiver.isNetworkConnected()) {

            HashMap<String, String> orderNote = ApiRequests.buildOrderNote(orderNotes.toString());
            ApiClient.getInstance().getApiInterface().createOrderNote(orderId, orderNote).enqueue(new Callback<OrderModel>() {
                @Override
                public void onResponse(@NonNull Call<OrderModel> call, @NonNull Response<OrderModel> response) {

                }

                @Override
                public void onFailure(@NonNull Call<OrderModel> call, @NonNull Throwable t) {

                }
            });
        }
    }

    private void clearCartProducts() {
        ProductCartItemLoader cartItemLoader = new ProductCartItemLoader(this);
        cartItemLoader.execute(DaoHelper.DELETE_ALL);
    }
}

