package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemCheckoutProductLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar  on 19-May-19.
 */
public class CheckoutProductListAdapter extends RecyclerView.Adapter<CheckoutProductListAdapter.CheckoutProductViewHolder> {

    private Context context;
    private List<ProductCartModel> arrayList;

    public CheckoutProductListAdapter() {
    }

    public CheckoutProductListAdapter(Context context, List<ProductCartModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public CheckoutProductListAdapter.CheckoutProductViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new CheckoutProductViewHolder((ItemCheckoutProductLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_checkout_product_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CheckoutProductListAdapter.CheckoutProductViewHolder holder, int position) {
        String title = arrayList.get(position).getProductName();
        String productImage = arrayList.get(position).getProductImage();
        String productPrice = arrayList.get(position).getProductPrice();
        String totalPrice = arrayList.get(position).getTotalPrice();
        String quantity = arrayList.get(position).getProductQuantity();
        String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
        String attributes = arrayList.get(position).getProductAttribute();

        if (productImage != null) {
            Picasso.get().load(productImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(holder.binding.productImage);
        }

        holder.binding.productTitle.setText(AppHelper.fromHtml(title));
        holder.binding.productQuantity.setText(quantity + " pcs");
        holder.binding.productSalePrice.setText(currencySymbol + productPrice);
        holder.binding.productSubtotalPrice.setText(currencySymbol + totalPrice);

        if (attributes != null && !attributes.isEmpty()) {
            attributes = attributes.substring(1, attributes.length() - 1).replace("=", ":");
            attributes = attributes.replace("=", ":");
            holder.binding.productAttributes.setText(attributes);
            holder.binding.productAttributes.setVisibility(View.VISIBLE);
        } else {
            holder.binding.productAttributes.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class CheckoutProductViewHolder extends RecyclerView.ViewHolder {

        ItemCheckoutProductLayoutBinding binding;

        CheckoutProductViewHolder(@NonNull ItemCheckoutProductLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;
        }
    }
}
