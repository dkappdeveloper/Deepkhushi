package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemFavouriteProductLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemViewClickListener;
import com.shoppingapp.deepkhushi.model.dbEntity.FavouritesModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 14-May-19.
 */

public class MyFavouritesAdapter extends RecyclerView.Adapter<MyFavouritesAdapter.MyFavouritesViewHolder> {

    private Context context;
    private List<FavouritesModel> arrayList;

    private ItemViewClickListener itemClickListener;

    public MyFavouritesAdapter() {
    }

    public MyFavouritesAdapter(Context context, List<FavouritesModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemViewClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public MyFavouritesAdapter.MyFavouritesViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new MyFavouritesViewHolder((ItemFavouriteProductLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_favourite_product_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyFavouritesAdapter.MyFavouritesViewHolder holder, int position) {
        String title = arrayList.get(position).getProductName();
        String productImage = arrayList.get(position).getProductImage();
        String salePrice = arrayList.get(position).getSalePrice();
        String regularPrice = arrayList.get(position).getRegularPrice();
        String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);

        if (productImage != null && !productImage.isEmpty()) {
            Picasso.get().load(productImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(holder.binding.productImage);
        }

        holder.binding.productTitle.setText(AppHelper.fromHtml(title));

        if (salePrice != null && !salePrice.isEmpty()) {
            holder.binding.productSalePrice.setText(currencySymbol + salePrice);
            holder.binding.productRegularPrice.setText(currencySymbol + regularPrice);
            holder.binding.productRegularPrice.setVisibility(View.VISIBLE);
        } else {
            holder.binding.productSalePrice.setText(currencySymbol + regularPrice);
            holder.binding.productRegularPrice.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyFavouritesViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemFavouriteProductLayoutBinding binding;

        MyFavouritesViewHolder(@NonNull ItemFavouriteProductLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
            binding.removeProduct.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemViewClickGetPosition(getLayoutPosition(), view);
        }
    }
}
