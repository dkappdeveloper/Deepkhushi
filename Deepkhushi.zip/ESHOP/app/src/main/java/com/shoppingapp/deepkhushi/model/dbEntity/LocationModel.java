package com.shoppingapp.deepkhushi.model.dbEntity;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;

/**
 * Created by Sahidul Islam on 15-Nov-19.
 */
@Entity(tableName = DaoHelper.LOCATION_TBL)
public class LocationModel implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = DaoHelper.COLUMN_AUTO_ID)
    private int autoId;

    @ColumnInfo(name = DaoHelper.COLUMN_CONTINENT_CODE)
    private String continentCode;

    @ColumnInfo(name = DaoHelper.COLUMN_CONTINENT_NAME)
    private String continentName;

    @ColumnInfo(name = DaoHelper.COLUMN_COUNTRY_CODE)
    private String countryCode;

    @ColumnInfo(name = DaoHelper.COLUMN_COUNTRY_NAME)
    private String countryName;

    @ColumnInfo(name = DaoHelper.COLUMN_STATE_CODE)
    private String stateCode;

    @ColumnInfo(name = DaoHelper.COLUMN_STATE_NAME)
    private String stateName;


    @Ignore
    public LocationModel() {
    }

    @Ignore
    public LocationModel(String continentCode, String continentName, String countryCode, String countryName, String stateCode, String stateName) {
        this.continentCode = continentCode;
        this.continentName = continentName;
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.stateCode = stateCode;
        this.stateName = stateName;
    }

    public LocationModel(int autoId, String continentCode, String continentName, String countryCode, String countryName, String stateCode, String stateName) {
        this.autoId = autoId;
        this.continentCode = continentCode;
        this.continentName = continentName;
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.stateCode = stateCode;
        this.stateName = stateName;
    }

    protected LocationModel(Parcel in) {
        autoId = in.readInt();
        continentCode = in.readString();
        continentName = in.readString();
        countryCode = in.readString();
        countryName = in.readString();
        stateCode = in.readString();
        stateName = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(autoId);
        dest.writeString(continentCode);
        dest.writeString(continentName);
        dest.writeString(countryCode);
        dest.writeString(countryName);
        dest.writeString(stateCode);
        dest.writeString(stateName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<LocationModel> CREATOR = new Creator<LocationModel>() {
        @Override
        public LocationModel createFromParcel(Parcel in) {
            return new LocationModel(in);
        }

        @Override
        public LocationModel[] newArray(int size) {
            return new LocationModel[size];
        }
    };

    public int getAutoId() {
        return autoId;
    }

    public void setAutoId(int autoId) {
        this.autoId = autoId;
    }

    public String getContinentCode() {
        return continentCode;
    }

    public void setContinentCode(String continentCode) {
        this.continentCode = continentCode;
    }

    public String getContinentName() {
        return continentName;
    }

    public void setContinentName(String continentName) {
        this.continentName = continentName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }
}
