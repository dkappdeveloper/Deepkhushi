package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.HomeCategoryListAdapter;
import com.shoppingapp.deepkhushi.adapter.recycler.HomeProductListAdapter;
import com.shoppingapp.deepkhushi.adapter.recycler.ProductListAdapter;
import com.shoppingapp.deepkhushi.adapter.viewpager.HomeSliderAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ActivityHomeLayoutBinding;
import com.shoppingapp.deepkhushi.databinding.NavHeaderLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DateHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.category.CategoryModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.shoppingapp.deepkhushi.model.product.ProductSearchModel;
import com.shoppingapp.deepkhushi.model.product.ProductTag;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiConfig;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 19-Jan-19.
 */

public class HomeActivity extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener {

    ActivityHomeLayoutBinding binding;
    NavHeaderLayoutBinding navHeaderbinding;

    HomeSliderAdapter sliderAdapter;
    HomeCategoryListAdapter categoryListAdapter;
    ProductListAdapter specialSaleAdapter;
    HomeProductListAdapter newArrivalAdapter;
    HomeProductListAdapter hotDealAdapter;
    HomeProductListAdapter trendingAdapter;

    private List<CategoryModel> categoryList, categoryArrayList;
    private List<ProductModel> sliderList;
    private List<ProductModel> newArrivalList, trendingList;
    private List<ProductModel> hotDealList, specialSaleList;

    private ProductSearchModel categoryModel, newestModel;
    private ProductSearchModel featuredModel, taggedModel;

    private boolean doubleBackToExitPressedOnce = false;
    private int NUM_PAGES = 0, CURRENT_PAGE = 0;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Boolean isLoggedIn = AppPreference.getInstance(context).getBoolean(PrefKey.SIGNED_IN);
        if (isLoggedIn) {
            String firstName = AppPreference.getInstance(context).getString(PrefKey.FIRST_NAME);
            String lastName = AppPreference.getInstance(context).getString(PrefKey.LAST_NAME);
            String email = AppPreference.getInstance(context).getString(PrefKey.EMAIL);
            String profilePic = AppPreference.getInstance(context).getString(PrefKey.PROFILE_IMAGE);

            if (profilePic != null && !profilePic.isEmpty()) {
                Picasso.get().load(profilePic)
                        .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .into(navHeaderbinding.profileImage);
            }

            navHeaderbinding.profileFullName.setText(firstName + " " + lastName);
            navHeaderbinding.profileEmail.setText(email);

            navHeaderbinding.defaultHeader.setVisibility(View.GONE);
            navHeaderbinding.profileHeader.setVisibility(View.VISIBLE);
        } else {
            navHeaderbinding.profileHeader.setVisibility(View.GONE);
            navHeaderbinding.defaultHeader.setVisibility(View.VISIBLE);
        }

        updateToolbarNotificationCount(binding.homeToolbar.notificationCounter);
    }

    @Override
    public void onBackPressed() {
        if (this.binding.homeDrawerlayout.isDrawerOpen(GravityCompat.START)) {
            this.binding.homeDrawerlayout.closeDrawer(GravityCompat.START);
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }
            this.doubleBackToExitPressedOnce = true;
            AppHelper.showShortToast(HomeActivity.this, getString(R.string.please_click_back));

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        binding.homeDrawerlayout.closeDrawer(GravityCompat.START);

        switch (id) {
            case R.id.nav_category:
                startActivity(new Intent(this, CategoryActivity.class));
                break;
            case R.id.nav_favourites:
                startActivity(new Intent(this, MyFavouritesActivity.class));
                break;
            case R.id.nav_cart_list:
                startActivity(new Intent(this, ProductCartActivity.class));
                break;
            case R.id.nav_orders:
                startActivity(new Intent(this, MyOrdersActivity.class));
                break;
            case R.id.nav_address:
                Bundle bundle = new Bundle();
                bundle.putBoolean(AppConstants.BUNDLE_UPDATE_ADDRESS, true);
                startActivity(new Intent(this, CheckoutAddressActivity.class).putExtras(bundle));
                break;
            case R.id.nav_app_settings:
                startActivity(new Intent(this, AppSettingsActivity.class));
                break;
            case R.id.nav_facebook:
                AppHelper.faceBookLink(this);
                break;
            case R.id.nav_youtube:
                AppHelper.youtubeLink(this);
                break;
            case R.id.nav_instagram:
                AppHelper.instagramLink(this);
                break;
            case R.id.nav_whatsapp:
                AppHelper.whatsappLink(this);
                break;
            case R.id.nav_terms_condition:
                AppHelper.browseUrl(this, getString(R.string.nav_terms_condition), getString(R.string.terms_url), false);
                break;
            case R.id.nav_privacy_policy:
                AppHelper.browseUrl(this, getString(R.string.nav_privacy_policy), getString(R.string.privacy_url), false);
                break;
            case R.id.nav_faq:
                AppHelper.browseUrl(this, getString(R.string.nav_faq), getString(R.string.faq_url), false);
                break;
            case R.id.nav_rate_app:
                AppHelper.rateThisApp(this);
                break;
            case R.id.nav_more_apps:
                AppHelper.developerMoreApps(this);
                break;
        }
        return true;
    }

    private void initVars() {
        categoryList = new ArrayList<>();
        categoryArrayList = new ArrayList<>();
        sliderList = new ArrayList<>();
        newArrivalList = new ArrayList<>();
        trendingList = new ArrayList<>();
        hotDealList = new ArrayList<>();
        specialSaleList = new ArrayList<>();

        newestModel = new ProductSearchModel();
        featuredModel = new ProductSearchModel();
        taggedModel = new ProductSearchModel();
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home_layout);

        initDrawerLayout();
        initializeDrawerHeader();
        initSliderViewPager();
        initRecyclerView();
    }

    private void initListener() {
        binding.homeToolbar.toolbarMenuNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, NotificationActivity.class));
            }
        });

        binding.homeToolbar.toolbarMenuSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, SearchProductActivity.class));
            }
        });

        sliderAdapter.setSliderItemClickListerner(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
/*                categoryModel = new ProductSearchModel();
                categoryModel.setPage(AppConstants.PAGE_NUMBER);
                categoryModel.setPerPage(AppConstants.PER_PAGE);
                categoryModel.setCategoryId(categoryList.get(position).getId().toString());

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, categoryList.get(position).getName());
                bundle.putParcelable(AppConstants.BUNDLE_SEARCH_PRODUCT, categoryModel);
                startActivity(new Intent(HomeActivity.this, ProductDetailActivity.class).putExtras(bundle));*/

                ProductModel model = sliderList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(HomeActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });
    }

    private void loadData() {
        loadFeaturedProducts();
        loadCategories();
        loadProductByTag(ApiConfig.SLUG_TRENDING_DEAL);
        loadProductByTag(ApiConfig.SLUG_HOT_DEAL);
        loadProductByTag(ApiConfig.SLUG_SPECIAL_SALE);
        loadNewestProducts();
    }

    private void initDrawerLayout() {
        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this, binding.homeDrawerlayout, binding.homeToolbar.toolbar, R.string.navigation_open, R.string.navigation_close);
        binding.homeDrawerlayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        binding.mainNavView.setNavigationItemSelectedListener(this);
    }

    private void initializeDrawerHeader() {
        navHeaderbinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.nav_header_layout, binding.mainNavView, false);
        binding.mainNavView.addHeaderView(navHeaderbinding.getRoot());
    }

    private void initSliderViewPager() {
        sliderAdapter = new HomeSliderAdapter(this, sliderList, true);
        binding.contentView.sliderViewpager.setPadding(10, 10, 10, 10);
        binding.contentView.sliderViewpager.setPageMargin(20);
        binding.contentView.sliderViewpager.setAdapter(sliderAdapter);
    }

    private void initRecyclerView() {
        categoryListAdapter = new HomeCategoryListAdapter(getApplicationContext(), categoryList);
        binding.contentView.categoryRecyclerView.setHasFixedSize(true);
        binding.contentView.categoryRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.contentView.categoryRecyclerView.setNestedScrollingEnabled(false);
        binding.contentView.categoryRecyclerView.setAdapter(categoryListAdapter);

        categoryListAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {

                Bundle bundle = new Bundle();
                if (hasSubCategory(categoryList.get(position).getId())) {
                    bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, categoryList.get(position).getName());
                    bundle.putInt(AppConstants.BUNDLE_CATEGORY_ID, categoryList.get(position).getId());
                    startActivity(new Intent(HomeActivity.this, SubCategoryActivity.class).putExtras(bundle));
                } else {
                    categoryModel = new ProductSearchModel();
                    categoryModel.setPage(AppConstants.PAGE_NUMBER);
                    categoryModel.setPerPage(AppConstants.PER_PAGE);
                    categoryModel.setCategoryId(categoryList.get(position).getId().toString());

                    bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, categoryList.get(position).getName());
                    bundle.putParcelable(AppConstants.BUNDLE_SEARCH_PRODUCT, categoryModel);
                    startActivity(new Intent(HomeActivity.this, ProductListActivity.class).putExtras(bundle));
                }
            }
        });


        newArrivalAdapter = new HomeProductListAdapter(getApplicationContext(), newArrivalList, AppConstants.ListLayoutType.GRID);
        binding.contentView.newArrival.contentRecyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.contentView.newArrival.contentRecyclerView.setNestedScrollingEnabled(false);
        binding.contentView.newArrival.contentRecyclerView.setAdapter(newArrivalAdapter);

        newArrivalAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = newArrivalList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(HomeActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });


        trendingAdapter = new HomeProductListAdapter(getApplicationContext(), trendingList, AppConstants.ListLayoutType.GRID);
        binding.contentView.trendingDeal.contentRecyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.contentView.trendingDeal.contentRecyclerView.setNestedScrollingEnabled(false);
        binding.contentView.trendingDeal.contentRecyclerView.setAdapter(trendingAdapter);

        trendingAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = trendingList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(HomeActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });


        hotDealAdapter = new HomeProductListAdapter(getApplicationContext(), hotDealList, AppConstants.ListLayoutType.GRID);
        binding.contentView.hotDeal.contentRecyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.contentView.hotDeal.contentRecyclerView.setNestedScrollingEnabled(false);
        binding.contentView.hotDeal.contentRecyclerView.setAdapter(hotDealAdapter);

        hotDealAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = hotDealList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(HomeActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });


        specialSaleAdapter = new ProductListAdapter(getApplicationContext(), specialSaleList, AppConstants.ListLayoutType.GRID);
        binding.contentView.specialSale.contentRecyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.contentView.specialSale.contentRecyclerView.setNestedScrollingEnabled(false);
        binding.contentView.specialSale.contentRecyclerView.setAdapter(specialSaleAdapter);

        specialSaleAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = specialSaleList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(HomeActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });
    }

    private void showSlider() {
        NUM_PAGES = sliderList.size();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(AppConstants.SLIDER_DURATION);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    CURRENT_PAGE = binding.contentView.sliderViewpager.getCurrentItem();
                    if (CURRENT_PAGE == (NUM_PAGES - 1)) {
                        CURRENT_PAGE = 0;
                    } else {
                        CURRENT_PAGE++;
                    }

                    (HomeActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            binding.contentView.sliderViewpager.setCurrentItem(CURRENT_PAGE, true);
                        }
                    });
                }
            }
        }).start();

        sliderAdapter.notifyDataSetChanged();
        binding.contentView.sliderIndicator.setViewPager(binding.contentView.sliderViewpager);

        binding.contentView.sliderShimmerView.setVisibility(View.GONE);
        binding.contentView.sliderViewpager.setVisibility(View.VISIBLE);
        binding.contentView.sliderIndicator.setVisibility(View.VISIBLE);
    }

    private void showProductListByTag(@NonNull String tagSlug, List<ProductModel> productModels) {
        switch (tagSlug) {
            case ApiConfig.SLUG_TRENDING_DEAL:
                trendingList.clear();
                trendingList.addAll(productModels);
                trendingAdapter.notifyDataSetChanged();

                binding.contentView.contentShimmerLayout.shimmerGridLayout.setVisibility(View.GONE);
                binding.contentView.trendingDeal.contentView.setVisibility(View.VISIBLE);
                binding.contentView.trendingDeal.contentTitle.setText(getString(R.string.trending_deal));
                break;
            case ApiConfig.SLUG_HOT_DEAL:
                hotDealList.clear();
                hotDealList.addAll(productModels);
                hotDealAdapter.notifyDataSetChanged();

                binding.contentView.contentShimmerLayout.shimmerGridLayout.setVisibility(View.GONE);
                binding.contentView.hotDeal.contentView.setVisibility(View.VISIBLE);
                binding.contentView.hotDeal.contentTitle.setText(getString(R.string.hot_deal));
                break;
            case ApiConfig.SLUG_SPECIAL_SALE:
                specialSaleList.clear();
                specialSaleList.addAll(productModels);
                specialSaleAdapter.notifyDataSetChanged();

                binding.contentView.contentShimmerLayout.shimmerGridLayout.setVisibility(View.GONE);
                binding.contentView.specialSale.contentView.setVisibility(View.VISIBLE);
                binding.contentView.specialSale.contentTitle.setText(getString(R.string.special_sale));
                break;
        }
    }

    private void loadCategories() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            HashMap<String, String> categoryListMap = ApiRequests.buildCategoryList(true, AppConstants.CATEGORY_PER_PAGE);
            ApiClient.getInstance().getApiInterface().getCategories(categoryListMap).enqueue(new Callback<List<CategoryModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<CategoryModel>> call, @NonNull Response<List<CategoryModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            categoryList.clear();
                            categoryArrayList.clear();
                            categoryArrayList.addAll(response.body());

                            if (categoryArrayList != null && categoryArrayList.size() > 0) {

                                /* Show only Main/Parent Categories*/
                                for (CategoryModel categoryModel : response.body()) {
                                    if (categoryModel.getParent() == 0) {
                                        categoryList.add(categoryModel);
                                    }
                                }

                                /* Show All Categories*/
                                // categoryList.addAll(response.body());

/*                                for (int i = 0; i < categoryList.size(); i++) {
                                    if (categoryList.get(i).getCategoryImageModel() != null) {
                                        sliderList.add(categoryList.get(i));
                                    }
                                }*/


                                categoryListAdapter.notifyDataSetChanged();
                                binding.contentView.categoryRecyclerView.setVisibility(View.VISIBLE);
                            }
                            binding.contentView.categoryShimmerView.setVisibility(View.GONE);
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<CategoryModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadNewestProducts() {
        if (NetworkChangeReceiver.isNetworkConnected()) {

            newestModel.setPage(AppConstants.PAGE_NUMBER);
            newestModel.setPerPage(AppConstants.PER_PAGE);
            newestModel.setDateAfter(DateHelper.getISODateTime(AppConstants.DEFAULT_DAYS_BEFORE));
            HashMap<String, String> productOfNewest = ApiRequests.buildProductList(newestModel);

            ApiClient.getInstance().getApiInterface().getProducts(productOfNewest).enqueue(new Callback<List<ProductModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductModel>> call, @NonNull Response<List<ProductModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            List<ProductModel> modelList = response.body();

                            if (modelList.size() > 0) {
                                newArrivalList.clear();
                                newArrivalList.addAll(modelList);
                                newArrivalAdapter.notifyDataSetChanged();

                                binding.contentView.contentShimmerLayout.shimmerGridLayout.setVisibility(View.GONE);
                                binding.contentView.newArrival.contentTitle.setText(getString(R.string.new_arrival));
                                binding.contentView.newArrival.contentView.setVisibility(View.VISIBLE);
                            }
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadFeaturedProducts() {
        if (NetworkChangeReceiver.isNetworkConnected()) {

            featuredModel = new ProductSearchModel();
            featuredModel.setFeatured("true");
            HashMap<String, String> featuredProduct = ApiRequests.buildProductList(featuredModel);

            ApiClient.getInstance().getApiInterface().getProducts(featuredProduct).enqueue(new Callback<List<ProductModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductModel>> call, @NonNull Response<List<ProductModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            List<ProductModel> modelList = response.body();

                            if (modelList.size() > 0) {
                                sliderList.clear();
                                sliderList.addAll(modelList);
                                showSlider();
                            }
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadProductByTag(final String tagSlug) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            HashMap<String, String> productTagBySlug = ApiRequests.buildProductTagBySlug(tagSlug);
            ApiClient.getInstance().getApiInterface().checkProductHasTag(productTagBySlug).enqueue(new Callback<List<ProductTag>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductTag>> call, @NonNull Response<List<ProductTag>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null && response.body().size() > 0) {
                            getProductByTag(tagSlug, response.body().get(0).getId());
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductTag>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void getProductByTag(final String tagSlug, int tagId) {
        taggedModel.setPage(AppConstants.PAGE_NUMBER);
        taggedModel.setPerPage(AppConstants.PER_PAGE);
        taggedModel.setTagId(tagId);
        HashMap<String, String> productByTag = ApiRequests.buildProductList(taggedModel);

        ApiClient.getInstance().getApiInterface().getProducts(productByTag).enqueue(new Callback<List<ProductModel>>() {
            @Override
            public void onResponse(@NonNull Call<List<ProductModel>> call, @NonNull Response<List<ProductModel>> response) {
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        showProductListByTag(tagSlug, response.body());
                    }
                } else {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<ProductModel>> call, @NonNull Throwable t) {
                AppHelper.showShortToast(context, getString(R.string.failed_msg));
            }
        });
    }

    private boolean hasSubCategory(int categoryId) {

        boolean hasCategory = false;

        for (CategoryModel model : categoryArrayList) {
            if (categoryId > 0 && model.getParent() == categoryId) {
                hasCategory = true;
            }
        }

        return hasCategory;
    }
}
