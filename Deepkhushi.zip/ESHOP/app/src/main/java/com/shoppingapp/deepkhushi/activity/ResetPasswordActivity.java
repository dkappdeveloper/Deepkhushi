package com.shoppingapp.deepkhushi.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.databinding.ActivityResetPaswordLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.ValidationHelper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

/**
 * Created by Deepak Kumar on 08-Feb-20.
 */

public class ResetPasswordActivity extends BaseActivity {

    ActivityResetPaswordLayoutBinding binding;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_reset_pasword_layout);

        initVars();
        initView();
        initListener();
    }

    private void initVars() {
        firebaseAuth = FirebaseAuth.getInstance();
    }

    private void initView() {
    }

    private void initListener() {
        binding.txtAccountLogin.setOnClickListener(onViewItemClick());
        binding.btnResetPassword.setOnClickListener(onViewItemClick());
    }

    private void sendResetLink() {
        String email = binding.inputAccountEmail.getText().toString().trim();

        if (!ValidationHelper.isValidEmail(email)) {
            AppHelper.showShortToast(context, getString(R.string.msg_invalid_email));
        } else {
            progressDialog.show();

            firebaseAuth.sendPasswordResetEmail(email)
                    .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                AppHelper.showLongToast(context, "We have sent you instructions to reset your password!");
                                finish();
                            }

                            progressDialog.dismiss();
                        }
                    })
                    .addOnFailureListener(this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("onComplete: ", e.getMessage());
                            AppHelper.showLongToast(context, e.getMessage());
                            progressDialog.dismiss();
                        }
                    });

        }
    }

    private View.OnClickListener onViewItemClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.txt_account_login:
                        finish();
                        break;
                    case R.id.btn_reset_password:
                        sendResetLink();
                        break;
                }
            }
        };
    }
}
