package com.shoppingapp.deepkhushi.database.converters;

import androidx.room.TypeConverter;

import java.util.Date;

/**
 * Created by Deepak Kumar on 15-Nov-19.
 */
public class DateConverter {

    @TypeConverter
    public static Date fromTimestamp(Long value) {
        return value == null ? null : new Date(value);
    }

    @TypeConverter
    public static Long dateToTimestamp(Date date) {
        return date == null ? null : date.getTime();
    }
}
