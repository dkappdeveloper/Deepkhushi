package com.shoppingapp.deepkhushi.listener;

/**
 * Created by Deepak Kumar on 11/7/2016.
 */
public interface NetworkChangeListener {
    void onNetworkConnectionChanged(Boolean isConnected);
}
