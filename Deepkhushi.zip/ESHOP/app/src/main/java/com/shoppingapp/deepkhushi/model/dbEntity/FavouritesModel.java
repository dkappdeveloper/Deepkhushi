package com.shoppingapp.deepkhushi.model.dbEntity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;

/**
 * Created by Md Sahidul Islam on 12-May-19.
 */

@Entity(tableName = DaoHelper.FAVOURITE_PRODUCT_TBL)
public class FavouritesModel {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = DaoHelper.COLUMN_AUTO_ID)
    private int autoId;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_ID)
    private int productId;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_NAME)
    private String productName;

    @ColumnInfo(name = DaoHelper.COLUMN_SALE_PRICE)
    private String salePrice;

    @ColumnInfo(name = DaoHelper.COLUMN_REGULAR_PRICE)
    private String regularPrice;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_IMAGE)
    private String productImage;


    @Ignore
    public FavouritesModel() {
    }

    public FavouritesModel(int productId, String productName, String salePrice, String regularPrice, String productImage) {
        this.productId = productId;
        this.productName = productName;
        this.salePrice = salePrice;
        this.regularPrice = regularPrice;
        this.productImage = productImage;
    }

    public int getAutoId() {
        return autoId;
    }

    public void setAutoId(int autoId) {
        this.autoId = autoId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }

    public String getRegularPrice() {
        return regularPrice;
    }

    public void setRegularPrice(String regularPrice) {
        this.regularPrice = regularPrice;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

}
