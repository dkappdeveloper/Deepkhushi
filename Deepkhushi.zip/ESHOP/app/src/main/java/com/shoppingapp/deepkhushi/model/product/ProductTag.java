package com.shoppingapp.deepkhushi.model.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductTag implements Parcelable {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("count")
    @Expose
    private Integer count;


    /**
     * No args constructor for use in serialization
     */
    public ProductTag() {
    }

    /**
     * @param id
     * @param count
     * @param description
     * @param name
     * @param slug
     */
    public ProductTag(Integer id, String name, String slug, String description, Integer count) {
        super();
        this.id = id;
        this.name = name;
        this.slug = slug;
        this.description = description;
        this.count = count;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public final static Parcelable.Creator<ProductTag> CREATOR = new Creator<ProductTag>() {

        @SuppressWarnings({
                "unchecked"
        })
        public ProductTag createFromParcel(Parcel in) {
            return new ProductTag(in);
        }

        public ProductTag[] newArray(int size) {
            return (new ProductTag[size]);
        }

    };

    protected ProductTag(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.slug = ((String) in.readValue((String.class.getClassLoader())));
        this.description = ((String) in.readValue((String.class.getClassLoader())));
        this.count = ((Integer) in.readValue((Integer.class.getClassLoader())));
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(name);
        dest.writeValue(slug);
        dest.writeValue(description);
        dest.writeValue(count);
    }

    public int describeContents() {
        return 0;
    }

}
