package com.shoppingapp.deepkhushi.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DataCurrencyModel implements Parcelable {

    public final static Creator<DataCurrencyModel> CREATOR = new Creator<DataCurrencyModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public DataCurrencyModel createFromParcel(Parcel in) {
            return new DataCurrencyModel(in);
        }

        public DataCurrencyModel[] newArray(int size) {
            return (new DataCurrencyModel[size]);
        }

    };
    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("symbol")
    @Expose
    private String symbol;

    protected DataCurrencyModel(Parcel in) {
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.symbol = ((String) in.readValue((String.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     */
    public DataCurrencyModel() {
    }

    /**
     * @param symbol
     * @param name
     * @param code
     */
    public DataCurrencyModel(String code, String name, String symbol) {
        super();
        this.code = code;
        this.name = name;
        this.symbol = symbol;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(code);
        dest.writeValue(name);
        dest.writeValue(symbol);
    }

    public int describeContents() {
        return 0;
    }

}
