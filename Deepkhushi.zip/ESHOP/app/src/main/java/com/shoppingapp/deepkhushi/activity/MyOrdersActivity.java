package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.MyOrdersAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ActivityMyOrdersLayoutBinding;
import com.shoppingapp.deepkhushi.helper.ADHelper;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.order.OrderModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 15-May-19.
 */
public class MyOrdersActivity extends BaseActivity {

    ActivityMyOrdersLayoutBinding binding;

    MyOrdersAdapter ordersAdapter;
    private List<OrderModel> orderList;

    boolean isFromConfirmOrder = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        initRecyclerView();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Boolean isLoggedIn = AppPreference.getInstance(context).getBoolean(PrefKey.SIGNED_IN);

        if (!isLoggedIn) {
            AppHelper.showLoginSnack(binding.parentView, this, MyOrdersActivity.this, false);
        } else {
            loadMyOrders();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (isFromConfirmOrder)
                    startActivity(new Intent(MyOrdersActivity.this, HomeActivity.class));
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (isFromConfirmOrder)
            startActivity(new Intent(MyOrdersActivity.this, HomeActivity.class));
        finish();
    }

    private void initVars() {
        orderList = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            if (bundle.containsKey(AppConstants.BUNDLE_FROM_CONFIRM_ORDER))
                isFromConfirmOrder = bundle.getBoolean(AppConstants.BUNDLE_FROM_CONFIRM_ORDER);
        }
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_orders_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_my_orders));
    }

    private void initListener() {

    }

    private void initRecyclerView() {
        ordersAdapter = new MyOrdersAdapter(this, orderList);
        binding.myOrdersRecycler.setLayoutManager(new LinearLayoutManager(this));
        binding.myOrdersRecycler.setAdapter(ordersAdapter);

        ordersAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                OrderModel model = orderList.get(position);

                Bundle bundle = new Bundle();
                bundle.putParcelable(AppConstants.BUNDLE_ORDER_DETAIL, model);
                startActivity(new Intent(MyOrdersActivity.this, OrderDetailActivity.class).putExtras(bundle));
            }
        });
    }

    private void loadMyOrders() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            binding.shimmerMyOrdersLayout.shimmerCategoryLayout.setVisibility(View.VISIBLE);
            Integer customerId = Integer.parseInt(AppPreference.getInstance(context).getString(PrefKey.CUSTOMER_ID));

            ApiClient.getInstance().getApiInterface().getMyOrders(customerId).enqueue(new Callback<List<OrderModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<OrderModel>> call, @NonNull Response<List<OrderModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            orderList.clear();
                            orderList.addAll(response.body());

                            if (orderList != null && orderList.size() > 0) {
                                ordersAdapter.notifyDataSetChanged();
                                binding.myOrdersRecycler.setVisibility(View.VISIBLE);
                            } else {
                                binding.emptyListLayout.removeAllViews();
                                binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.order_list_empty)));
                                binding.emptyListLayout.setVisibility(View.VISIBLE);
                            }
                        }
                    } else {
                        binding.emptyListLayout.removeAllViews();
                        binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.no_data)));
                        binding.emptyListLayout.setVisibility(View.VISIBLE);
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                    binding.shimmerMyOrdersLayout.shimmerCategoryLayout.setVisibility(View.GONE);
                }

                @Override
                public void onFailure(@NonNull Call<List<OrderModel>> call, @NonNull Throwable t) {
                    binding.emptyListLayout.removeAllViews();
                    binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.no_data)));
                    binding.emptyListLayout.setVisibility(View.VISIBLE);
                    binding.shimmerMyOrdersLayout.shimmerCategoryLayout.setVisibility(View.GONE);
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }
}
