package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemSearchCategoryLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.category.CategoryModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 26-May-19.
 */
public class SearchCategoryListAdapter extends RecyclerView.Adapter<SearchCategoryListAdapter.SearchCategoryViewHolder> {

    private Context context;
    private List<CategoryModel> arrayList;

    private ItemClickListener itemClickListener;

    public SearchCategoryListAdapter() {
    }

    public SearchCategoryListAdapter(Context context, List<CategoryModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public SearchCategoryListAdapter.SearchCategoryViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new SearchCategoryViewHolder((ItemSearchCategoryLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_search_category_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SearchCategoryListAdapter.SearchCategoryViewHolder holder, int position) {
        String categoryName = arrayList.get(position).getName();
        Integer productCount = arrayList.get(position).getCount();

        holder.binding.categoryName.setText(AppHelper.fromHtml(categoryName) + " (" + productCount + ") ");

        Boolean selected = arrayList.get(position).getSelected();
        if (selected) {
            holder.binding.categoryName.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimary2));
            holder.binding.categoryName.setTextColor(ContextCompat.getColor(context, R.color.colorWhite));
        } else {
            holder.binding.categoryName.setBackgroundColor(ContextCompat.getColor(context, R.color.grayExtraLight));
            holder.binding.categoryName.setTextColor(ContextCompat.getColor(context, R.color.colorBlack));
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class SearchCategoryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemSearchCategoryLayoutBinding binding;

        SearchCategoryViewHolder(@NonNull ItemSearchCategoryLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.categoryName.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
