package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemGridProductListLayoutBinding;
import com.shoppingapp.deepkhushi.databinding.ItemLinearProductListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductImageModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 22-Feb-19.
 */
public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ProductListViewHolder> {

    private Context context;
    private List<ProductModel> arrayList;
    private AppConstants.ListLayoutType listLayoutType;

    private ItemClickListener itemClickListener;

    public ProductListAdapter(Context context) {
        this.context = context;
    }

    public ProductListAdapter(Context context, List<ProductModel> arrayList, AppConstants.ListLayoutType listLayoutType) {
        this.context = context;
        this.arrayList = arrayList;
        this.listLayoutType = listLayoutType;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ProductListAdapter.ProductListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        if (listLayoutType == AppConstants.ListLayoutType.GRID) {
            return new ProductListViewHolder((ItemGridProductListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_grid_product_list_layout, viewGroup, false));
        } else {
            return new ProductListViewHolder((ItemLinearProductListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_linear_product_list_layout, viewGroup, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ProductListAdapter.ProductListViewHolder holder, int position) {
        List<ProductImageModel> imageModel = arrayList.get(position).getProductImageModels();
        String type = arrayList.get(position).getType();
        String title = arrayList.get(position).getName();
        String rating = arrayList.get(position).getAverageRating();
        String sale = arrayList.get(position).getTotalSales().toString();
        String basePrice = arrayList.get(position).getPrice();
        String salePrice = arrayList.get(position).getSalePrice();
        String regularPrice = arrayList.get(position).getRegularPrice();
        String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
        Boolean isFavourite = arrayList.get(position).getFavourite();

        if (listLayoutType == AppConstants.ListLayoutType.GRID) {
            if (imageModel.size() > 0) {
                String productImage = imageModel.get(0).getSrc();
                Picasso.get().load(productImage)
                        .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .into(holder.gridLayoutBinding.productImage);
            }

            holder.gridLayoutBinding.productTitle.setText(AppHelper.fromHtml(title));
            holder.gridLayoutBinding.productRating.setText(rating);
            holder.gridLayoutBinding.productSaleCount.setText(sale + " " + context.getString(R.string.sales));

            if (type.equals(AppConstants.PRODUCT_TYPE_VARIABLE)) {
                holder.gridLayoutBinding.productSalePrice.setText(currencySymbol + basePrice);
                holder.gridLayoutBinding.productRegularPrice.setVisibility(View.GONE);
                holder.gridLayoutBinding.productDiscountPercent.setVisibility(View.GONE);
            } else if (type.equals(AppConstants.PRODUCT_TYPE_SIMPLE)) {
                if (salePrice != null && !salePrice.isEmpty()) {
                    int discountPercent = (int) Math.round((Float.parseFloat(salePrice) - Float.parseFloat(regularPrice)) / (Float.parseFloat(regularPrice) * .01));

                    holder.gridLayoutBinding.productSalePrice.setText(currencySymbol + salePrice);
                    holder.gridLayoutBinding.productRegularPrice.setText(currencySymbol + regularPrice);
                    holder.gridLayoutBinding.productDiscountPercent.setText("-" + Math.abs(discountPercent) + AppConstants.PERCENTAGE_SYMBOLE);
                    holder.gridLayoutBinding.productRegularPrice.setVisibility(View.VISIBLE);
                    holder.gridLayoutBinding.productDiscountPercent.setVisibility(View.VISIBLE);
                } else {
                    holder.gridLayoutBinding.productSalePrice.setText(currencySymbol + regularPrice);
                    holder.gridLayoutBinding.productRegularPrice.setVisibility(View.GONE);
                    holder.gridLayoutBinding.productDiscountPercent.setVisibility(View.GONE);
                }
            }

        } else {
            if (imageModel.size() > 0) {
                String productImage = imageModel.get(0).getSrc();
                Picasso.get().load(productImage)
                        .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .into(holder.listLayoutBinding.productImage);
            }

            holder.listLayoutBinding.productTitle.setText(title);
            holder.listLayoutBinding.productRating.setText(rating);
            holder.listLayoutBinding.productSaleCount.setText(sale + " " + context.getString(R.string.sales));

            if (type.equals(AppConstants.PRODUCT_TYPE_VARIABLE)) {
                holder.listLayoutBinding.productSalePrice.setText(currencySymbol + basePrice);
                holder.listLayoutBinding.productRegularPrice.setVisibility(View.GONE);
                holder.listLayoutBinding.productDiscountPercent.setVisibility(View.GONE);
            } else if (type.equals(AppConstants.PRODUCT_TYPE_SIMPLE)) {
                if (salePrice != null && !salePrice.isEmpty()) {
                    int discountPercent = (int) Math.round((Float.parseFloat(salePrice) - Float.parseFloat(regularPrice)) / (Float.parseFloat(regularPrice) * .01));

                    holder.listLayoutBinding.productSalePrice.setText(currencySymbol + salePrice);
                    holder.listLayoutBinding.productRegularPrice.setText(currencySymbol + regularPrice);
                    holder.listLayoutBinding.productDiscountPercent.setText("-" + Math.abs(discountPercent) + AppConstants.PERCENTAGE_SYMBOLE);
                    holder.listLayoutBinding.productRegularPrice.setVisibility(View.VISIBLE);
                    holder.listLayoutBinding.productDiscountPercent.setVisibility(View.VISIBLE);
                } else {
                    holder.listLayoutBinding.productSalePrice.setText(currencySymbol + regularPrice);
                    holder.listLayoutBinding.productRegularPrice.setVisibility(View.GONE);
                    holder.listLayoutBinding.productDiscountPercent.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ProductListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemGridProductListLayoutBinding gridLayoutBinding;
        ItemLinearProductListLayoutBinding listLayoutBinding;

        ProductListViewHolder(ItemGridProductListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            gridLayoutBinding = layoutBinding;

            gridLayoutBinding.parentView.setOnClickListener(this);
        }

        ProductListViewHolder(ItemLinearProductListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            listLayoutBinding = layoutBinding;

            listLayoutBinding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
