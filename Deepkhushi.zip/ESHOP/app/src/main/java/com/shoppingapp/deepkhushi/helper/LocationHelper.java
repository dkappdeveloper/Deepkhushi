package com.shoppingapp.deepkhushi.helper;

import android.content.Context;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.customview.RotateProgressDialog;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;
import com.shoppingapp.deepkhushi.model.order.ZoneModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Created by Deepak Kumar on 03-May-19.
 */

public class LocationHelper {

    private static LocationHelper locationHelper = null;

    // create single instance
    public static LocationHelper getInstance() {

        if (locationHelper == null) {

            locationHelper = new LocationHelper();
        }
        return locationHelper;
    }

    private String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = context.getResources().openRawResource(R.raw.country_state_code);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public List<ZoneModel> getCountries(Context context) {
        List<ZoneModel> arrayList = new ArrayList<>();
        try {
            JSONObject jObj = new JSONObject(loadJSONFromAsset(context));
            JSONArray countryArry = jObj.getJSONArray("countries");

            for (int i = 0; i < countryArry.length(); i++) {
                JSONObject countryObj = countryArry.getJSONObject(i);
                String value = countryObj.getString("value");
                String name = countryObj.getString("name");

                arrayList.add(new ZoneModel(name, value));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return arrayList;
    }

    public List<ZoneModel> getFilteredCountries(Context context, String query) {
        List<ZoneModel> arrayList = new ArrayList<>();
        try {
            JSONObject jObj = new JSONObject(loadJSONFromAsset(context));
            JSONArray countryArry = jObj.getJSONArray("countries");

            for (int i = 0; i < countryArry.length(); i++) {
                JSONObject countryObj = countryArry.getJSONObject(i);
                String value = countryObj.getString("value");
                String name = countryObj.getString("name");

                if (!query.isEmpty() && name.startsWith(query)) {
                    arrayList.add(new ZoneModel(name, value));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return arrayList;
    }

    public List<ZoneModel> getStates(Context context, String code) {
        List<ZoneModel> arrayList = new ArrayList<>();
        try {
            JSONObject jObj = new JSONObject(loadJSONFromAsset(context));
            JSONObject jObj1 = jObj.getJSONObject("states");
            JSONArray stateArry = jObj1.getJSONArray(code);

            for (int i = 0; i < stateArry.length(); i++) {
                JSONObject stateObj = stateArry.getJSONObject(i);
                String value = stateObj.getString("value");
                String name = stateObj.getString("name");

                arrayList.add(new ZoneModel(name, value));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return arrayList;
    }

    public List<ZoneModel> getFilteredStates(Context context, String code, String query) {
        List<ZoneModel> arrayList = new ArrayList<>();
        try {
            JSONObject jObj = new JSONObject(loadJSONFromAsset(context));
            JSONObject jObj1 = jObj.getJSONObject("states");
            JSONArray stateArry = jObj1.getJSONArray(code);

            for (int i = 0; i < stateArry.length(); i++) {
                JSONObject stateObj = stateArry.getJSONObject(i);
                String value = stateObj.getString("value");
                String name = stateObj.getString("name");

                if (!query.isEmpty() && name.startsWith(query)) {
                    arrayList.add(new ZoneModel(name, value));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return arrayList;
    }


    public List<ZoneModel> getShippingCountries(Context context, List<LocationModel> countryList) {
        RotateProgressDialog progressDialog = new RotateProgressDialog(context);
        List<ZoneModel> arrayList = new ArrayList<>();

        progressDialog.show();
        for (LocationModel model : countryList) {
            arrayList.add(new ZoneModel(model.getCountryCode(), model.getCountryName()));
        }

        Set<ZoneModel> set = new TreeSet<>(new Comparator<ZoneModel>() {
            @Override
            public int compare(ZoneModel model1, ZoneModel model2) {
                if (model1.getName().equalsIgnoreCase(model2.getName()))
                    return 0;
                else
                    return 1;
            }
        });
        set.addAll(arrayList);
        progressDialog.dismiss();

        return new ArrayList<>(set);
    }

    public List<ZoneModel> getFilteredShippingCountries(Context context, List<LocationModel> countryList, String query) {
        RotateProgressDialog progressDialog = new RotateProgressDialog(context);
        List<ZoneModel> arrayList = new ArrayList<>();

        progressDialog.show();
        for (LocationModel model : countryList) {
            if (!query.isEmpty() && model.getCountryName().startsWith(query))
                arrayList.add(new ZoneModel(model.getCountryCode(), model.getCountryName()));
        }

        Set<ZoneModel> set = new TreeSet<>(new Comparator<ZoneModel>() {
            @Override
            public int compare(ZoneModel model1, ZoneModel model2) {
                if (model1.getName().equalsIgnoreCase(model2.getName()))
                    return 0;
                else
                    return 1;
            }
        });
        set.addAll(arrayList);
        progressDialog.dismiss();

        return new ArrayList<>(set);
    }

    public List<ZoneModel> getShippingStates(Context context, List<LocationModel> stateList, String countryCode) {
        RotateProgressDialog progressDialog = new RotateProgressDialog(context);
        List<ZoneModel> arrayList = new ArrayList<>();

        progressDialog.show();
        for (LocationModel model : stateList) {
            if (model.getCountryCode().equals(countryCode) && !model.getStateCode().isEmpty()) {
                arrayList.add(new ZoneModel(model.getStateCode(), model.getStateName()));
            }
        }

        progressDialog.dismiss();

        return arrayList;
    }

    public List<ZoneModel> getFilteredShippingStates(Context context, List<LocationModel> stateList, String countryCode, String query) {
        RotateProgressDialog progressDialog = new RotateProgressDialog(context);
        List<ZoneModel> arrayList = new ArrayList<>();

        progressDialog.show();
        for (LocationModel model : stateList) {
            if (!query.isEmpty() && model.getStateName().startsWith(query) && model.getCountryCode().equals(countryCode) && !model.getStateCode().isEmpty())
                arrayList.add(new ZoneModel(model.getStateCode(), model.getStateName()));
        }

        progressDialog.dismiss();

        return arrayList;
    }

/*    public String getCountryName(List<LocationModel> countryList, String countryCode) {

        for (LocationModel countryModel : countryList) {
            if (countryList.size() > 0 && countryModel.getCode().equals(countryCode))
                return countryModel.getName();
        }

        return "";
    }*/

/*    public String getStateName(List<LocationModel> countryList, String countryCode, String stateCode) {

        for (LocationModel countryModel : countryList) {
            if (countryList.size() > 0 && countryModel.getCode().equals(countryCode)) {
                for (DataStateModel stateModel : countryModel.getDataStateModels()) {
                    if (countryModel.getDataStateModels().size() > 0 && stateModel.getCode().equals(stateCode)) {
                        return stateModel.getName();
                    }
                }
            }
        }

        return "";
    }*/
}
