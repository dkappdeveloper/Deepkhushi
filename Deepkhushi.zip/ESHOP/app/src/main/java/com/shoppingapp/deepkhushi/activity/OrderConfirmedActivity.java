package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.ActivityOrderConfirmedLayoutBinding;
import com.shoppingapp.deepkhushi.helper.ADHelper;

/**
 * Created by Deepak Kumar on 23-May-19.
 */
public class OrderConfirmedActivity extends BaseActivity {

    ActivityOrderConfirmedLayoutBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();
        initListener();

        ADHelper.getInstance(getApplicationContext()).showFullScreenAd();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                startActivity(new Intent(OrderConfirmedActivity.this, HomeActivity.class));
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        startActivity(new Intent(OrderConfirmedActivity.this, HomeActivity.class));
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_order_confirmed_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_order_confirmed));
    }

    private void initListener() {
        binding.checkOrderStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(AppConstants.BUNDLE_FROM_CONFIRM_ORDER, true);
                startActivity(new Intent(OrderConfirmedActivity.this, MyOrdersActivity.class).putExtras(bundle));
                finish();
            }
        });
    }
}
