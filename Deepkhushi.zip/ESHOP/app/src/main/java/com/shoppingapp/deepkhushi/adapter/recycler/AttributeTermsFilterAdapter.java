package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemFilterAttributeTermsListLayoutBinding;
import com.shoppingapp.deepkhushi.listener.FilterItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductAttributeModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 06-Mar-19.
 */
public class AttributeTermsFilterAdapter extends RecyclerView.Adapter<AttributeTermsFilterAdapter.AttributeTermsFilterViewHolder> {

    private Context context;
    private List<ProductAttributeModel> arrayList;

    private FilterItemClickListener filterItemClickListener;

    public AttributeTermsFilterAdapter(Context context) {
        this.context = context;
    }

    public AttributeTermsFilterAdapter(Context context, List<ProductAttributeModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setFilterItemClickListener(FilterItemClickListener filterItemClickListener) {
        this.filterItemClickListener = filterItemClickListener;
    }

    @NonNull
    @Override
    public AttributeTermsFilterAdapter.AttributeTermsFilterViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new AttributeTermsFilterViewHolder((ItemFilterAttributeTermsListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_filter_attribute_terms_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AttributeTermsFilterAdapter.AttributeTermsFilterViewHolder holder, int position) {
        holder.binding.attributeTermsName.setText(arrayList.get(position).getName());
        manageItemSelection(holder, position);
    }

    private void manageItemSelection(AttributeTermsFilterViewHolder holder, int position) {
        boolean selected = arrayList.get(position).getSelected();
        if (selected) {
            holder.binding.attributeTermsName.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimary2));
            holder.binding.attributeTermsName.setTextColor(ContextCompat.getColor(context, R.color.colorWhite));
        } else {
            holder.binding.attributeTermsName.setBackgroundColor(ContextCompat.getColor(context, R.color.grayExtraLight));
            holder.binding.attributeTermsName.setTextColor(ContextCompat.getColor(context, R.color.colorBlack));
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class AttributeTermsFilterViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemFilterAttributeTermsListLayoutBinding binding;

        AttributeTermsFilterViewHolder(@NonNull ItemFilterAttributeTermsListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.getRoot().setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (filterItemClickListener != null)
                filterItemClickListener.onFilterItemClickGetPosition(arrayList.get(getAdapterPosition()).getId().toString(), getAdapterPosition());
        }
    }
}
