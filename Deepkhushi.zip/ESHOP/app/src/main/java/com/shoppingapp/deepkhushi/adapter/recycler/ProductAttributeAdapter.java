package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemProductAttributeListLayoutBinding;
import com.shoppingapp.deepkhushi.listener.ProductAttributeSelectedListener;
import com.shoppingapp.deepkhushi.model.product.AttributeModel;
import com.shoppingapp.deepkhushi.model.product.AttributeTermsModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Deepak Kumar on 17-Apr-19.
 */
public class ProductAttributeAdapter extends RecyclerView.Adapter<ProductAttributeAdapter.ProductAttributeViewHolder> {

    private Context context;
    private List<AttributeModel> arrayList;

    private ProductAttributeSelectedListener itemSelectedListener;

    public ProductAttributeAdapter(Context context) {
        this.context = context;
    }

    public ProductAttributeAdapter(Context context, List<AttributeModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemSelectedListener(ProductAttributeSelectedListener itemSelectedListener) {
        this.itemSelectedListener = itemSelectedListener;
    }

    @NonNull
    @Override
    public ProductAttributeAdapter.ProductAttributeViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new ProductAttributeViewHolder((ItemProductAttributeListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_product_attribute_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAttributeAdapter.ProductAttributeViewHolder holder, int position) {
        holder.binding.attributeName.setText(arrayList.get(position).getName());

        holder.termsList.clear();

        for (int i = 0; i < arrayList.get(position).getOptions().size(); i++) {
            AttributeTermsModel model = new AttributeTermsModel();
            model.setTermsName(arrayList.get(position).getOptions().get(i));
            holder.termsList.add(model);
        }

        holder.attributeTermsAdapter.notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ProductAttributeViewHolder extends RecyclerView.ViewHolder {

        ItemProductAttributeListLayoutBinding binding;

        ProductAttributeTermsAdapter attributeTermsAdapter;
        List<AttributeTermsModel> termsList;

        public ProductAttributeViewHolder(@NonNull ItemProductAttributeListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            termsList = new ArrayList<>();

            attributeTermsAdapter = new ProductAttributeTermsAdapter(context, termsList);
            binding.attributeTermsRecycler.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
            binding.attributeTermsRecycler.setAdapter(attributeTermsAdapter);
            binding.attributeTermsRecycler.setNestedScrollingEnabled(false);

            attributeTermsAdapter.setItemSelectedListener(new ProductAttributeSelectedListener() {
                @Override
                public void onProductAttributeSelected(int position, String term) {
                    for (AttributeTermsModel termsModel : termsList) {
                        termsModel.setSelected(false);
                    }
                    termsList.get(position).setSelected(true);
                    attributeTermsAdapter.notifyDataSetChanged();

                    if (itemSelectedListener != null)
                        itemSelectedListener.onProductAttributeSelected(getLayoutPosition(), term);
                }
            });
        }
    }
}


