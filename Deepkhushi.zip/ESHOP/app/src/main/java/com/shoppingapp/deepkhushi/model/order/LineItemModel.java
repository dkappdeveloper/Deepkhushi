
package com.shoppingapp.deepkhushi.model.order;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LineItemModel implements Parcelable {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("product_id")
    @Expose
    private Integer productId;
    @SerializedName("variation_id")
    @Expose
    private Integer variationId;
    @SerializedName("quantity")
    @Expose
    private Integer quantity;
    @SerializedName("tax_class")
    @Expose
    private String taxClass;
    @SerializedName("subtotal")
    @Expose
    private String subtotal;
    @SerializedName("subtotal_tax")
    @Expose
    private String subtotalTax;
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("total_tax")
    @Expose
    private String totalTax;
    @Expose
    private String sku;
    @SerializedName("price")
    @Expose
    private Double price;

    private String productImage;
    private String currency;
    private String currencySymbol;

    public final static Creator<LineItemModel> CREATOR = new Creator<LineItemModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public LineItemModel createFromParcel(Parcel in) {
            return new LineItemModel(in);
        }

        public LineItemModel[] newArray(int size) {
            return (new LineItemModel[size]);
        }

    };

    protected LineItemModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.productId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.variationId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.quantity = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.taxClass = ((String) in.readValue((String.class.getClassLoader())));
        this.subtotal = ((String) in.readValue((String.class.getClassLoader())));
        this.subtotalTax = ((String) in.readValue((String.class.getClassLoader())));
        this.total = ((String) in.readValue((String.class.getClassLoader())));
        this.totalTax = ((String) in.readValue((String.class.getClassLoader())));
        this.sku = ((String) in.readValue((String.class.getClassLoader())));
        this.price = ((Double) in.readValue((Double.class.getClassLoader())));
        this.productImage = ((String) in.readValue((String.class.getClassLoader())));
        this.currency = ((String) in.readValue((String.class.getClassLoader())));
        this.currencySymbol = ((String) in.readValue((String.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     */
    public LineItemModel() {
    }

    /**
     * @param total
     * @param subtotalTax
     * @param sku
     * @param subtotal
     * @param productId
     * @param id
     * @param variationId
     * @param taxClass
     * @param price
     * @param name
     * @param quantity
     * @param totalTax
     */
    public LineItemModel(Integer id, String name, Integer productId, Integer variationId, Integer quantity, String taxClass, String subtotal, String subtotalTax, String total, String totalTax, String sku, Double price) {
        super();
        this.id = id;
        this.name = name;
        this.productId = productId;
        this.variationId = variationId;
        this.quantity = quantity;
        this.taxClass = taxClass;
        this.subtotal = subtotal;
        this.subtotalTax = subtotalTax;
        this.total = total;
        this.totalTax = totalTax;
        this.sku = sku;
        this.price = price;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getVariationId() {
        return variationId;
    }

    public void setVariationId(Integer variationId) {
        this.variationId = variationId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getTaxClass() {
        return taxClass;
    }

    public void setTaxClass(String taxClass) {
        this.taxClass = taxClass;
    }

    public String getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(String subtotal) {
        this.subtotal = subtotal;
    }

    public String getSubtotalTax() {
        return subtotalTax;
    }

    public void setSubtotalTax(String subtotalTax) {
        this.subtotalTax = subtotalTax;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(String totalTax) {
        this.totalTax = totalTax;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(name);
        dest.writeValue(productId);
        dest.writeValue(variationId);
        dest.writeValue(quantity);
        dest.writeValue(taxClass);
        dest.writeValue(subtotal);
        dest.writeValue(subtotalTax);
        dest.writeValue(total);
        dest.writeValue(totalTax);
        dest.writeValue(sku);
        dest.writeValue(price);
        dest.writeValue(productImage);
        dest.writeValue(currency);
        dest.writeValue(currencySymbol);
    }

    public int describeContents() {
        return 0;
    }
}
