package com.shoppingapp.deepkhushi.database.loader;

import android.content.Context;
import android.os.AsyncTask;

import com.shoppingapp.deepkhushi.database.helpers.AppDb;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Created by Sahidul Islam on 15-Nov-19.
 */
public class LocationLoader extends AsyncTask<Object, Void, Object> {

    private DbLoaderInterface dbLoaderInterface;
    private WeakReference<Context> weakContext;

    public LocationLoader(Context context) {
        weakContext = new WeakReference<Context>(context);
    }

    public void setDbLoaderInterface(DbLoaderInterface dbLoaderInterface) {
        this.dbLoaderInterface = dbLoaderInterface;
    }

    @Override
    protected Object doInBackground(Object... object) {
        Context context = weakContext.get();
        int query = (int) object[0];

        if (query == DaoHelper.INSERT) {
            LocationModel insertModel = (LocationModel) object[1];
            AppDb.getAppDb(context).getLocationDao().insert(insertModel);
        } else if (query == DaoHelper.ROW_COUNT) {
            return AppDb.getAppDb(context).getLocationDao().getRowCount();
        } else if (query == DaoHelper.FETCH_ALL) {
            return AppDb.getAppDb(context).getLocationDao().getAll();
        } else if (query == DaoHelper.FETCH_CONTINENT) {
            return AppDb.getAppDb(context).getLocationDao().getContinent((String) object[1]);
        } else if (query == DaoHelper.FETCH_COUNTRY) {
            return AppDb.getAppDb(context).getLocationDao().getCountry((String) object[1]);
        } else if (query == DaoHelper.FETCH_STATE) {
            return AppDb.getAppDb(context).getLocationDao().getState((String) object[1]);
        } else if (query == DaoHelper.INSERT_ALL) {
            ArrayList<LocationModel> locationModels = (ArrayList<LocationModel>) object[1];
            AppDb.getAppDb(context).getLocationDao().insertAll(locationModels);
        } else if (query == DaoHelper.DELETE_ALL) {
            AppDb.getAppDb(context).getLocationDao().deleteAllContinent();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);

        if (dbLoaderInterface != null) {
            dbLoaderInterface.onFinished(o);
        }
    }
}
