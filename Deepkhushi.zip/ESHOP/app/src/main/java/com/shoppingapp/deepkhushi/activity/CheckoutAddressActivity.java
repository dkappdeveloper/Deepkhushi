package com.shoppingapp.deepkhushi.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.CheckoutLocationAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.LocationLoader;
import com.shoppingapp.deepkhushi.databinding.ActivityCheckoutAddressBinding;
import com.shoppingapp.deepkhushi.databinding.DialogCheckoutLocationListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DataMapingHelper;
import com.shoppingapp.deepkhushi.helper.LocationHelper;
import com.shoppingapp.deepkhushi.listener.CheckoutLocationSelectedListener;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.model.order.ZoneModel;
import com.shoppingapp.deepkhushi.model.shipping.ShippingLocationModel;
import com.shoppingapp.deepkhushi.model.shipping.ShippingZoneModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 27-Apr-19.
 */

public class CheckoutAddressActivity extends BaseActivity {

    ActivityCheckoutAddressBinding binding;
    DialogCheckoutLocationListLayoutBinding checkoutLocationBinding;

    private HashMap<String, String> billingMap, shippingMap;
    private List<HashMap> orderNotes;
    private List<ProductCartModel> orderList;

    private String totalAmount;
    private Boolean updateAddress = false, buyNow = false;

    private List<ZoneModel> countryList, stateList;
    private List<LocationModel> locationList;
    private List<ShippingZoneModel> zoneList;

    private String billingCountryCode, billingStateCode;
    private String shippingContinentCode, shippingCountryCode, shippingSateCode;
    private String billingCountry, billingState, shippingCountry, shippingSate;
    private String billingFirstName, billingLastName, billingEmail, billingPhone, billingAddress, billingCity, billingZip;
    private String shippingFirstName, shippingLastName, shippingAddress, shippingCity, shippingZip;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        loadAddressData();
        loadDataToView();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {
        locationList = new ArrayList<>();
        zoneList = new ArrayList<>();

        countryList = new ArrayList<>();
        stateList = new ArrayList<>();
        billingMap = new HashMap<>();
        shippingMap = new HashMap<>();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {

            if (bundle.containsKey(AppConstants.BUNDLE_ORDER_NOTES))
                orderNotes = (List<HashMap>) bundle.getSerializable(AppConstants.BUNDLE_ORDER_NOTES);

            if (bundle.containsKey(AppConstants.BUNDLE_CHECKOUT_PRODUCTS))
                orderList = (List<ProductCartModel>) bundle.getSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS);

            if (bundle.containsKey(AppConstants.BUNDLE_PAYMENT_TOTAL))
                totalAmount = bundle.getString(AppConstants.BUNDLE_PAYMENT_TOTAL);

            if (bundle.containsKey(AppConstants.BUNDLE_BUY_NOW))
                buyNow = bundle.getBoolean(AppConstants.BUNDLE_BUY_NOW);

            if (bundle.containsKey(AppConstants.BUNDLE_UPDATE_ADDRESS))
                updateAddress = bundle.getBoolean(AppConstants.BUNDLE_UPDATE_ADDRESS);
        }

        loadLocationList();
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_checkout_address);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_address));

        if (updateAddress) {
            binding.saveAddress.setText(getString(R.string.save_address));
        } else {
            binding.saveAddress.setText(getString(R.string.save_proceed));
        }
    }

    private void initListener() {
        binding.billingCountryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadCountryDialog(AppConstants.CHECKOUT_ADDRESS_BILLING);
            }
        });

        binding.shippingCountryLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadCountryDialog(AppConstants.CHECKOUT_ADDRESS_SHIPPING);
            }
        });

        binding.billingStateLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (billingCountryCode != null && !billingCountryCode.isEmpty()) {
                    loadStateDialog(billingCountryCode, AppConstants.CHECKOUT_ADDRESS_BILLING);
                } else {
                    AppHelper.showShortSnack(getApplicationContext(), binding.saveAddress, getString(R.string.msg_country));
                }
            }
        });

        binding.shippingStateLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (shippingCountryCode != null && !shippingCountryCode.isEmpty()) {
                    loadStateDialog(shippingCountryCode, AppConstants.CHECKOUT_ADDRESS_SHIPPING);
                } else {
                    AppHelper.showShortSnack(getApplicationContext(), binding.saveAddress, getString(R.string.msg_country));
                }
            }
        });

        binding.shipBillingAddress.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    binding.inputShippingFirstName.setText(binding.inputBillingFirstName.getText());
                    binding.inputShippingLastName.setText(binding.inputBillingLastName.getText());
                    binding.inputShippingAdress.setText(binding.inputBillingAdress.getText());
                    binding.inputShippingCountry.setText(binding.inputBillingCountry.getText());
                    binding.inputShippingState.setText(binding.inputBillingState.getText());
                    binding.inputShippingCity.setText(binding.inputBillingCity.getText());
                    binding.inputShippingZipPostal.setText(binding.inputBillingZipPostal.getText());

                    shippingCountryCode = billingCountryCode;
                    shippingSateCode = billingStateCode;
                }
            }
        });

        binding.saveAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValidInput()) {
                    saveAddress();

                    if (updateAddress) {
                        AppHelper.showShortToast(getApplicationContext(), getString(R.string.saved_address));
                        finish();
                    } else {
                        loadShippingZones();
                    }
                }
            }
        });
    }

    private Boolean isValidInput() {
        billingFirstName = binding.inputBillingFirstName.getText().toString();
        billingLastName = binding.inputBillingLastName.getText().toString();
        billingEmail = binding.inputBillingEmail.getText().toString();
        billingPhone = binding.inputBillingPhone.getText().toString();
        billingAddress = binding.inputBillingAdress.getText().toString();
        billingCountry = binding.inputBillingCountry.getText().toString();
        billingState = binding.inputBillingState.getText().toString();
        billingCity = binding.inputBillingCity.getText().toString();
        billingZip = binding.inputBillingZipPostal.getText().toString();

        shippingFirstName = binding.inputShippingFirstName.getText().toString();
        shippingLastName = binding.inputShippingLastName.getText().toString();
        shippingAddress = binding.inputShippingAdress.getText().toString();
        shippingCountry = binding.inputShippingCountry.getText().toString();
        shippingSate = binding.inputShippingState.getText().toString();
        shippingCity = binding.inputShippingCity.getText().toString();
        shippingZip = binding.inputShippingZipPostal.getText().toString();

        if (billingFirstName.isEmpty()) {
            binding.inputBillingFirstName.setError(getString(R.string.msg_first_name));
            binding.inputBillingFirstName.requestFocus();
            return false;
        } else if (billingLastName.isEmpty()) {
            binding.inputBillingLastName.setError(getString(R.string.msg_last_name));
            binding.inputBillingLastName.requestFocus();
            return false;
        } else if (billingEmail.isEmpty()) {
            binding.inputBillingEmail.setError(getString(R.string.msg_email));
            binding.inputBillingEmail.requestFocus();
            return false;
        } else if (billingPhone.isEmpty()) {
            binding.inputBillingPhone.setError(getString(R.string.msg_phone));
            binding.inputBillingPhone.requestFocus();
            return false;
        } else if (billingAddress.isEmpty()) {
            binding.inputBillingAdress.setError(getString(R.string.msg_address));
            binding.inputBillingAdress.requestFocus();
            return false;
        } else if (billingCountryCode == null || billingCountryCode.isEmpty()) {
            loadCountryDialog(AppConstants.CHECKOUT_ADDRESS_BILLING);
            AppHelper.showShortSnack(getApplicationContext(), binding.saveAddress, getString(R.string.msg_country));
            return false;
        } else if (billingStateCode == null || billingStateCode.isEmpty()) {
            loadStateDialog(billingCountryCode, AppConstants.CHECKOUT_ADDRESS_BILLING);
            AppHelper.showShortSnack(getApplicationContext(), binding.saveAddress, getString(R.string.msg_state));
            return false;
        } else if (billingCity.isEmpty()) {
            binding.inputBillingCity.setError(getString(R.string.msg_city));
            binding.inputBillingCity.requestFocus();
            return false;
        } else if (billingZip.isEmpty()) {
            binding.inputBillingZipPostal.setError(getString(R.string.msg_zip_code));
            binding.inputBillingZipPostal.requestFocus();
            return false;
        } else if (shippingFirstName.isEmpty()) {
            binding.inputShippingFirstName.setError(getString(R.string.msg_first_name));
            binding.inputShippingFirstName.requestFocus();
            return false;
        } else if (shippingLastName.isEmpty()) {
            binding.inputShippingLastName.setError(getString(R.string.msg_last_name));
            binding.inputShippingLastName.requestFocus();
            return false;
        } else if (shippingAddress.isEmpty()) {
            binding.inputShippingAdress.setError(getString(R.string.msg_address));
            binding.inputShippingAdress.requestFocus();
            return false;
        } else if (shippingCountryCode == null || shippingCountryCode.isEmpty()) {
            loadCountryDialog(AppConstants.CHECKOUT_ADDRESS_SHIPPING);
            AppHelper.showShortSnack(getApplicationContext(), binding.saveAddress, getString(R.string.msg_country));
            return false;
        } else if (shippingSateCode == null || shippingSateCode.isEmpty()) {
            loadStateDialog(shippingCountryCode, AppConstants.CHECKOUT_ADDRESS_SHIPPING);
            AppHelper.showShortSnack(getApplicationContext(), binding.saveAddress, getString(R.string.msg_state));
            return false;
        } else if (shippingCity.isEmpty()) {
            binding.inputShippingCity.setError(getString(R.string.msg_city));
            binding.inputShippingCity.requestFocus();
            return false;
        } else if (shippingZip.isEmpty()) {
            binding.inputShippingZipPostal.setError(getString(R.string.msg_zip_code));
            binding.inputShippingZipPostal.requestFocus();
            return false;
        } else {
            return true;
        }
    }

    private void saveAddress() {
        AppPreference.getInstance(this).setString(PrefKey.FIRST_NAME_BILL, billingFirstName);
        AppPreference.getInstance(this).setString(PrefKey.LAST_NAME_BILL, billingLastName);
        AppPreference.getInstance(this).setString(PrefKey.EMAIL_BILL, billingEmail);
        AppPreference.getInstance(this).setString(PrefKey.PHONE_BILL, billingPhone);
        AppPreference.getInstance(this).setString(PrefKey.ADDRESS_BILL, billingAddress);
        AppPreference.getInstance(this).setString(PrefKey.CITY_BILL, billingCity);
        AppPreference.getInstance(this).setString(PrefKey.COUNTRY_BILL, billingCountry);
        AppPreference.getInstance(this).setString(PrefKey.COUNTRY_CODE_BILL, billingCountryCode);
        AppPreference.getInstance(this).setString(PrefKey.STATE_BILL, billingState);
        AppPreference.getInstance(this).setString(PrefKey.STATE_CODE_BILL, billingStateCode);
        AppPreference.getInstance(this).setString(PrefKey.POST_CODE_BILL, billingZip);

        AppPreference.getInstance(this).setString(PrefKey.FIRST_NAME_SHIP, shippingFirstName);
        AppPreference.getInstance(this).setString(PrefKey.LAST_NAME_SHIP, shippingLastName);
        AppPreference.getInstance(this).setString(PrefKey.ADDRESS_SHIP, shippingAddress);
        AppPreference.getInstance(this).setString(PrefKey.CITY_SHIP, shippingCity);
        AppPreference.getInstance(this).setString(PrefKey.COUNTRY_NAME_SHIP, shippingCountry);
        AppPreference.getInstance(this).setString(PrefKey.COUNTRY_CODE_SHIP, shippingCountryCode);
        AppPreference.getInstance(this).setString(PrefKey.STATE_NAME_SHIP, shippingSate);
        AppPreference.getInstance(this).setString(PrefKey.STATE_CODE_SHIP, shippingSateCode);
        AppPreference.getInstance(this).setString(PrefKey.POST_CODE_SHIP, shippingZip);

        AppPreference.getInstance(this).setBoolean(PrefKey.SHIP_TO_BILLING, binding.shipBillingAddress.isChecked());
    }

    private void loadAddressData() {
        billingFirstName = AppPreference.getInstance(this).getString(PrefKey.FIRST_NAME_BILL);
        billingLastName = AppPreference.getInstance(this).getString(PrefKey.LAST_NAME_BILL);
        billingEmail = AppPreference.getInstance(this).getString(PrefKey.EMAIL_BILL);
        billingPhone = AppPreference.getInstance(this).getString(PrefKey.PHONE_BILL);
        billingAddress = AppPreference.getInstance(this).getString(PrefKey.ADDRESS_BILL);
        billingCity = AppPreference.getInstance(this).getString(PrefKey.CITY_BILL);
        billingCountry = AppPreference.getInstance(this).getString(PrefKey.COUNTRY_BILL);
        billingCountryCode = AppPreference.getInstance(this).getString(PrefKey.COUNTRY_CODE_BILL);
        billingState = AppPreference.getInstance(this).getString(PrefKey.STATE_BILL);
        billingStateCode = AppPreference.getInstance(this).getString(PrefKey.STATE_CODE_BILL);
        billingZip = AppPreference.getInstance(this).getString(PrefKey.POST_CODE_BILL);

        shippingFirstName = AppPreference.getInstance(this).getString(PrefKey.FIRST_NAME_SHIP);
        shippingLastName = AppPreference.getInstance(this).getString(PrefKey.LAST_NAME_SHIP);
        shippingAddress = AppPreference.getInstance(this).getString(PrefKey.ADDRESS_SHIP);
        shippingCity = AppPreference.getInstance(this).getString(PrefKey.CITY_SHIP);
        shippingCountry = AppPreference.getInstance(this).getString(PrefKey.COUNTRY_NAME_SHIP);
        shippingCountryCode = AppPreference.getInstance(this).getString(PrefKey.COUNTRY_CODE_SHIP);
        shippingSate = AppPreference.getInstance(this).getString(PrefKey.STATE_NAME_SHIP);
        shippingSateCode = AppPreference.getInstance(this).getString(PrefKey.STATE_CODE_SHIP);
        shippingZip = AppPreference.getInstance(this).getString(PrefKey.POST_CODE_SHIP);
    }

    private void loadDataToView() {
        binding.inputBillingFirstName.setText(billingFirstName);
        binding.inputBillingLastName.setText(billingLastName);
        binding.inputBillingEmail.setText(billingEmail);
        binding.inputBillingPhone.setText(billingPhone);
        binding.inputBillingAdress.setText(billingAddress);
        binding.inputBillingCountry.setText(billingCountry);
        binding.inputBillingState.setText(billingState);
        binding.inputBillingCity.setText(billingCity);
        binding.inputBillingZipPostal.setText(billingZip);

        binding.inputShippingFirstName.setText(shippingFirstName);
        binding.inputShippingLastName.setText(shippingLastName);
        binding.inputShippingAdress.setText(shippingAddress);
        binding.inputShippingCountry.setText(shippingCountry);
        binding.inputShippingState.setText(shippingSate);
        binding.inputShippingCity.setText(shippingCity);
        binding.inputShippingZipPostal.setText(shippingZip);

        Boolean shipToBilling = AppPreference.getInstance(this).getBoolean(PrefKey.SHIP_TO_BILLING);
        binding.shipBillingAddress.setChecked(shipToBilling);
    }

    private void loadLocationList() {
        progressDialog.show();
        LocationLoader loader = new LocationLoader(this);
        loader.execute(DaoHelper.FETCH_ALL);
        loader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {
                    locationList.clear();
                    locationList.addAll((List<LocationModel>) object);
                } else {
                    AppHelper.showShortToast(getApplicationContext(), getString(R.string.failed_database_msg));
                    finish();
                }
                progressDialog.dismiss();
            }
        });
    }

    private void loadCountryDialog(int addressType) {
        final Dialog countryDialog = new Dialog(this);
        countryDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        checkoutLocationBinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.dialog_checkout_location_list_layout, null, false);
        countryDialog.setContentView(checkoutLocationBinding.getRoot());
        countryDialog.setCanceledOnTouchOutside(true);

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(countryDialog.getWindow().getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -2;
        countryDialog.getWindow().setAttributes(layoutParams);

        checkoutLocationBinding.dialogTitle.setText(getString(R.string.country));
        final CheckoutLocationAdapter locationAdapter = new CheckoutLocationAdapter(this, countryList, addressType);
        checkoutLocationBinding.locationRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        checkoutLocationBinding.locationRecycler.setAdapter(locationAdapter);

        countryList.clear();
        countryList.addAll(LocationHelper.getInstance().getShippingCountries(this, locationList));

        locationAdapter.notifyDataSetChanged();
        locationAdapter.setItemSelectedListener(new CheckoutLocationSelectedListener() {
            @Override
            public void onCheckoutLocationSelected(int position, int addressType) {

                switch (addressType) {
                    case AppConstants.CHECKOUT_ADDRESS_BILLING:
                        binding.inputBillingCountry.setText(AppHelper.fromHtml(countryList.get(position).getName()));
                        billingCountryCode = countryList.get(position).getValue();
                        break;
                    case AppConstants.CHECKOUT_ADDRESS_SHIPPING:
                        binding.inputShippingCountry.setText(AppHelper.fromHtml(countryList.get(position).getName()));
                        shippingCountryCode = countryList.get(position).getValue();
                        loadShippingContinent(shippingCountryCode);
                        break;
                }
                countryDialog.dismiss();
            }
        });

        checkoutLocationBinding.cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countryDialog.dismiss();
            }
        });

        checkoutLocationBinding.searchLocationName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence sequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence sequence, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable sequence) {
                String query = sequence.toString().trim();

                countryList.clear();
                if (query.length() > 0) {
                    countryList.addAll(LocationHelper.getInstance().getFilteredShippingCountries(CheckoutAddressActivity.this, locationList, query));
                } else {
                    countryList.addAll(LocationHelper.getInstance().getShippingCountries(CheckoutAddressActivity.this, locationList));
                }
                locationAdapter.notifyDataSetChanged();
            }
        });

        countryDialog.show();
    }

    private void loadStateDialog(final String countryCode, int addressType) {
        final Dialog stateDialog = new Dialog(this);
        stateDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        checkoutLocationBinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.dialog_checkout_location_list_layout, null, false);
        stateDialog.setContentView(checkoutLocationBinding.getRoot());
        stateDialog.setCanceledOnTouchOutside(true);

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(stateDialog.getWindow().getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -2;
        stateDialog.getWindow().setAttributes(layoutParams);

        checkoutLocationBinding.dialogTitle.setText(getString(R.string.state));
        final CheckoutLocationAdapter locationAdapter = new CheckoutLocationAdapter(this, stateList, addressType);
        checkoutLocationBinding.locationRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        checkoutLocationBinding.locationRecycler.setAdapter(locationAdapter);

        stateList.clear();
        stateList.addAll(LocationHelper.getInstance().getShippingStates(CheckoutAddressActivity.this, locationList, countryCode));

        if (stateList.size() == 0) {
            stateList.add(new ZoneModel("OT", "Other"));
        }
        locationAdapter.notifyDataSetChanged();

        locationAdapter.setItemSelectedListener(new CheckoutLocationSelectedListener() {
            @Override
            public void onCheckoutLocationSelected(int position, int addressType) {

                switch (addressType) {
                    case AppConstants.CHECKOUT_ADDRESS_BILLING:
                        binding.inputBillingState.setText(AppHelper.fromHtml(stateList.get(position).getName()));
                        billingStateCode = stateList.get(position).getValue();
                        break;
                    case AppConstants.CHECKOUT_ADDRESS_SHIPPING:
                        binding.inputShippingState.setText(AppHelper.fromHtml(stateList.get(position).getName()));
                        shippingSateCode = stateList.get(position).getValue();
                        break;
                }
                stateDialog.dismiss();
            }
        });

        checkoutLocationBinding.cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stateDialog.dismiss();
            }
        });

        checkoutLocationBinding.searchLocationName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence sequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence sequence, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable sequence) {
                String query = sequence.toString().trim();

                stateList.clear();
                if (query.length() > 0) {
                    stateList.addAll(LocationHelper.getInstance().getFilteredShippingStates(CheckoutAddressActivity.this, locationList, countryCode, query));
                } else {
                    stateList.addAll(LocationHelper.getInstance().getShippingStates(CheckoutAddressActivity.this, locationList, countryCode));
                }

                if (stateList.size() == 0) {
                    stateList.add(new ZoneModel("OT", "Other"));
                }
                locationAdapter.notifyDataSetChanged();
            }
        });

        stateDialog.show();
    }

    private void loadShippingContinent(String countryCode) {
        if (countryCode != null && !countryCode.isEmpty()) {
            LocationLoader loader = new LocationLoader(this);
            loader.execute(DaoHelper.FETCH_COUNTRY, countryCode);
            loader.setDbLoaderInterface(new DbLoaderInterface() {
                @Override
                public void onFinished(Object object) {
                    LocationModel model = (LocationModel) object;
                    shippingContinentCode = model.getContinentCode();

                }
            });
        }
    }

    private int getShippingStateMethod() {
        int method = 0;
        for (ShippingZoneModel zoneModel : zoneList) {
            if (zoneModel.getLocationList().size() > 0) {
                for (ShippingLocationModel locationModel : zoneModel.getLocationList()) {
                    if (locationModel.getType().equals(AppConstants.SHIPPING_TYPE_STATE) && locationModel.getCode().equals(shippingSateCode)) {
                        method = zoneModel.getId();
                    }
                }
            }
        }

        return method;
    }

    private int getShippingCountryMethod() {
        int method = 0;
        for (ShippingZoneModel zoneModel : zoneList) {
            if (zoneModel.getLocationList().size() > 0) {
                for (ShippingLocationModel locationModel : zoneModel.getLocationList()) {
                    if (locationModel.getType().equals(AppConstants.SHIPPING_TYPE_COUNTRY) && locationModel.getCode().equals(shippingCountryCode)) {
                        method = zoneModel.getId();
                    }
                }
            }
        }

        return method;
    }

    private int getShippingContinentMethod() {
        int method = 0;
        for (ShippingZoneModel zoneModel : zoneList) {
            if (zoneModel.getLocationList().size() > 0) {
                for (ShippingLocationModel locationModel : zoneModel.getLocationList()) {
                    if (locationModel.getType().equals(AppConstants.SHIPPING_TYPE_CONTINENT) && locationModel.getCode().equals(shippingContinentCode)) {
                        method = zoneModel.getId();
                    }
                }
            }
        }

        return method;
    }

    private void loadShippingZones() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            ApiClient.getInstance().getApiInterface().getShippingZones().enqueue(new Callback<List<ShippingZoneModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ShippingZoneModel>> call, @NonNull Response<List<ShippingZoneModel>> response) {
                    if (response.body() != null) {
                        if (response.body().size() > 1) {
                            zoneList.clear();
                            zoneList.addAll(response.body());
                            loadShippingLocations(1);
                        } else {
                            loadOrderView();
                        }
                    } else {
                        AppHelper.showShortToast(CheckoutAddressActivity.this, getString(R.string.failed_msg));
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<List<ShippingZoneModel>> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(CheckoutAddressActivity.this, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadShippingLocations(final int position) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
              progressDialog.show();
            int zoneId = zoneList.get(position).getId();

            ApiClient.getInstance().getApiInterface().getShippingZoneLocations(zoneId).enqueue(new Callback<List<ShippingLocationModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ShippingLocationModel>> call, @NonNull Response<List<ShippingLocationModel>> response) {
                    if (response.body() != null) {
                        List<ShippingLocationModel> zoneLocationList = new ArrayList<>(response.body());

                        if (zoneLocationList.size() > 0) {
                            ShippingZoneModel zoneModel = zoneList.get(position);
                            zoneModel.setLocationList(zoneLocationList);
                            zoneList.set(position, zoneModel);
                        }

                        if (zoneList.size() == position + 1) {
                            progressDialog.dismiss();
                            loadOrderView();
                        } else {
                            progressDialog.dismiss();                
                            loadShippingLocations(position + 1);
                        }
                       
                    } else {
                        progressDialog.dismiss();
                        AppHelper.showShortToast(CheckoutAddressActivity.this, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ShippingLocationModel>> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(CheckoutAddressActivity.this, getString(R.string.failed_msg));
                }
            });
        }

        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadOrderView() {
        int shippingZone = 0;

        if (zoneList.size() > 1) {
            int stateMethod = getShippingStateMethod();
            int countryMethod = getShippingCountryMethod();
            int continentMethod = getShippingContinentMethod();

            if (stateMethod != 0) {
                shippingZone = stateMethod;
            } else if (countryMethod != 0) {
                shippingZone = countryMethod;
            } else if (continentMethod != 0) {
                shippingZone = continentMethod;
            }
        }

        billingMap = DataMapingHelper.getOrderBillingAddress(billingFirstName, billingLastName,
                billingEmail, billingPhone, billingAddress, billingCountry, billingCountryCode, billingState, billingStateCode, billingCity, billingZip);

        shippingMap = DataMapingHelper.getOrderShippingAddress(shippingFirstName, shippingLastName, shippingAddress,
                shippingCountry, shippingCountryCode, shippingSate, shippingSateCode, shippingCity, shippingZip);

        Bundle bundle = new Bundle();
        bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
        bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) orderList);
        bundle.putSerializable(AppConstants.BUNDLE_BILLING_ADDRESS, billingMap);
        bundle.putSerializable(AppConstants.BUNDLE_SHIPPING_ADDRESS, shippingMap);
        bundle.putBoolean(AppConstants.BUNDLE_BUY_NOW, buyNow);
        bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, totalAmount);
        bundle.putInt(AppConstants.BUNDLE_SHIPPING_ZONE, shippingZone);
        startActivity(new Intent(CheckoutAddressActivity.this,PlaceOrderActivity.class).putExtras(bundle));
    }
}
