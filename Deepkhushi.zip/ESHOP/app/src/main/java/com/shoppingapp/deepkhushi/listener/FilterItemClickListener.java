package com.shoppingapp.deepkhushi.listener;

/**
 * Created by Deepak Kumar on 07-Mar-19.
 */
public interface FilterItemClickListener {
    void onFilterItemClickGetPosition(String id, int position);
}
