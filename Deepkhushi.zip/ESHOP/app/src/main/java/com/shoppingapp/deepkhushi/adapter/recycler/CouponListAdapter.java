package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemCouponLayoutBinding;
import com.shoppingapp.deepkhushi.helper.DateHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductCouponModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 19-Nov-19.
 */
public class CouponListAdapter extends RecyclerView.Adapter<CouponListAdapter.CouponListViewHolder> {

    private Context context;
    private List<ProductCouponModel> arrayList;

    private ItemClickListener itemClickListener;

    public CouponListAdapter(Context context) {
        this.context = context;
    }

    public CouponListAdapter(Context context, List<ProductCouponModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public CouponListAdapter.CouponListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new CouponListViewHolder((ItemCouponLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_coupon_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CouponListAdapter.CouponListViewHolder holder, int position) {
        String discountAmount = arrayList.get(position).getAmount();
        String discountCode = arrayList.get(position).getCode();
        String discountType = arrayList.get(position).getDiscountType();
        String description = arrayList.get(position).getDescription();
        String expireDate = arrayList.get(position).getDateExpires();

        if (discountType.equals(AppConstants.COUPON_TYPE_PERCENT)) {
            double percent = Double.parseDouble(discountAmount);
            holder.binding.discountAmount.setText(String.format("%.0f", percent) + "%");
            holder.binding.discountType.setText(context.getString(R.string.cart_discount));
        } else if (discountType.equals(AppConstants.COUPON_TYPE_FIXED_CART)) {
            String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
            holder.binding.discountAmount.setText(currencySymbol + discountAmount);
            holder.binding.discountType.setText(context.getString(R.string.cart_discount));
        } else if (discountType.equals(AppConstants.COUPON_TYPE_FIXED_PRODUCT)) {
            String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
            holder.binding.discountAmount.setText(currencySymbol + discountAmount);
            holder.binding.discountType.setText(context.getString(R.string.fixed_product_discount));
        }

        holder.binding.discountCoupon.setText(discountCode);

        if (!description.isEmpty()) {
            holder.binding.discountDescription.setText(description);
            holder.binding.discountDescription.setVisibility(View.VISIBLE);
        } else {
            holder.binding.discountDescription.setVisibility(View.GONE);
        }

        if (expireDate != null && !expireDate.isEmpty()) {
            expireDate = DateHelper.formateISODate(expireDate);
            holder.binding.discountExpireDate.setText(context.getString(R.string.expires_on) + " " + expireDate);
            holder.binding.discountExpireDate.setVisibility(View.VISIBLE);
        } else {
            holder.binding.discountExpireDate.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class CouponListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemCouponLayoutBinding binding;

        public CouponListViewHolder(@NonNull ItemCouponLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());

            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
