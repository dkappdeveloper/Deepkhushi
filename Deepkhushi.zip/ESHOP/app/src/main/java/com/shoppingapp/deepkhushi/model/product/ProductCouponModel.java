
package com.shoppingapp.deepkhushi.model.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ProductCouponModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("amount")
    @Expose
    private String amount;
    @SerializedName("date_created")
    @Expose
    private String dateCreated;
    @SerializedName("date_created_gmt")
    @Expose
    private String dateCreatedGmt;
    @SerializedName("date_modified")
    @Expose
    private String dateModified;
    @SerializedName("date_modified_gmt")
    @Expose
    private String dateModifiedGmt;
    @SerializedName("discount_type")
    @Expose
    private String discountType;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("date_expires")
    @Expose
    private String dateExpires;
    @SerializedName("date_expires_gmt")
    @Expose
    private String dateExpiresGmt;
    @SerializedName("usage_count")
    @Expose
    private Integer usageCount;
    @SerializedName("individual_use")
    @Expose
    private Boolean individualUse;
    @SerializedName("product_ids")
    @Expose
    private List<Integer> productIds = new ArrayList<>();
    @SerializedName("excluded_product_ids")
    @Expose
    private List<Integer> excludedProductIds = new ArrayList<>();
    @SerializedName("usage_limit")
    @Expose
    private Integer usageLimit;
    @SerializedName("usage_limit_per_user")
    @Expose
    private Integer usageLimitPerUser;
    @SerializedName("limit_usage_to_x_items")
    @Expose
    private Integer limitUsageToXItems;
    @SerializedName("free_shipping")
    @Expose
    private Boolean freeShipping;
    @SerializedName("product_categories")
    @Expose
    private List<Integer> productCategories = new ArrayList<>();
    @SerializedName("excluded_product_categories")
    @Expose
    private List<Integer> excludedProductCategories = new ArrayList<>();
    @SerializedName("exclude_sale_items")
    @Expose
    private Boolean excludeSaleItems;
    @SerializedName("minimum_amount")
    @Expose
    private String minimumAmount;
    @SerializedName("maximum_amount")
    @Expose
    private String maximumAmount;
    @SerializedName("email_restrictions")
    @Expose
    private List<Integer> emailRestrictions = new ArrayList<>();
    @SerializedName("used_by")
    @Expose
    private List<Integer> usedBy = new ArrayList<>();
    public final static Creator<ProductCouponModel> CREATOR = new Creator<ProductCouponModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public ProductCouponModel createFromParcel(Parcel in) {
            return new ProductCouponModel(in);
        }

        public ProductCouponModel[] newArray(int size) {
            return (new ProductCouponModel[size]);
        }

    }
    ;

    protected ProductCouponModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.amount = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCreated = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCreatedGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.dateModified = ((String) in.readValue((String.class.getClassLoader())));
        this.dateModifiedGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.discountType = ((String) in.readValue((String.class.getClassLoader())));
        this.description = ((String) in.readValue((String.class.getClassLoader())));
        this.dateExpires = ((String) in.readValue((String.class.getClassLoader())));
        this.dateExpiresGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.usageCount = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.individualUse = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        in.readList(this.productIds, (Integer.class.getClassLoader()));
        in.readList(this.excludedProductIds, (Integer.class.getClassLoader()));
        this.usageLimit = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.usageLimitPerUser = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.limitUsageToXItems = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.freeShipping = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        in.readList(this.productCategories, (Integer.class.getClassLoader()));
        in.readList(this.excludedProductCategories, (Integer.class.getClassLoader()));
        this.excludeSaleItems = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        this.minimumAmount = ((String) in.readValue((String.class.getClassLoader())));
        this.maximumAmount = ((String) in.readValue((String.class.getClassLoader())));
        in.readList(this.emailRestrictions, (Integer.class.getClassLoader()));
        in.readList(this.usedBy, (Integer.class.getClassLoader()));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public ProductCouponModel() {
    }

    /**
     * 
     * @param code
     * @param maximumAmount
     * @param description
     * @param usageLimitPerUser
     * @param dateCreated
     * @param freeShipping
     * @param excludeSaleItems
     * @param dateExpires
     * @param excludedProductCategories
     * @param discountType
     * @param id
     * @param excludedProductIds
     * @param usedBy
     * @param amount
     * @param dateCreatedGmt
     * @param individualUse
     * @param dateModifiedGmt
     * @param usageLimit
     * @param limitUsageToXItems
     * @param dateExpiresGmt
     * @param dateModified
     * @param usageCount
     * @param productCategories
     * @param productIds
     * @param minimumAmount
     * @param emailRestrictions
     */
    public ProductCouponModel(Integer id, String code, String amount, String dateCreated, String dateCreatedGmt, String dateModified, String dateModifiedGmt, String discountType, String description, String dateExpires, String dateExpiresGmt, Integer usageCount, Boolean individualUse, List<Integer> productIds, List<Integer> excludedProductIds, Integer usageLimit, Integer usageLimitPerUser, Integer limitUsageToXItems, Boolean freeShipping, List<Integer> productCategories, List<Integer> excludedProductCategories, Boolean excludeSaleItems, String minimumAmount, String maximumAmount, List<Integer> emailRestrictions, List<Integer> usedBy) {
        super();
        this.id = id;
        this.code = code;
        this.amount = amount;
        this.dateCreated = dateCreated;
        this.dateCreatedGmt = dateCreatedGmt;
        this.dateModified = dateModified;
        this.dateModifiedGmt = dateModifiedGmt;
        this.discountType = discountType;
        this.description = description;
        this.dateExpires = dateExpires;
        this.dateExpiresGmt = dateExpiresGmt;
        this.usageCount = usageCount;
        this.individualUse = individualUse;
        this.productIds = productIds;
        this.excludedProductIds = excludedProductIds;
        this.usageLimit = usageLimit;
        this.usageLimitPerUser = usageLimitPerUser;
        this.limitUsageToXItems = limitUsageToXItems;
        this.freeShipping = freeShipping;
        this.productCategories = productCategories;
        this.excludedProductCategories = excludedProductCategories;
        this.excludeSaleItems = excludeSaleItems;
        this.minimumAmount = minimumAmount;
        this.maximumAmount = maximumAmount;
        this.emailRestrictions = emailRestrictions;
        this.usedBy = usedBy;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getDateCreatedGmt() {
        return dateCreatedGmt;
    }

    public void setDateCreatedGmt(String dateCreatedGmt) {
        this.dateCreatedGmt = dateCreatedGmt;
    }

    public String getDateModified() {
        return dateModified;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public String getDateModifiedGmt() {
        return dateModifiedGmt;
    }

    public void setDateModifiedGmt(String dateModifiedGmt) {
        this.dateModifiedGmt = dateModifiedGmt;
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDateExpires() {
        return dateExpires;
    }

    public void setDateExpires(String dateExpires) {
        this.dateExpires = dateExpires;
    }

    public String getDateExpiresGmt() {
        return dateExpiresGmt;
    }

    public void setDateExpiresGmt(String dateExpiresGmt) {
        this.dateExpiresGmt = dateExpiresGmt;
    }

    public Integer getUsageCount() {
        return usageCount;
    }

    public void setUsageCount(Integer usageCount) {
        this.usageCount = usageCount;
    }

    public Boolean getIndividualUse() {
        return individualUse;
    }

    public void setIndividualUse(Boolean individualUse) {
        this.individualUse = individualUse;
    }

    public List<Integer> getProductIds() {
        return productIds;
    }

    public void setProductIds(List<Integer> productIds) {
        this.productIds = productIds;
    }

    public List<Integer> getExcludedProductIds() {
        return excludedProductIds;
    }

    public void setExcludedProductIds(List<Integer> excludedProductIds) {
        this.excludedProductIds = excludedProductIds;
    }

    public Integer getUsageLimit() {
        return usageLimit;
    }

    public void setUsageLimit(Integer usageLimit) {
        this.usageLimit = usageLimit;
    }

    public Integer getUsageLimitPerUser() {
        return usageLimitPerUser;
    }

    public void setUsageLimitPerUser(Integer usageLimitPerUser) {
        this.usageLimitPerUser = usageLimitPerUser;
    }

    public Integer getLimitUsageToXItems() {
        return limitUsageToXItems;
    }

    public void setLimitUsageToXItems(Integer limitUsageToXItems) {
        this.limitUsageToXItems = limitUsageToXItems;
    }

    public Boolean getFreeShipping() {
        return freeShipping;
    }

    public void setFreeShipping(Boolean freeShipping) {
        this.freeShipping = freeShipping;
    }

    public List<Integer> getProductCategories() {
        return productCategories;
    }

    public void setProductCategories(List<Integer> productCategories) {
        this.productCategories = productCategories;
    }

    public List<Integer> getExcludedProductCategories() {
        return excludedProductCategories;
    }

    public void setExcludedProductCategories(List<Integer> excludedProductCategories) {
        this.excludedProductCategories = excludedProductCategories;
    }

    public Boolean getExcludeSaleItems() {
        return excludeSaleItems;
    }

    public void setExcludeSaleItems(Boolean excludeSaleItems) {
        this.excludeSaleItems = excludeSaleItems;
    }

    public String getMinimumAmount() {
        return minimumAmount;
    }

    public void setMinimumAmount(String minimumAmount) {
        this.minimumAmount = minimumAmount;
    }

    public String getMaximumAmount() {
        return maximumAmount;
    }

    public void setMaximumAmount(String maximumAmount) {
        this.maximumAmount = maximumAmount;
    }

    public List<Integer> getEmailRestrictions() {
        return emailRestrictions;
    }

    public void setEmailRestrictions(List<Integer> emailRestrictions) {
        this.emailRestrictions = emailRestrictions;
    }

    public List<Integer> getUsedBy() {
        return usedBy;
    }

    public void setUsedBy(List<Integer> usedBy) {
        this.usedBy = usedBy;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(code);
        dest.writeValue(amount);
        dest.writeValue(dateCreated);
        dest.writeValue(dateCreatedGmt);
        dest.writeValue(dateModified);
        dest.writeValue(dateModifiedGmt);
        dest.writeValue(discountType);
        dest.writeValue(description);
        dest.writeValue(dateExpires);
        dest.writeValue(dateExpiresGmt);
        dest.writeValue(usageCount);
        dest.writeValue(individualUse);
        dest.writeList(productIds);
        dest.writeList(excludedProductIds);
        dest.writeValue(usageLimit);
        dest.writeValue(usageLimitPerUser);
        dest.writeValue(limitUsageToXItems);
        dest.writeValue(freeShipping);
        dest.writeList(productCategories);
        dest.writeList(excludedProductCategories);
        dest.writeValue(excludeSaleItems);
        dest.writeValue(minimumAmount);
        dest.writeValue(maximumAmount);
        dest.writeList(emailRestrictions);
        dest.writeList(usedBy);
    }

    public int describeContents() {
        return  0;
    }

}
