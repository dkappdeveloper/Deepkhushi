package com.shoppingapp.deepkhushi.database.helpers;


import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

class Migrator {

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE " + DaoHelper.PRODUCT_CART_TBL + " ADD COLUMN " + DaoHelper.COLUMN_CATEGORY_ID + " TEXT");
            database.execSQL("ALTER TABLE " + DaoHelper.PRODUCT_CART_TBL + " ADD COLUMN " + DaoHelper.COLUMN_IS_SALE + " INTEGER");

            database.execSQL("CREATE TABLE " + DaoHelper.LOCATION_TBL + "(" + DaoHelper.COLUMN_AUTO_ID + " INTEGER NOT NULL PRIMARY KEY, "
                    + DaoHelper.COLUMN_CONTINENT_CODE + " TEXT, " + DaoHelper.COLUMN_CONTINENT_NAME + " TEXT, "
                    + DaoHelper.COLUMN_COUNTRY_CODE + " TEXT, " + DaoHelper.COLUMN_COUNTRY_NAME + " TEXT, "
                    + DaoHelper.COLUMN_STATE_CODE + " TEXT, " + DaoHelper.COLUMN_STATE_NAME + " TEXT )");

        }
    };

/*    static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE " + DaoHelper.PRODUCT_CART_TBL + " ADD COLUMN " + DaoHelper.COLUMN_PRICE_CURRENCY);
        }
    };*/

}