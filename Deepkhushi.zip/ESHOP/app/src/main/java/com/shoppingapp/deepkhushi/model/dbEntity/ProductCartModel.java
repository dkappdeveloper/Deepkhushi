package com.shoppingapp.deepkhushi.model.dbEntity;


import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.shoppingapp.deepkhushi.database.converters.IntegerArrayConverter;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Md Sahidul Islam on 12-May-19.
 */

@Entity(tableName = DaoHelper.PRODUCT_CART_TBL)
public class ProductCartModel implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = DaoHelper.COLUMN_AUTO_ID)
    private int autoId;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_ID)
    private int productId;

    @TypeConverters({IntegerArrayConverter.class})
    @ColumnInfo(name = DaoHelper.COLUMN_CATEGORY_ID)
    private List<Integer> categoryIds = new ArrayList<>();

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_NAME)
    private String productName;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_PRICE)
    private String productPrice;

    @ColumnInfo(name = DaoHelper.COLUMN_TOTAL_PRICE)
    private String totalPrice;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_QUANTITY)
    private String productQuantity;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_ATTRIBUTE)
    private String productAttribute;

    @ColumnInfo(name = DaoHelper.COLUMN_PRODUCT_IMAGE)
    private String productImage;

    @ColumnInfo(name = DaoHelper.COLUMN_IS_SALE)
    private Boolean isSale;


    @Ignore
    public ProductCartModel() {
    }

    public ProductCartModel(int productId, List<Integer> categoryIds, String productName, String productPrice, String totalPrice,
                            String productQuantity, String productAttribute, String productImage, Boolean isSale) {
        this.productId = productId;
        this.categoryIds = categoryIds;
        this.productName = productName;
        this.productPrice = productPrice;
        this.totalPrice = totalPrice;
        this.productQuantity = productQuantity;
        this.productAttribute = productAttribute;
        this.productImage = productImage;
        this.isSale = isSale;
    }

    protected ProductCartModel(Parcel in) {
        autoId = in.readInt();
        productId = in.readInt();

        categoryIds = new ArrayList<>();
        in.readList(categoryIds, Integer.class.getClassLoader());

        productName = in.readString();
        productPrice = in.readString();
        totalPrice = in.readString();
        productQuantity = in.readString();
        productAttribute = in.readString();
        productImage = in.readString();

        isSale = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(autoId);
        dest.writeInt(productId);
        dest.writeList(categoryIds);
        dest.writeString(productName);
        dest.writeString(productPrice);
        dest.writeString(totalPrice);
        dest.writeString(productQuantity);
        dest.writeString(productAttribute);
        dest.writeString(productImage);
        dest.writeByte((byte) (isSale ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ProductCartModel> CREATOR = new Creator<ProductCartModel>() {
        @Override
        public ProductCartModel createFromParcel(Parcel in) {
            return new ProductCartModel(in);
        }

        @Override
        public ProductCartModel[] newArray(int size) {
            return new ProductCartModel[size];
        }
    };

    public int getAutoId() {
        return autoId;
    }

    public void setAutoId(int autoId) {
        this.autoId = autoId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public List<Integer> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Integer> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public String getProductAttribute() {
        return productAttribute;
    }

    public void setProductAttribute(String productAttribute) {
        this.productAttribute = productAttribute;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public Boolean getSale() {
        return isSale;
    }

    public void setSale(Boolean sale) {
        isSale = sale;
    }
}
