package com.shoppingapp.deepkhushi.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.OrderProductListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.LocationLoader;
import com.shoppingapp.deepkhushi.databinding.ActivityOrderDetailLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.model.data.DataCurrencyModel;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.model.order.LineItemModel;
import com.shoppingapp.deepkhushi.model.order.OrderModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 24-May-19.
 */

public class OrderDetailActivity extends BaseActivity {

    ActivityOrderDetailLayoutBinding binding;

    OrderProductListAdapter orderProductListAdapter;

    private OrderModel orderModel;
    private List<ProductCartModel> cartList;
    private String currencyCode, currencySymbol;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        initRecycler();
        loadOrderCurrency();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {
        cartList = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {

            if (bundle.containsKey(AppConstants.BUNDLE_ORDER_DETAIL))
                orderModel = bundle.getParcelable(AppConstants.BUNDLE_ORDER_DETAIL);
        }
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_order_detail_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_order_detail));
    }

    private void initListener() {
        binding.cancelOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelOrder();
            }
        });
    }

    private void initRecycler() {
        orderProductListAdapter = new OrderProductListAdapter(this, cartList);
        binding.checkoutProducts.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        binding.checkoutProducts.setNestedScrollingEnabled(false);
        binding.checkoutProducts.setAdapter(orderProductListAdapter);
    }

    private void loadOrderView() {
        String billFirstName = orderModel.getBilling().getFirstName();
        String billLastName = orderModel.getBilling().getLastName();
        String billEmail = orderModel.getBilling().getEmail();
        String billPhone = orderModel.getBilling().getPhone();
        String billAddress = orderModel.getBilling().getAddress1();
        String billCity = orderModel.getBilling().getCity();
        String billPostCode = orderModel.getBilling().getPostcode();

        String billState = orderModel.getBilling().getState();
        String billCountry = orderModel.getBilling().getCountry();
        loadBillingCountryState(billState, billCountry);

        binding.billingFullname.setText(AppHelper.fromHtml(getString(R.string.order_full_name) + billFirstName + ", " + billLastName));
        binding.billingPhone.setText(AppHelper.fromHtml(getString(R.string.order_phone) + billPhone));
        binding.billingEmail.setText(AppHelper.fromHtml(getString(R.string.order_email) + billEmail));
        binding.billingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + billState + ", " + billCountry));
        binding.billingPostalAddress.setText(AppHelper.fromHtml(getString(R.string.order_address) + billAddress + ", " + billCity + ", " + billPostCode));


        String shipFirstName = orderModel.getShipping().getFirstName();
        String shipLastName = orderModel.getShipping().getLastName();
        String shipAddress = orderModel.getShipping().getAddress1();
        String shipCity = orderModel.getShipping().getCity();
        String shipPostCode = orderModel.getShipping().getPostcode();

        String shipState = orderModel.getShipping().getState();
        String shipCountry = orderModel.getShipping().getCountry();
        loadShippingCountryState(shipState, shipCountry);

        binding.shippingFullname.setText(AppHelper.fromHtml(getString(R.string.order_full_name) + shipFirstName + ", " + shipLastName));
        binding.shippingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + shipState + ", " + shipCountry));
        binding.shippingPostalAddress.setText(AppHelper.fromHtml(getString(R.string.order_address) + shipAddress + ", " + shipCity + ", " + shipPostCode));

        String shippingTotal = orderModel.getShippingTotal();
        if (shippingTotal != null && !shippingTotal.isEmpty()) {
            binding.shippingPrice.setText(currencySymbol + shippingTotal);
            binding.shippingTotalLayout.setVisibility(View.VISIBLE);
        } else {
            binding.shippingTotalLayout.setVisibility(View.GONE);
        }

        binding.checkoutTotal.setText("Total: " + currencySymbol + orderModel.getTotal());
        binding.orderDetailId.setText(String.valueOf(orderModel.getId()));
        binding.orderStatus.setText(getOrderStatus());
        binding.paymentMethod.setText(orderModel.getPaymentMethodTitle());

        if (orderModel.getStatus().equals(AppConstants.ORDER_STATUS_PENDING)
                || orderModel.getStatus().equals(AppConstants.ORDER_STATUS_PROCESSING)
                || orderModel.getStatus().equals(AppConstants.ORDER_STATUS_ONHOLD)) {
            binding.cancelOrder.setVisibility(View.VISIBLE);
        } else {
            binding.cancelOrder.setVisibility(View.GONE);
        }
    }

    private void loadBillingCountryState(String billState, String billCountry) {
        if (billState != null && !billState.isEmpty()) {
            LocationLoader loader = new LocationLoader(this);
            loader.execute(DaoHelper.FETCH_STATE, billState);
            loader.setDbLoaderInterface(new DbLoaderInterface() {
                @Override
                public void onFinished(Object object) {
                    LocationModel model = (LocationModel) object;
                    binding.billingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + model.getStateName() + ", " + model.getCountryName()));
                }
            });
        } else {
            LocationLoader loader = new LocationLoader(this);
            loader.execute(DaoHelper.FETCH_COUNTRY, billCountry);
            loader.setDbLoaderInterface(new DbLoaderInterface() {
                @Override
                public void onFinished(Object object) {
                    LocationModel model = (LocationModel) object;
                    binding.billingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + model.getCountryName()));
                }
            });
        }
    }

    private void loadShippingCountryState(String shipState, String shipCountry) {
        if (shipState != null && !shipState.isEmpty()) {
            LocationLoader loader = new LocationLoader(this);
            loader.execute(DaoHelper.FETCH_STATE, shipState);
            loader.setDbLoaderInterface(new DbLoaderInterface() {
                @Override
                public void onFinished(Object object) {
                    LocationModel model = (LocationModel) object;
                    binding.shippingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + model.getStateName() + ", " + model.getCountryName()));
                }
            });
        } else {
            LocationLoader loader = new LocationLoader(this);
            loader.execute(DaoHelper.FETCH_COUNTRY, shipCountry);
            loader.setDbLoaderInterface(new DbLoaderInterface() {
                @Override
                public void onFinished(Object object) {
                    LocationModel model = (LocationModel) object;
                    binding.shippingZone.setText(AppHelper.fromHtml(getString(R.string.order_country_state) + model.getCountryName()));
                }
            });
        }
    }

    private void loadOrderCurrency() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            ApiClient.getInstance().getApiInterface().getCurrencySymbol(orderModel.getCurrency()).enqueue(new Callback<DataCurrencyModel>() {
                @Override
                public void onResponse(@NonNull Call<DataCurrencyModel> call, @NonNull Response<DataCurrencyModel> response) {
                    if (response.body() != null) {
                        currencyCode = response.body().getCode();
                        currencySymbol = AppHelper.fromHtml(response.body().getSymbol()).toString();

                        loadOrderItems();

                    } else {
                        AppHelper.showShortSnack(getApplicationContext(), binding.parentView, getString(R.string.server_failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<DataCurrencyModel> call, @NonNull Throwable t) {
                    AppHelper.showLongSnack(getApplicationContext(), binding.parentView, getString(R.string.server_failed_msg), true);
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadOrderItems() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            for (final LineItemModel lineItemModel : orderModel.getLineItemModels()) {
                ApiClient.getInstance().getApiInterface().getProductDetail(lineItemModel.getProductId()).enqueue(new Callback<ProductModel>() {
                    @Override
                    public void onResponse(@NonNull Call<ProductModel> call, @NonNull Response<ProductModel> response) {
                        if (response.body() != null) {
                            String productImage = response.body().getProductImageModels().get(0).getSrc();

                            ProductCartModel cartModel = new ProductCartModel();
                            cartModel.setProductId(lineItemModel.getProductId());
                            cartModel.setProductName(lineItemModel.getName());
                            cartModel.setProductPrice(currencySymbol + lineItemModel.getPrice());
                            cartModel.setTotalPrice(currencySymbol + lineItemModel.getTotal());
                            cartModel.setProductQuantity(String.valueOf(lineItemModel.getQuantity()));
                            cartModel.setProductImage(productImage);

                            cartList.add(cartModel);

                            if (orderModel.getLineItemModels().size() == cartList.size()) {
                                orderProductListAdapter.notifyDataSetChanged();
                                loadOrderView();

                                binding.shimmerOrderDetail.shimmerLayout.setVisibility(View.GONE);
                                binding.orderDetail.setVisibility(View.VISIBLE);
                            } else {
                                binding.orderDetail.setVisibility(View.GONE);
                                binding.shimmerOrderDetail.shimmerLayout.setVisibility(View.VISIBLE);
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ProductModel> call, @NonNull Throwable t) {

                    }
                });
            }
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private String getOrderStatus() {
        String orderStatus = orderModel.getStatus();

        switch (orderStatus) {
            case AppConstants.ORDER_STATUS_PENDING:
                orderStatus = getString(R.string.order_status_pending);
                break;
            case AppConstants.ORDER_STATUS_PROCESSING:
                orderStatus = getString(R.string.order_status_processing);
                break;
            case AppConstants.ORDER_STATUS_ONHOLD:
                orderStatus = getString(R.string.order_status_onhold);
                break;
            case AppConstants.ORDER_STATUS_COMPLETED:
                orderStatus = getString(R.string.order_status_completed);
                break;
            case AppConstants.ORDER_STATUS_CANCELLED:
                orderStatus = getString(R.string.order_status_cancelled);
                break;
            case AppConstants.ORDER_STATUS_REFUNDED:
                orderStatus = getString(R.string.order_status_refunded);
                break;
            case AppConstants.ORDER_STATUS_FAILED:
                orderStatus = getString(R.string.order_status_failed);
                break;
        }

        return orderStatus;
    }

    private void cancelOrder() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            Integer orderId = orderModel.getId();
            HashMap<String, String> cancelOrder = ApiRequests.buildCancelOrder();

            ApiClient.getInstance().getApiInterface().cancelOrder(orderId, cancelOrder).enqueue(new Callback<OrderModel>() {
                @Override
                public void onResponse(@NonNull Call<OrderModel> call, @NonNull Response<OrderModel> response) {
                    if (response.body() != null) {
                        AppHelper.showShortToast(context, getString(R.string.order_cancelled));
                        finish();
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }

                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<OrderModel> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    progressDialog.dismiss();
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }
}
