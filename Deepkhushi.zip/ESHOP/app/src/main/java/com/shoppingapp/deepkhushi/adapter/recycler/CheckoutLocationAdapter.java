package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemCheckoutLocationListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.CheckoutLocationSelectedListener;
import com.shoppingapp.deepkhushi.model.order.ZoneModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 03-May-19.
 */
public class CheckoutLocationAdapter extends RecyclerView.Adapter<CheckoutLocationAdapter.CheckoutLocationViewHolder> {

    private Context context;
    private List<ZoneModel> arrayList;
    private int addressType;

    private CheckoutLocationSelectedListener selectedListener;

    public CheckoutLocationAdapter() {
    }

    public CheckoutLocationAdapter(Context context, List<ZoneModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public CheckoutLocationAdapter(Context context, List<ZoneModel> arrayList, int addressType) {
        this.context = context;
        this.arrayList = arrayList;
        this.addressType = addressType;
    }

    public void setItemSelectedListener(CheckoutLocationSelectedListener selectedListener) {
        this.selectedListener = selectedListener;
    }

    @NonNull
    @Override
    public CheckoutLocationAdapter.CheckoutLocationViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new CheckoutLocationViewHolder((ItemCheckoutLocationListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_checkout_location_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CheckoutLocationAdapter.CheckoutLocationViewHolder holder, int position) {
        holder.binding.locationName.setText(AppHelper.fromHtml(arrayList.get(position).getName()));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class CheckoutLocationViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemCheckoutLocationListLayoutBinding binding;

        CheckoutLocationViewHolder(@NonNull ItemCheckoutLocationListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (selectedListener != null)
                selectedListener.onCheckoutLocationSelected(getAdapterPosition(), addressType);
        }
    }
}
