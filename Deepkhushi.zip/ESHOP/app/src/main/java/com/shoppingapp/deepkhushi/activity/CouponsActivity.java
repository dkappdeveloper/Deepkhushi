package com.shoppingapp.deepkhushi.activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.CouponListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.ActivityMyCouponLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductCouponModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 19-Nov-19.
 */

public class CouponsActivity extends BaseActivity {

    ActivityMyCouponLayoutBinding binding;
    CouponListAdapter couponAdapter;

    private List<ProductCouponModel> couponList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            if (bundle.containsKey(AppConstants.BUNDLE_COUPON_LIST))
                couponList = (List<ProductCouponModel>) bundle.getSerializable(AppConstants.BUNDLE_COUPON_LIST);
        }
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_coupon_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_my_coupon));

        initRecyclerView();
    }

    private void initListener() {
        couponAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                String couponCode = couponList.get(position).getCode();
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText(getString(R.string.coupon), couponCode);
                clipboard.setPrimaryClip(clip);
                AppHelper.showShortToast(CouponsActivity.this, getString(R.string.copied_clipboard));
            }
        });
    }

    private void initRecyclerView() {
        couponAdapter = new CouponListAdapter(this, couponList);
        binding.couponRecycler.setLayoutManager(new LinearLayoutManager(this));
        binding.couponRecycler.setAdapter(couponAdapter);

        if (couponList.size() > 0) {
            binding.couponRecycler.setVisibility(View.VISIBLE);
            binding.emptyListLayout.setVisibility(View.GONE);
        } else {
            binding.couponRecycler.setVisibility(View.GONE);
            binding.emptyListLayout.setVisibility(View.VISIBLE);
        }
    }
}
