package com.shoppingapp.deepkhushi.activity;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceScreen;

import com.shoppingapp.deepkhushi.BuildConfig;
import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ActivityAppSettingsLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.facebook.login.LoginManager;

/**
 * Created by Deepak Kumar on 15-May-19.
 */
public class AppSettingsActivity extends BaseActivity {

    ActivityAppSettingsLayoutBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_app_settings_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_settings));
        getSupportFragmentManager().beginTransaction().replace(R.id.preference_settings, new AppPreferenceFragment()).commit();
    }

    public static class AppPreferenceFragment extends PreferenceFragmentCompat {

        PreferenceScreen preferenceScreen;
        Preference logoutPref;
        Preference versionPref;
        ListPreference languagePreference;

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            addPreferencesFromResource(R.xml.settings_preference);

            initVars();
            initView();
            initListener();
        }

        private void initVars() {
        }

        private void initView() {
            preferenceScreen = getPreferenceScreen();
            versionPref = getPreferenceManager().findPreference(getString(R.string.pref_app_version));
            logoutPref = getPreferenceManager().findPreference(getString(R.string.pref_logout));
            languagePreference = (ListPreference) getPreferenceManager().findPreference(getString(R.string.pref_language));

            int languageValue = AppPreference.getInstance(getActivity()).getInteger(getActivity().getResources().getString(R.string.pref_language));
            String languageCode = getResources().getStringArray(R.array.app_locality_entries)[languageValue];
            languagePreference.setSummary(languageCode);
            languagePreference.setValue(String.valueOf(languageValue));

            String versionName = BuildConfig.VERSION_NAME;
            versionPref.setSummary("v" + versionName);

            Boolean isLoggedIn = AppPreference.getInstance(getActivity()).getBoolean(PrefKey.SIGNED_IN);
            if (isLoggedIn) {
                preferenceScreen.addPreference(logoutPref);
            } else {
                preferenceScreen.removePreference(logoutPref);
            }
        }

        private void initListener() {
            languagePreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    AppPreference.getInstance(getActivity()).setInteger(getActivity().getResources().getString(R.string.pref_language), Integer.parseInt(String.valueOf(newValue)));
                    AppHelper.restartApplicaion(getActivity());
                    return false;
                }
            });

            logoutPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    LoginManager.getInstance().logOut();
                    AppPreference.getInstance(getActivity()).logOutUser();
                    AppHelper.showShortToast(getActivity(), getActivity().getResources().getString(R.string.logout_success));
                    return true;
                }
            });
        }
    }
}
