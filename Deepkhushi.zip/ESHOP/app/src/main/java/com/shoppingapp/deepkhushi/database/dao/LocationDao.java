package com.shoppingapp.deepkhushi.database.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sahidul Islam on 15-Nov-19.
 */
@Dao
public interface LocationDao {

    @Insert
    void insert(LocationModel locationModel);

    @Insert
    void insertAll(ArrayList<LocationModel> locationModels);

    @Query("SELECT COUNT(" + DaoHelper.COLUMN_AUTO_ID + ") FROM " + DaoHelper.LOCATION_TBL)
    int getRowCount();

    @Query("SELECT * FROM " + DaoHelper.LOCATION_TBL + " ORDER BY " + DaoHelper.COLUMN_COUNTRY_NAME + " ASC")
    List<LocationModel> getAll();

    @Query("SELECT * FROM " + DaoHelper.LOCATION_TBL + " WHERE " + DaoHelper.COLUMN_CONTINENT_CODE + " = :continentCode LIMIT 1")
    LocationModel getContinent(String continentCode);

    @Query("SELECT * FROM " + DaoHelper.LOCATION_TBL + " WHERE " + DaoHelper.COLUMN_COUNTRY_CODE + " = :countryCode LIMIT 1")
    LocationModel getCountry(String countryCode);

    @Query("SELECT * FROM " + DaoHelper.LOCATION_TBL + " WHERE " + DaoHelper.COLUMN_STATE_CODE + " = :stateCode LIMIT 1")
    LocationModel getState(String stateCode);

    @Query("DELETE FROM " + DaoHelper.LOCATION_TBL)
    void deleteAllContinent();

    @Delete
    void delete(LocationModel locationModel);
}
