package com.shoppingapp.deepkhushi.model.product;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Md Sahidul Islam on 23-Feb-19.
 */
public class ProductSearchModel implements Parcelable {

    private int page;
    private int perPage;
    private int tagId;

    private String categoryId;
    private String orderBy;  //Date,Price,Alphabet
    private String order;  //ASC or DESC
    private String dateAfter;  //newest result after a date
    private String attribute;  //Barnd, Color, Size
    private String attributeTerm;  //Blue, Black, L, M

    private String featured;

    private String searchKey;
    private String minPrice;
    private String maxPrice;

    public ProductSearchModel() {
    }

    protected ProductSearchModel(Parcel in) {
        page = in.readInt();
        perPage = in.readInt();
        tagId = in.readInt();
        categoryId = in.readString();
        orderBy = in.readString();
        order = in.readString();
        dateAfter = in.readString();
        attribute = in.readString();
        attributeTerm = in.readString();
        featured = in.readString();
        searchKey = in.readString();
        minPrice = in.readString();
        maxPrice = in.readString();
    }

    public static final Creator<ProductSearchModel> CREATOR = new Creator<ProductSearchModel>() {
        @Override
        public ProductSearchModel createFromParcel(Parcel in) {
            return new ProductSearchModel(in);
        }

        @Override
        public ProductSearchModel[] newArray(int size) {
            return new ProductSearchModel[size];
        }
    };

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPerPage() {
        return perPage;
    }

    public void setPerPage(int perPage) {
        this.perPage = perPage;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getDateAfter() {
        return dateAfter;
    }

    public void setDateAfter(String dateAfter) {
        this.dateAfter = dateAfter;
    }

    public int getTagId() {
        return tagId;
    }

    public void setTagId(int tagId) {
        this.tagId = tagId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getAttributeTerm() {
        return attributeTerm;
    }

    public void setAttributeTerm(String attributeTerm) {
        this.attributeTerm = attributeTerm;
    }

    public String getFeatured() {
        return featured;
    }

    public void setFeatured(String featured) {
        this.featured = featured;
    }

    public String getSearchKey() {
        return searchKey;
    }

    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }

    public String getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(String minPrice) {
        this.minPrice = minPrice;
    }

    public String getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(String maxPrice) {
        this.maxPrice = maxPrice;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeInt(page);
        dest.writeInt(perPage);
        dest.writeInt(tagId);
        dest.writeString(categoryId);
        dest.writeString(orderBy);
        dest.writeString(order);
        dest.writeString(dateAfter);
        dest.writeString(attribute);
        dest.writeString(attributeTerm);
        dest.writeString(featured);
        dest.writeString(searchKey);
        dest.writeString(minPrice);
        dest.writeString(maxPrice);
    }
}
