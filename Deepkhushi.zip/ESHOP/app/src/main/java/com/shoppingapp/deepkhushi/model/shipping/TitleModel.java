
package com.shoppingapp.deepkhushi.model.shipping;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TitleModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("label")
    @Expose
    private String label;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("value")
    @Expose
    private String value;
    @SerializedName("default")
    @Expose
    private String _default;
    @SerializedName("tip")
    @Expose
    private String tip;
    @SerializedName("placeholder")
    @Expose
    private String placeholder;
    public final static Creator<TitleModel> CREATOR = new Creator<TitleModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public TitleModel createFromParcel(Parcel in) {
            return new TitleModel(in);
        }

        public TitleModel[] newArray(int size) {
            return (new TitleModel[size]);
        }

    }
    ;

    protected TitleModel(Parcel in) {
        this.id = ((String) in.readValue((String.class.getClassLoader())));
        this.label = ((String) in.readValue((String.class.getClassLoader())));
        this.description = ((String) in.readValue((String.class.getClassLoader())));
        this.type = ((String) in.readValue((String.class.getClassLoader())));
        this.value = ((String) in.readValue((String.class.getClassLoader())));
        this._default = ((String) in.readValue((String.class.getClassLoader())));
        this.tip = ((String) in.readValue((String.class.getClassLoader())));
        this.placeholder = ((String) in.readValue((String.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public TitleModel() {
    }

    /**
     * 
     * @param _default
     * @param description
     * @param tip
     * @param id
     * @param label
     * @param placeholder
     * @param type
     * @param value
     */
    public TitleModel(String id, String label, String description, String type, String value, String _default, String tip, String placeholder) {
        super();
        this.id = id;
        this.label = label;
        this.description = description;
        this.type = type;
        this.value = value;
        this._default = _default;
        this.tip = tip;
        this.placeholder = placeholder;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDefault() {
        return _default;
    }

    public void setDefault(String _default) {
        this._default = _default;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getPlaceholder() {
        return placeholder;
    }

    public void setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(label);
        dest.writeValue(description);
        dest.writeValue(type);
        dest.writeValue(value);
        dest.writeValue(_default);
        dest.writeValue(tip);
        dest.writeValue(placeholder);
    }

    public int describeContents() {
        return  0;
    }

}
