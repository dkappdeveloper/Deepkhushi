package com.shoppingapp.deepkhushi.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.PaymentMethodAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConfig;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ActivityPaymentLayoutBinding;
import com.shoppingapp.deepkhushi.databinding.DialogPaymentInfoLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DataMapingHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.order.PaymentMethodModel;
import com.shoppingapp.deepkhushi.model.payment.PaypalBraintreeModel;
import com.shoppingapp.deepkhushi.model.payment.StripePaymentModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.braintreepayments.api.dropin.DropInRequest;
import com.braintreepayments.api.dropin.DropInResult;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 2/17/2020.
 */

public class PaymentActivity extends BaseActivity implements PaymentResultListener {

    ActivityPaymentLayoutBinding binding;
    DialogPaymentInfoLayoutBinding paymentInfoBinding;

    PaymentMethodAdapter paymentMethodAdapter;
    private List<PaymentMethodModel> paymentMethodList;
    private HashMap<String, String> billingAddress;

    private String totalAmount = "", transactionId = "";
    private String paymentMethod, paymentTitle;
    private String currencySymbol;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initRecyclerView();
        initListener();
        initPaymentMethods();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case AppConstants.PAYPAL_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        DropInResult result = data.getParcelableExtra(DropInResult.EXTRA_DROP_IN_RESULT);
                        String nonce = result.getPaymentMethodNonce().getNonce();
                        completePaypalPayment(nonce);
                        break;
                    case Activity.RESULT_CANCELED:
                        Log.e("Payment Selection", "User cancelled payment");
                        break;
                }
                break;

            case AppConstants.STRIPE_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        loadStripePayment(data);
                        break;
                    case Activity.RESULT_CANCELED:
                        Log.e("Payment Selection", "User cancelled payment");
                        break;
                }
                break;
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        Log.e("onPaymentSuccess: ", s);
        transactionId = s;
        paymentMethod = AppConstants.PAYMENT_METHOD_RAZORPAY;
        paymentTitle = getString(R.string.payment_title_razorpay);
        confirmOrderPlace(true);
    }

    @Override
    public void onPaymentError(int i, String s) {
        Log.e("onPaymentError: ", s + " " + i);
        AppHelper.showShortToast(PaymentActivity.this, getString(R.string.failed_msg));
    }

    private void initVars() {
        paymentMethodList = new ArrayList<>();

        currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.containsKey(AppConstants.BUNDLE_PAYMENT_TOTAL))
                totalAmount = bundle.getString(AppConstants.BUNDLE_PAYMENT_TOTAL);

            if (bundle.containsKey(AppConstants.BUNDLE_BILLING_ADDRESS))
                billingAddress = (HashMap<String, String>) bundle.getSerializable(AppConstants.BUNDLE_BILLING_ADDRESS);

        }
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_payment_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.payment_total) + " " + currencySymbol + totalAmount);

        if (AppConfig.PAYMENT_METHOD_RAZORPAY)
            Checkout.preload(getApplicationContext());
    }

    private void initListener() {
        paymentMethodAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                PaymentMethodModel model = paymentMethodList.get(position);

                switch (model.getMethod()) {
                    case AppConstants.PAYMENT_METHOD_BANK:
                        loadPaymentInfoDialog(getString(R.string.payment_title_bank), getString(R.string.method_description_bank));
                        paymentMethod = AppConstants.PAYMENT_METHOD_BANK;
                        paymentTitle = getString(R.string.payment_title_bank);
                        break;
                    case AppConstants.PAYMENT_METHOD_CHECK:
                        loadPaymentInfoDialog(getString(R.string.payment_title_check), getString(R.string.method_description_check));
                        paymentMethod = AppConstants.PAYMENT_METHOD_CHECK;
                        paymentTitle = getString(R.string.payment_title_check);
                        break;
                    case AppConstants.PAYMENT_METHOD_CASH:
                        loadPaymentInfoDialog(getString(R.string.payment_title_cash), getString(R.string.method_description_cash_delivery));
                        paymentMethod = AppConstants.PAYMENT_METHOD_CASH;
                        paymentTitle = getString(R.string.payment_title_cash);
                        break;
                    case AppConstants.PAYMENT_METHOD_PAYPAL:
                        loadPaypalPayment();
                        break;
                    case AppConstants.PAYMENT_METHOD_STRIPE:
                        loadStripePaymentUI();
                        break;
                    case AppConstants.PAYMENT_METHOD_RAZORPAY:
                        loadRazorpayPayment();
                        break;
                }
            }
        });
    }

    private void initRecyclerView() {
        paymentMethodAdapter = new PaymentMethodAdapter(this, paymentMethodList);
        binding.paymentMethodRecycler.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.paymentMethodRecycler.setHasFixedSize(true);

        DividerItemDecoration verticalDivider = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        verticalDivider.setDrawable(ContextCompat.getDrawable(getBaseContext(), R.drawable.line_divider));
        binding.paymentMethodRecycler.addItemDecoration(verticalDivider);

        DividerItemDecoration horizontalDivider = new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL);
        horizontalDivider.setDrawable(ContextCompat.getDrawable(getBaseContext(), R.drawable.line_divider));
        binding.paymentMethodRecycler.addItemDecoration(horizontalDivider);

        binding.paymentMethodRecycler.setNestedScrollingEnabled(false);
        binding.paymentMethodRecycler.setAdapter(paymentMethodAdapter);
    }

    private void initPaymentMethods() {
        if (AppConfig.PAYMENT_METHOD_BANK)
            paymentMethodList.add(new PaymentMethodModel(1, getString(R.string.payment_title_bank), AppConstants.PAYMENT_METHOD_BANK, R.drawable.ic_bank, false));

        if (AppConfig.PAYMENT_METHOD_CASH)
            paymentMethodList.add(new PaymentMethodModel(2, getString(R.string.payment_title_cash), AppConstants.PAYMENT_METHOD_CASH, R.drawable.ic_cash_delivery, false));

        if (AppConfig.PAYMENT_METHOD_CHECK)
            paymentMethodList.add(new PaymentMethodModel(3, getString(R.string.payment_title_check), AppConstants.PAYMENT_METHOD_CHECK, R.drawable.ic_bank_check, false));

        if (AppConfig.PAYMENT_METHOD_PAYPAL)
            paymentMethodList.add(new PaymentMethodModel(4, getString(R.string.payment_title_paypal), AppConstants.PAYMENT_METHOD_PAYPAL, R.drawable.ic_paypal, false));

        if (AppConfig.PAYMENT_METHOD_RAZORPAY)
            paymentMethodList.add(new PaymentMethodModel(5, getString(R.string.payment_title_razorpay), AppConstants.PAYMENT_METHOD_RAZORPAY, R.drawable.ic_razorpay, false));

        if (AppConfig.PAYMENT_METHOD_STRIPE)
            paymentMethodList.add(new PaymentMethodModel(6, getString(R.string.payment_title_stripe), AppConstants.PAYMENT_METHOD_STRIPE, R.drawable.ic_stripe, false));

        paymentMethodAdapter.notifyDataSetChanged();
    }

    private void loadPaymentInfoDialog(String title, String info) {
        final Dialog stateDialog = new Dialog(this);
        stateDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        paymentInfoBinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.dialog_payment_info_layout, null, false);
        stateDialog.setContentView(paymentInfoBinding.getRoot());
        stateDialog.setCanceledOnTouchOutside(false);

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(stateDialog.getWindow().getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -2;
        stateDialog.getWindow().setAttributes(layoutParams);

        paymentInfoBinding.paymentMethodTitle.setText(title);
        paymentInfoBinding.paymentMethodInfo.setText(info);

        paymentInfoBinding.okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stateDialog.dismiss();
                confirmOrderPlace(false);
            }
        });

        stateDialog.show();
    }

    private void loadPaypalPayment() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            HashMap<String, String> paypalRequest = ApiRequests.buildPaypalRequest(AppConstants.REQUEST_PAYPAL_TOKEN, "", "");
            ApiClient.getInstance().getApiInterface().getPaypalBraintree(paypalRequest).enqueue(new Callback<PaypalBraintreeModel>() {
                @Override
                public void onResponse(@NonNull Call<PaypalBraintreeModel> call, @NonNull Response<PaypalBraintreeModel> response) {
                    if (response.isSuccessful()) {
                        int responseCode = Integer.parseInt(response.body().getCode());
                        if (responseCode == AppConstants.RESPONSE_SUCCESS) {
                            String token = response.body().getData();
                            initializePaymentUI(token);
                        }
                    } else {
                        AppHelper.showShortToast(PaymentActivity.this, getString(R.string.server_error_msg));
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<PaypalBraintreeModel> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(PaymentActivity.this, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void completePaypalPayment(String paymentNonce) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            HashMap<String, String> paypalRequest = ApiRequests.buildPaypalRequest(AppConstants.REQUEST_PAYPAL_TOKEN, paymentNonce, totalAmount);
            ApiClient.getInstance().getApiInterface().getPaypalBraintree(paypalRequest).enqueue(new Callback<PaypalBraintreeModel>() {
                @Override
                public void onResponse(@NonNull Call<PaypalBraintreeModel> call, @NonNull Response<PaypalBraintreeModel> response) {
                    if (response.isSuccessful()) {
                        int responseCode = Integer.parseInt(response.body().getCode());
                        if (responseCode == AppConstants.RESPONSE_SUCCESS) {
                            AppHelper.showShortToast(PaymentActivity.this, getString(R.string.payment_success));
                            paymentMethod = AppConstants.PAYMENT_METHOD_PAYPAL;
                            paymentTitle = getString(R.string.payment_title_paypal);
                            confirmOrderPlace(true);
                        }
                    } else {
                        AppHelper.showShortToast(PaymentActivity.this, getString(R.string.server_error_msg));
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<PaypalBraintreeModel> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(PaymentActivity.this, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void initializePaymentUI(String token) {
        DropInRequest dropInRequest = new DropInRequest().clientToken(token);
        startActivityForResult(dropInRequest.getIntent(this), AppConstants.PAYPAL_REQUEST_CODE);
    }

    private void loadStripePaymentUI() {
        startActivityForResult(new Intent(PaymentActivity.this, StripePaymentActivity.class), AppConstants.STRIPE_REQUEST_CODE);
    }

    private void loadStripePayment(Intent intent) {
        String stripeToken = intent.getStringExtra(AppConstants.BUNDLE_STRIPE_TOKEN);
        String currencyCode = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_CODE);
        String paymentTtle = getString(R.string.app_name) + " " + getString(R.string.order_payment);

        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();
            HashMap<String, String> stripeRequest = ApiRequests.buildStripeRequest(stripeToken, currencyCode, paymentTtle, totalAmount);
            ApiClient.getInstance().getApiInterface().getStripePayment(stripeRequest).enqueue(new Callback<StripePaymentModel>() {
                @Override
                public void onResponse(@NonNull Call<StripePaymentModel> call, @NonNull Response<StripePaymentModel> response) {
                    if (response.isSuccessful()) {
                        int responseCode = Integer.parseInt(response.body().getCode());
                        if (responseCode == AppConstants.RESPONSE_SUCCESS) {
                            AppHelper.showShortToast(PaymentActivity.this, getString(R.string.payment_success));

                            transactionId = response.body().getData();
                            paymentMethod = AppConstants.PAYMENT_METHOD_STRIPE;
                            paymentTitle = getString(R.string.payment_title_stripe);
                            confirmOrderPlace(true);
                        }
                    } else {
                        AppHelper.showShortToast(PaymentActivity.this, getString(R.string.server_error_msg));
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<StripePaymentModel> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(PaymentActivity.this, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadRazorpayPayment() {
        final Checkout checkout = new Checkout();
        checkout.setImage(R.drawable.ic_logo);

        String billFirstName = billingAddress.get(DataMapingHelper.KEY_FIRST_NAME);
        String billLastName = billingAddress.get(DataMapingHelper.KEY_LAST_NAME);
        String billEmail = billingAddress.get(DataMapingHelper.KEY_EMAIL);
        String billContact = billingAddress.get(DataMapingHelper.KEY_PHONE);
        String currencyCode = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_CODE);
        currencyCode = "INR";

        String shopName = getString(R.string.app_name);
        String description = getString(R.string.order_payment);

        try {
            JSONObject options = new JSONObject();
            options.put("name", shopName);
            options.put("description", description);
            options.put("currency", currencyCode);

            double total = Double.parseDouble(totalAmount) * 100;
            options.put("amount", total);

            JSONObject preFill = new JSONObject();
            preFill.put("name", billFirstName + " " + billLastName);
            preFill.put("email", billEmail);
            preFill.put("contact", billContact);
            options.put("prefill", preFill);

            checkout.open(this, options);
        } catch (Exception e) {
            Log.e("loadRazorpayPayment: ", e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    private void confirmOrderPlace(Boolean isPaid) {
        Intent intent = new Intent();
        intent.putExtra(AppConstants.BUNDLE_PAYMENT_METHOD, paymentMethod);
        intent.putExtra(AppConstants.BUNDLE_PAYMENT_METHOD_TITLE, paymentTitle);
        intent.putExtra(AppConstants.BUNDLE_TRANSACTION_ID, transactionId);
        intent.putExtra(AppConstants.BUNDLE_PAYMENT_CONFIRMED, isPaid);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }
}
