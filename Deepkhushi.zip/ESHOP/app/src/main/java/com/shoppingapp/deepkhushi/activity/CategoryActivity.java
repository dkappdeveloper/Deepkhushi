package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.CategoryListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.ActivityCategoryListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.category.CategoryModel;
import com.shoppingapp.deepkhushi.model.product.ProductSearchModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 10-May-19.
 */

public class CategoryActivity extends BaseActivity {

    ActivityCategoryListLayoutBinding binding;

    CategoryListAdapter categoryListAdapter;

    private List<CategoryModel> categoryList, categoryArrayList;
    private ProductSearchModel productSearchModel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initRecyclerView();
        initListener();
        loadCategories();
    }

    @Override
    protected void onResume() {
        super.onResume();

        updateToolbarCartCount(binding.primaryToolbar.cartCounter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {
        categoryList = new ArrayList<>();
        categoryArrayList = new ArrayList<>();
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_category_list_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_categories));
    }

    private void initListener() {

        binding.primaryToolbar.toolbarMenuCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, ProductCartActivity.class));
            }
        });

        binding.primaryToolbar.toolbarMenuSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CategoryActivity.this, SearchProductActivity.class));
            }
        });

        categoryListAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                Bundle bundle = new Bundle();
                if (hasSubCategory(categoryList.get(position).getId())) {
                    bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, categoryList.get(position).getName());
                    bundle.putInt(AppConstants.BUNDLE_CATEGORY_ID, categoryList.get(position).getId());
                    startActivity(new Intent(CategoryActivity.this, SubCategoryActivity.class).putExtras(bundle));
                } else {
                    productSearchModel = new ProductSearchModel();
                    productSearchModel.setPage(AppConstants.PAGE_NUMBER);
                    productSearchModel.setPerPage(AppConstants.PER_PAGE);
                    productSearchModel.setCategoryId(categoryList.get(position).getId().toString());

                    bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, categoryList.get(position).getName());
                    bundle.putParcelable(AppConstants.BUNDLE_SEARCH_PRODUCT, productSearchModel);
                    startActivity(new Intent(CategoryActivity.this, ProductListActivity.class).putExtras(bundle));
                }
            }
        });
    }

    private void initRecyclerView() {
        categoryListAdapter = new CategoryListAdapter(this, categoryList);
        binding.categoryRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        binding.categoryRecycler.setAdapter(categoryListAdapter);
    }

    private void loadCategories() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            HashMap<String, String> categoryListMap = ApiRequests.buildCategoryList(true, AppConstants.CATEGORY_PER_PAGE);
            ApiClient.getInstance().getApiInterface().getCategories(categoryListMap).enqueue(new Callback<List<CategoryModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<CategoryModel>> call, @NonNull Response<List<CategoryModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            categoryList.clear();
                            categoryArrayList.clear();
                            categoryArrayList.addAll(response.body());

                            if (categoryArrayList != null && categoryArrayList.size() > 0) {
                                for (CategoryModel model : categoryArrayList) {
                                    if (model.getParent() == 0) {
                                        categoryList.add(model);
                                    }
                                }

                                categoryListAdapter.notifyDataSetChanged();
                                binding.categoryRecycler.setVisibility(View.VISIBLE);
                            }

                            binding.shimmerCategoryLayout.shimmerCategoryLayout.setVisibility(View.GONE);
                        }
                    } else {
                        binding.emptyListLayout.removeAllViews();
                        binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.no_data)));
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<CategoryModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private boolean hasSubCategory(int categoryId) {

        boolean hasCategory = false;

        for (CategoryModel model : categoryArrayList) {
            if (categoryId > 0 && model.getParent() == categoryId) {
                hasCategory = true;
            }
        }

        return hasCategory;
    }
}
