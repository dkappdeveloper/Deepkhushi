package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemGridHomeProductListLayoutBinding;
import com.shoppingapp.deepkhushi.databinding.ItemLinearHomeProductListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductImageModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 21-Feb-19.
 */
public class HomeProductListAdapter extends RecyclerView.Adapter<HomeProductListAdapter.ProductListViewHolder> {

    private Context context;
    private List<ProductModel> arrayList;
    private AppConstants.ListLayoutType listLayoutType;

    private ItemClickListener itemClickListener;

    public HomeProductListAdapter(Context context) {
        this.context = context;
    }

    public HomeProductListAdapter(Context context, List<ProductModel> arrayList, AppConstants.ListLayoutType listLayoutType) {
        this.context = context;
        this.arrayList = arrayList;
        this.listLayoutType = listLayoutType;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public HomeProductListAdapter.ProductListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        if (listLayoutType == AppConstants.ListLayoutType.GRID) {
            return new ProductListViewHolder((ItemGridHomeProductListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_grid_home_product_list_layout, viewGroup, false));
        } else {
            return new ProductListViewHolder((ItemLinearHomeProductListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_linear_home_product_list_layout, viewGroup, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull HomeProductListAdapter.ProductListViewHolder holder, int position) {

        List<ProductImageModel> imageModel = arrayList.get(position).getProductImageModels();
        String type = arrayList.get(position).getType();
        String title = arrayList.get(position).getName();
        String basePrice = arrayList.get(position).getPrice();
        String salePrice = arrayList.get(position).getSalePrice();
        String regularPrice = arrayList.get(position).getRegularPrice();
        String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
        Boolean isFavourite = arrayList.get(position).getFavourite();

        if (listLayoutType == AppConstants.ListLayoutType.GRID) {
            if (imageModel.size() > 0) {
                String productImage = imageModel.get(0).getSrc();
                Picasso.get().load(productImage)
                        .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .into(holder.gridLayoutBinding.productImage);
            }

            holder.gridLayoutBinding.productTitle.setText(AppHelper.fromHtml(title));

            if (type.equals(AppConstants.PRODUCT_TYPE_VARIABLE)) {
                holder.gridLayoutBinding.productSalePrice.setText(currencySymbol + basePrice);
                holder.gridLayoutBinding.productRegularPrice.setVisibility(View.GONE);
            } else if (type.equals(AppConstants.PRODUCT_TYPE_SIMPLE)) {

                if (salePrice != null && !salePrice.isEmpty()) {
                    holder.gridLayoutBinding.productSalePrice.setText(currencySymbol + salePrice);
                    holder.gridLayoutBinding.productRegularPrice.setText(currencySymbol + regularPrice);
                    holder.gridLayoutBinding.productRegularPrice.setVisibility(View.VISIBLE);
                } else {
                    holder.gridLayoutBinding.productSalePrice.setText(currencySymbol + regularPrice);
                    holder.gridLayoutBinding.productRegularPrice.setVisibility(View.GONE);
                }
            }

        } else {
            if (imageModel.size() > 0) {
                String productImage = imageModel.get(0).getSrc();
                Picasso.get().load(productImage)
                        .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                        .into(holder.listLayoutBinding.productImage);
            }

            holder.listLayoutBinding.productTitle.setText(title);

            if (type.equals(AppConstants.PRODUCT_TYPE_VARIABLE)) {
                holder.listLayoutBinding.productSalePrice.setText(currencySymbol + basePrice);
                holder.listLayoutBinding.productRegularPrice.setVisibility(View.GONE);
            } else if (type.equals(AppConstants.PRODUCT_TYPE_SIMPLE)) {
                if (salePrice != null && !salePrice.isEmpty()) {
                    holder.listLayoutBinding.productSalePrice.setText(currencySymbol + salePrice);
                    holder.listLayoutBinding.productRegularPrice.setText(currencySymbol + regularPrice);
                    holder.listLayoutBinding.productRegularPrice.setVisibility(View.VISIBLE);
                } else {
                    holder.listLayoutBinding.productSalePrice.setText(currencySymbol + regularPrice);
                    holder.listLayoutBinding.productRegularPrice.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ProductListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemLinearHomeProductListLayoutBinding listLayoutBinding;
        ItemGridHomeProductListLayoutBinding gridLayoutBinding;

        ProductListViewHolder(@NonNull ItemLinearHomeProductListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            listLayoutBinding = layoutBinding;

            listLayoutBinding.parentView.setOnClickListener(this);
        }

        ProductListViewHolder(@NonNull ItemGridHomeProductListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            gridLayoutBinding = layoutBinding;

            gridLayoutBinding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
