package com.shoppingapp.deepkhushi.adapter.viewpager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.viewpager.widget.PagerAdapter;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemProductImageSliderBinding;
import com.shoppingapp.deepkhushi.model.product.ProductImageModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Md Sahidul Islam on 29-Mar-19.
 */
public class ProductImageSliderAdpater extends PagerAdapter {

    private Context context;
    private List<ProductImageModel> modelList;

    public ProductImageSliderAdpater(Context context) {
        this.context = context;
    }

    public ProductImageSliderAdpater(Context context, List<ProductImageModel> modelList) {
        this.context = context;
        this.modelList = modelList;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        ItemProductImageSliderBinding binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_product_image_slider, container, false);

        String sliderImage = modelList.get(position).getSrc();
        if (sliderImage != null && !sliderImage.isEmpty())
            Picasso.get().load(sliderImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(binding.sliderProductImage);

        container.addView(binding.getRoot());
        return binding.getRoot();
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return modelList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }
}
