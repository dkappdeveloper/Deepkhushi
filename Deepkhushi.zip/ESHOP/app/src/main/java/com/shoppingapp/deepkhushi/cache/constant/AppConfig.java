package com.shoppingapp.deepkhushi.cache.constant;

/**
 * Created by Deepak Kumar on 26-Feb-20.
 */

public class AppConfig {


    /* Facebook, Google Activation ENABLE = true , DISABLE = false */
    public static final Boolean FACEBOOK_LOGIN = false;
    public static final Boolean GOOGLE_LOGIN = false;


    /* Payment Method Activation ENABLE = true , DISABLE = false */
    public static final Boolean PAYMENT_METHOD_BANK = false;
    public static final Boolean PAYMENT_METHOD_CASH = true;
    public static final Boolean PAYMENT_METHOD_CHECK = false;
    public static final Boolean PAYMENT_METHOD_PAYPAL = false;
    public static final Boolean PAYMENT_METHOD_RAZORPAY = true;
    public static final Boolean PAYMENT_METHOD_STRIPE = false;
}
