package com.shoppingapp.deepkhushi.activity;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.LocationLoader;
import com.shoppingapp.deepkhushi.databinding.ActivitySplashLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.model.data.DataContinentModel;
import com.shoppingapp.deepkhushi.model.data.DataCountryModel;
import com.shoppingapp.deepkhushi.model.data.DataCurrencyModel;
import com.shoppingapp.deepkhushi.model.data.DataStateModel;
import com.shoppingapp.deepkhushi.model.dbEntity.LocationModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 18-Jan-19.
 */

public class SplashActivity extends BaseActivity {

    ActivitySplashLayoutBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();
        getLocationList();

        deepLinkHandler();
    }

    private void initView() {
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash_layout);
    }

    private void getLocationList() {
        binding.rotateProgress.show();
        LocationLoader loader = new LocationLoader(this);
        loader.execute(DaoHelper.ROW_COUNT);
        loader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {

                    int rowCount = (int) object;
                    if (rowCount > 0) {
                        setAppCurrency();
                    } else {
                        loadLocationData();
                    }
                } else {
                    AppHelper.showShortSnack(getApplicationContext(), binding.parentView, getString(R.string.failed_database_msg));
                }
            }
        });
    }

    private void loadLocationData() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            ApiClient.getInstance().getApiInterface().getDataContinents().enqueue(new Callback<List<DataContinentModel>>() {
                @Override
                public void onResponse(@Nullable Call<List<DataContinentModel>> call, @Nullable Response<List<DataContinentModel>> response) {
                    if (response.body() != null) {
                        List<DataContinentModel> continentList = new ArrayList<>(response.body());
                        setLocationData(continentList);
                    } else {
                        binding.rotateProgress.hide();
                        AppHelper.showShortSnack(getApplicationContext(), binding.parentView, getString(R.string.server_failed_msg));
                    }
                }

                @Override
                public void onFailure(@Nullable Call<List<DataContinentModel>> call, @Nullable Throwable t) {
                    binding.rotateProgress.hide();
                    AppHelper.showLongSnack(getApplicationContext(), binding.parentView, getString(R.string.server_failed_msg), true);
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void setLocationData(List<DataContinentModel> continentModelList) {
        for (DataContinentModel dataContinentModel : continentModelList) {
            String continentName = AppHelper.fromHtml(dataContinentModel.getName()).toString();
            String continentCode = dataContinentModel.getCode();

            for (DataCountryModel dataCountryModel : dataContinentModel.getCountries()) {
                String countryName = AppHelper.fromHtml(dataCountryModel.getName()).toString();
                String countryCode = dataCountryModel.getCode();

                if (dataCountryModel.getDataStateModels().size() > 0) {
                    for (DataStateModel dataStateModel : dataCountryModel.getDataStateModels()) {
                        String stateName = AppHelper.fromHtml(dataStateModel.getName()).toString();
                        String stateCode = dataStateModel.getCode();

                        LocationModel model = new LocationModel(continentCode, continentName, countryCode, countryName, stateCode, stateName);

                        LocationLoader loader = new LocationLoader(this);
                        loader.execute(DaoHelper.INSERT, model);
                    }
                } else {
                    LocationModel model = new LocationModel(continentCode, continentName, countryCode, countryName, "", "");

                    LocationLoader loader = new LocationLoader(this);
                    loader.execute(DaoHelper.INSERT, model);
                }
            }
        }
        setAppCurrency();
    }

    private void setAppCurrency() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            ApiClient.getInstance().getApiInterface().getDataCurrency().enqueue(new Callback<DataCurrencyModel>() {
                @Override
                public void onResponse(@NonNull Call<DataCurrencyModel> call, @NonNull Response<DataCurrencyModel> response) {
                    if (response.body() != null) {
                        String code = response.body().getCode();
                        String symbol = AppHelper.fromHtml(response.body().getSymbol()).toString();

                        AppPreference.getInstance(getApplicationContext()).setString(PrefKey.CURRENCY_CODE, code);
                        AppPreference.getInstance(getApplicationContext()).setString(PrefKey.CURRENCY_SYMBOL, symbol);

                        loadApp();
                    } else {
                        AppHelper.showShortSnack(getApplicationContext(), binding.parentView, getString(R.string.server_failed_msg));
                    }
                    binding.rotateProgress.hide();
                }

                @Override
                public void onFailure(@NonNull Call<DataCurrencyModel> call, @NonNull Throwable t) {
                    binding.rotateProgress.hide();
                    AppHelper.showLongSnack(getApplicationContext(), binding.parentView, getString(R.string.server_failed_msg), true);
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadApp() {
        boolean signed = AppPreference.getInstance(context).getBoolean(PrefKey.SIGNED_IN);
        boolean skipped = AppPreference.getInstance(context).getBoolean(PrefKey.SKIP_SIGN_IN);

        if (signed || skipped)
            startActivity(new Intent(SplashActivity.this, HomeActivity.class));
        else {
            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
        }
        finish();
    }

    private void deepLinkHandler() {
        Intent intent = getIntent();
        Uri data = intent.getData();

        if (data != null && data.isHierarchical()) {
            Log.e("deepData: ", data.toString());
        }
    }
}
