package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemOrderedProductLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 25-May-19.
 */
public class OrderProductListAdapter extends RecyclerView.Adapter<OrderProductListAdapter.OrderProductViewHolder> {

    private Context context;
    private List<ProductCartModel> arrayList;

    public OrderProductListAdapter() {
    }

    public OrderProductListAdapter(Context context, List<ProductCartModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public OrderProductListAdapter.OrderProductViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new OrderProductViewHolder((ItemOrderedProductLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_ordered_product_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull OrderProductListAdapter.OrderProductViewHolder holder, int position) {
        String title = arrayList.get(position).getProductName();
        String productImage = arrayList.get(position).getProductImage();
        String productPrice = arrayList.get(position).getProductPrice();
        String totalPrice = arrayList.get(position).getTotalPrice();
        String quantity = arrayList.get(position).getProductQuantity();

        if (productImage != null && !productImage.isEmpty()) {
            Picasso.get().load(productImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(holder.binding.productImage);
        }

        holder.binding.productTitle.setText(AppHelper.fromHtml(title));
        holder.binding.productQuantity.setText(quantity + " pcs");
        holder.binding.productSalePrice.setText(productPrice);
        holder.binding.productSubtotalPrice.setText(totalPrice);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class OrderProductViewHolder extends RecyclerView.ViewHolder {

        ItemOrderedProductLayoutBinding binding;

        OrderProductViewHolder(@NonNull ItemOrderedProductLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;
        }
    }
}
