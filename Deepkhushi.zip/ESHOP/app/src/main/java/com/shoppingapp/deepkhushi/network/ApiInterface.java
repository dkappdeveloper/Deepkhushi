package com.shoppingapp.deepkhushi.network;

import com.shoppingapp.deepkhushi.model.category.CategoryModel;
import com.shoppingapp.deepkhushi.model.customer.CustomerModel;
import com.shoppingapp.deepkhushi.model.data.DataContinentModel;
import com.shoppingapp.deepkhushi.model.data.DataCurrencyModel;
import com.shoppingapp.deepkhushi.model.order.OrderModel;
import com.shoppingapp.deepkhushi.model.payment.PaypalBraintreeModel;
import com.shoppingapp.deepkhushi.model.payment.StripePaymentModel;
import com.shoppingapp.deepkhushi.model.product.ProductAttributeModel;
import com.shoppingapp.deepkhushi.model.product.ProductCouponModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.shoppingapp.deepkhushi.model.product.ProductReviewModel;
import com.shoppingapp.deepkhushi.model.product.ProductTag;
import com.shoppingapp.deepkhushi.model.shipping.ShippingLocationModel;
import com.shoppingapp.deepkhushi.model.shipping.ShippingMethodModel;
import com.shoppingapp.deepkhushi.model.shipping.ShippingZoneModel;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

/**
 * Created by Deepak Kumar on 23-Jan-19.
 */

public interface ApiInterface {

    @POST(ApiConfig.API_CUSTOMER)
    @FormUrlEncoded
    Call<CustomerModel> createCustomer(@FieldMap HashMap<String, String> hashMap);

    @GET(ApiConfig.API_CUSTOMER)
    Call<List<CustomerModel>> getCustomer(@QueryMap HashMap<String, String> hashMap);


    @GET(ApiConfig.API_PRODUCT_CATEGORIES)
    Call<List<CategoryModel>> getCategories(@QueryMap HashMap<String, String> hashMap);


    @GET(ApiConfig.API_PRODUCTS)
    Call<List<ProductModel>> getProducts(@QueryMap HashMap<String, String> hashMap);


    @GET(ApiConfig.API_PRODUCT_DETAIL)
    Call<ProductModel> getProductDetail(@Path(ApiConfig.KEY_ID) Integer id);


    @GET(ApiConfig.API_PRODUCT_REVIEWS)
    Call<List<ProductReviewModel>> getProductReviews(@QueryMap HashMap<String, String> hashMap);


    @POST(ApiConfig.API_PRODUCT_REVIEWS)
    @FormUrlEncoded
    Call<ProductReviewModel> createProductReview(@FieldMap HashMap<String, String> hashMap);


    @GET(ApiConfig.API_PRODUCT_TAGS)
    Call<List<ProductTag>> checkProductHasTag(@QueryMap HashMap<String, String> hashMap);


    @GET(ApiConfig.API_PRODUCT_ATTRIBUTES)
    Call<List<ProductAttributeModel>> getProductAttributes();


    @GET(ApiConfig.API_PRODUCT_TERMS)
    Call<List<ProductAttributeModel>> getProductAttributesTerms(@Path(ApiConfig.KEY_ID) Integer id);


    @GET(ApiConfig.API_DATA_CURRENCY)
    Call<DataCurrencyModel> getDataCurrency();


    @GET(ApiConfig.API_CURRENCY_SYMBOL)
    Call<DataCurrencyModel> getCurrencySymbol(@Path(ApiConfig.KEY_ID) String id);


    @GET(ApiConfig.API_DATA_CONTINENTS)
    Call<List<DataContinentModel>> getDataContinents();


    @Headers("Content-Type: application/json")
    @POST(ApiConfig.API_REQUEST_ORDER)
    Call<OrderModel> createOrder(@Body JsonObject body);


    @POST(ApiConfig.API_ORDER_NOTES)
    @FormUrlEncoded
    Call<OrderModel> createOrderNote(@Path(ApiConfig.KEY_ID) Integer id, @FieldMap HashMap<String, String> hashMap);


    @GET(ApiConfig.API_REQUEST_ORDER)
    Call<List<OrderModel>> getMyOrders(@Query(ApiConfig.KEY_CUSTOMER) Integer id);


    @GET(ApiConfig.API_COUPONS)
    Call<List<ProductCouponModel>> getCoupons();


    @GET(ApiConfig.API_SHIPPING_ZONES)
    Call<List<ShippingZoneModel>> getShippingZones();


    @GET(ApiConfig.API_SHIPPING_ZONE_LOCATIONS)
    Call<List<ShippingLocationModel>> getShippingZoneLocations(@Path(ApiConfig.KEY_ID) Integer id);


    @GET(ApiConfig.API_SHIPPING_ZONE_METHODS)
    Call<List<ShippingMethodModel>> getShippingZoneMethods(@Path(ApiConfig.KEY_ID) Integer id);


    @POST(ApiConfig.API_PAYPAL_BRAINTREE)
    @FormUrlEncoded
    Call<PaypalBraintreeModel> getPaypalBraintree(@FieldMap HashMap<String, String> hashMap);


    @POST(ApiConfig.API_STRIPE_PAYMENT)
    @FormUrlEncoded
    Call<StripePaymentModel> getStripePayment(@FieldMap HashMap<String, String> hashMap);


    @DELETE(ApiConfig.API_CANCEL_ORDER)
    Call<OrderModel> cancelOrder(@Path(ApiConfig.KEY_ID) Integer id, @QueryMap HashMap<String, String> hashMap);
}
