package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemCouponLayoutBinding;
import com.shoppingapp.deepkhushi.databinding.ItemPaymentMethodLayoutBinding;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.order.PaymentMethodModel;

import java.util.List;

/**
 * Created by Deepak Kumar 17-Feb-20.
 */
public class PaymentMethodAdapter  extends RecyclerView.Adapter<PaymentMethodAdapter.PaymentMethodViewHolder>  {

    private Context context;
    private List<PaymentMethodModel> arrayList;

    private ItemClickListener itemClickListener;

    public PaymentMethodAdapter(Context context) {
        this.context = context;
    }

    public PaymentMethodAdapter(Context context, List<PaymentMethodModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public PaymentMethodAdapter.PaymentMethodViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new PaymentMethodViewHolder((ItemPaymentMethodLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_payment_method_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentMethodAdapter.PaymentMethodViewHolder holder, int position) {
        holder.binding.methodLogo.setImageResource(arrayList.get(position).getIcon());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class PaymentMethodViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemPaymentMethodLayoutBinding binding;

        public PaymentMethodViewHolder(@NonNull ItemPaymentMethodLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());

            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
