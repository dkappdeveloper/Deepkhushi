package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.MyFavouritesAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.FavouriteItemLoader;
import com.shoppingapp.deepkhushi.databinding.ActivityMyFavouritesLayoutBinding;
import com.shoppingapp.deepkhushi.helper.ADHelper;
import com.shoppingapp.deepkhushi.listener.ItemViewClickListener;
import com.shoppingapp.deepkhushi.model.dbEntity.FavouritesModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Deepak Kumar on 14-May-19.
 */

public class MyFavouritesActivity extends BaseActivity {

    ActivityMyFavouritesLayoutBinding binding;

    MyFavouritesAdapter myFavouritesAdapter;
    private List<FavouritesModel> favouriteList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        initRecyclerView();
        loadFavourites();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {
        favouriteList = new ArrayList<>();
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_favourites_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_favourites));

        /* Un Comment below code to show AD*/
       // ADHelper.getInstance(getApplicationContext()).showFullScreenAd();
       // ADHelper.getInstance(getApplicationContext()).showBannerAd(binding.bannerAdLayout);
    }

    private void initListener() {

    }

    private void initRecyclerView() {
        myFavouritesAdapter = new MyFavouritesAdapter(this, favouriteList);
        binding.myFavouritesRecycler.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.myFavouritesRecycler.setAdapter(myFavouritesAdapter);

        myFavouritesAdapter.setItemClickListener(new ItemViewClickListener() {
            @Override
            public void onItemViewClickGetPosition(int position, View view) {
                switch (view.getId()) {
                    case R.id.parent_view:
                        Bundle bundle = new Bundle();
                        bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, favouriteList.get(position).getProductName());
                        bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, favouriteList.get(position).getProductId());
                        startActivity(new Intent(MyFavouritesActivity.this, ProductDetailActivity.class).putExtras(bundle));
                        break;
                    case R.id.remove_product:
                        removeFavourite(position);
                        break;
                }
            }
        });
    }

    private void loadFavourites() {
        FavouriteItemLoader favouriteItemLoader = new FavouriteItemLoader(this);
        favouriteItemLoader.execute(DaoHelper.FETCH_ALL);
        favouriteItemLoader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {
                    List<FavouritesModel> modelList = (List<FavouritesModel>) object;

                    if (modelList.size() > 0) {
                        favouriteList.clear();
                        favouriteList.addAll(modelList);
                        myFavouritesAdapter.notifyDataSetChanged();
                        binding.emptyListLayout.setVisibility(View.GONE);
                        binding.myFavouritesRecycler.setVisibility(View.VISIBLE);
                    } else {
                        binding.emptyListLayout.removeAllViews();
                        binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.no_favourites)));
                        binding.myFavouritesRecycler.setVisibility(View.GONE);
                        binding.emptyListLayout.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }

    private void removeFavourite(int position) {
        FavouritesModel model = favouriteList.get(position);
        FavouriteItemLoader favouriteItemLoader = new FavouriteItemLoader(this);
        favouriteItemLoader.execute(DaoHelper.DELETE, model.getProductId());

        favouriteList.remove(position);
        myFavouritesAdapter.notifyItemRemoved(position);

        loadFavourites();
    }
}
