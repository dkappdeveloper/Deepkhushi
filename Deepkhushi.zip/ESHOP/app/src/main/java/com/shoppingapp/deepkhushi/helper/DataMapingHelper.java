package com.shoppingapp.deepkhushi.helper;

import java.util.HashMap;

/**
 * Created by Deepak Kumar on 10-May-19.
 */
public class DataMapingHelper {

    public static String KEY_PRODUCT_NAME = "name";
    public static String KEY_PRODUCT_ID = "product_id";
    public static String KEY_PRODUCT_QUANTITY = "quantity";

    public static String KEY_FIRST_NAME = "first_name";
    public static String KEY_LAST_NAME = "last_name";
    public static String KEY_ADDRESS = "address_1";
    public static String KEY_CITY = "city";
    public static String KEY_STATE_NAME = "state_name";
    public static String KEY_STATE_CODE = "state";
    public static String KEY_COUNTRY_NAME = "country_name";
    public static String KEY_COUNTRY_CODE = "country";
    public static String KEY_POST_CODE = "postcode";
    public static String KEY_EMAIL = "email";
    public static String KEY_PHONE = "phone";


    public static HashMap<String, String> getHashMap(String key, String value) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(key, value);

        return hashMap;
    }

    public static HashMap<String, String> getProductAttribute(String key, String value) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(key, value);

        return hashMap;
    }

    public static HashMap<String, String> getOrderBillingAddress(String firstName, String lastName, String email, String phone,
                                                                 String address, String countryName, String countryCode, String stateName,
                                                                 String stateCode, String city, String postCode) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(KEY_FIRST_NAME, firstName);
        hashMap.put(KEY_LAST_NAME, lastName);
        hashMap.put(KEY_EMAIL, email);
        hashMap.put(KEY_PHONE, phone);
        hashMap.put(KEY_ADDRESS, address);
        hashMap.put(KEY_COUNTRY_NAME, countryName);
        hashMap.put(KEY_COUNTRY_CODE, countryCode);
        hashMap.put(KEY_STATE_NAME, stateName);
        hashMap.put(KEY_STATE_CODE, stateCode);
        hashMap.put(KEY_CITY, city);
        hashMap.put(KEY_POST_CODE, postCode);

        return hashMap;
    }

    public static HashMap<String, String> getOrderShippingAddress(String firstName, String lastName, String address, String countryName,
                                                                  String countryCode, String stateName, String stateCode, String city,
                                                                  String postCode) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(KEY_FIRST_NAME, firstName);
        hashMap.put(KEY_LAST_NAME, lastName);
        hashMap.put(KEY_ADDRESS, address);
        hashMap.put(KEY_COUNTRY_NAME, countryName);
        hashMap.put(KEY_COUNTRY_CODE, countryCode);
        hashMap.put(KEY_STATE_NAME, stateName);
        hashMap.put(KEY_STATE_CODE, stateCode);
        hashMap.put(KEY_CITY, city);
        hashMap.put(KEY_POST_CODE, postCode);

        return hashMap;
    }
}
