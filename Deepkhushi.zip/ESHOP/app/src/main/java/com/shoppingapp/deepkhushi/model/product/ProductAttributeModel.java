package com.shoppingapp.deepkhushi.model.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ProductAttributeModel implements Parcelable {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("slug")
    @Expose
    private String slug;

    private List<ProductAttributeModel> attributeTerms = new ArrayList<>();
    private Boolean isSelected = false;

    protected ProductAttributeModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.slug = ((String) in.readValue((String.class.getClassLoader())));
        in.readList(this.attributeTerms, (ProductAttributeModel.class.getClassLoader()));
        isSelected = in.readByte() != 0;
    }

    public final static Creator<ProductAttributeModel> CREATOR = new Creator<ProductAttributeModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public ProductAttributeModel createFromParcel(Parcel in) {
            return new ProductAttributeModel(in);
        }

        public ProductAttributeModel[] newArray(int size) {
            return (new ProductAttributeModel[size]);
        }

    };

    /**
     * No args constructor for use in serialization
     */
    public ProductAttributeModel() {
    }

    /**
     * @param id
     * @param name
     * @param slug
     */
    public ProductAttributeModel(Integer id, String name, String slug) {
        super();
        this.id = id;
        this.name = name;
        this.slug = slug;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public List<ProductAttributeModel> getAttributeTerms() {
        return attributeTerms;
    }

    public void setAttributeTerms(List<ProductAttributeModel> attributeTerms) {
        this.attributeTerms = attributeTerms;
    }

    public Boolean getSelected() {
        return isSelected;
    }

    public void setSelected(Boolean selected) {
        isSelected = selected;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(name);
        dest.writeValue(slug);
        dest.writeList(attributeTerms);
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }

    public int describeContents() {
        return 0;
    }

}
