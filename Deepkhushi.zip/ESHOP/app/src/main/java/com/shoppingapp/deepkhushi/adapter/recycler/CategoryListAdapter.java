package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemCategoryLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.category.CategoryModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 10-May-19.
 */
public class CategoryListAdapter extends RecyclerView.Adapter<CategoryListAdapter.CategoryViewHolder> {

    private Context context;
    private List<CategoryModel> arrayList;

    private ItemClickListener itemClickListener;

    public CategoryListAdapter(Context context) {
        this.context = context;
    }

    public CategoryListAdapter(Context context, List<CategoryModel> categoryList) {
        this.context = context;
        this.arrayList = categoryList;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public CategoryListAdapter.CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new CategoryViewHolder((ItemCategoryLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_category_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryListAdapter.CategoryViewHolder holder, int position) {

        if (arrayList.get(position).getCategoryImageModel() != null) {
            String categoryImage = arrayList.get(position).getCategoryImageModel().getSrc();
            Picasso.get().load(categoryImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(holder.binding.categoryImage);
        }

        String categoryTitle = arrayList.get(position).getName();
        int productCount = arrayList.get(position).getCount();

        holder.binding.categoryTitle.setText(AppHelper.fromHtml(categoryTitle));
        holder.binding.categoryProductCount.setText(productCount + " Products");
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class CategoryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemCategoryLayoutBinding binding;

        CategoryViewHolder(@NonNull ItemCategoryLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
