package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemProductAttributeTermsListLayoutBinding;
import com.shoppingapp.deepkhushi.listener.ProductAttributeSelectedListener;
import com.shoppingapp.deepkhushi.model.product.AttributeTermsModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 17-Apr-19.
 */
public class ProductAttributeTermsAdapter extends RecyclerView.Adapter<ProductAttributeTermsAdapter.ProductAttributeTermsViewHolder> {

    private Context context;
    private List<AttributeTermsModel> arrayList;

    private ProductAttributeSelectedListener itemSelectedListener;

    public ProductAttributeTermsAdapter(Context context) {
        this.context = context;
    }

    public ProductAttributeTermsAdapter(Context context, List<AttributeTermsModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemSelectedListener(ProductAttributeSelectedListener itemSelectedListener) {
        this.itemSelectedListener = itemSelectedListener;
    }

    @NonNull
    @Override
    public ProductAttributeTermsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new ProductAttributeTermsViewHolder((ItemProductAttributeTermsListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_product_attribute_terms_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAttributeTermsViewHolder holder, int position) {
        holder.binding.attributeTermsName.setText(arrayList.get(position).getTermsName());

        if (arrayList.get(position).isSelected()) {
            holder.binding.attributeTermsName.setBackground(context.getResources().getDrawable(R.drawable.bg_product_attribut_selected));
            holder.binding.attributeTermsName.setTextColor(context.getResources().getColor(R.color.colorWhite));
        } else {
            holder.binding.attributeTermsName.setBackground(context.getResources().getDrawable(R.drawable.border_gray));
            holder.binding.attributeTermsName.setTextColor(context.getResources().getColor(R.color.colorAccent));
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ProductAttributeTermsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemProductAttributeTermsListLayoutBinding binding;

        public ProductAttributeTermsViewHolder(@NonNull ItemProductAttributeTermsListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.attributeTermsName.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemSelectedListener != null)
                itemSelectedListener.onProductAttributeSelected(getLayoutPosition(), arrayList.get(getAdapterPosition()).getTermsName());
        }
    }
}
