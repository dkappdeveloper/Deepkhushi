package com.shoppingapp.deepkhushi.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.ActivityStripePaymentLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.stripe.android.ApiResultCallback;
import com.stripe.android.Stripe;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;

import org.jetbrains.annotations.NotNull;

/**
 * Created by Deepak Kumar on 06-Nov-19.
 */
public class StripePaymentActivity extends BaseActivity {

    ActivityStripePaymentLayoutBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {

    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_stripe_payment_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_stripe));
    }

    private void initListener() {
        binding.stripePay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createStripeToken();
            }
        });
    }

    private void createStripeToken() {
        progressDialog.show();
        Stripe stripe = new Stripe(this, getString(R.string.stripe_publish_key));
        Card card = binding.stripeCardInfo.getCard();

        if (card != null) {
            stripe.createToken(card, new ApiResultCallback<Token>() {
                @Override
                public void onSuccess(Token token) {
                    progressDialog.dismiss();

                    Intent intent = new Intent();
                    intent.putExtra(AppConstants.BUNDLE_STRIPE_TOKEN, token.getId());
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                }

                @Override
                public void onError(@NotNull Exception e) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));

                    Intent intent = new Intent();
                    setResult(Activity.RESULT_CANCELED, intent);
                    finish();
                }
            });

        } else {
            AppHelper.showShortToast(context, getString(R.string.invalid_card));
        }
    }
}
