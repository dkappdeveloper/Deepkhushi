package com.shoppingapp.deepkhushi.database.dao;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.FavouritesModel;

import java.util.List;

@Dao
public interface FavouritesDao {

    @Insert
    void insert(FavouritesModel favoritesModel);

    @Query("SELECT * FROM " + DaoHelper.FAVOURITE_PRODUCT_TBL + " ORDER BY " + DaoHelper.COLUMN_AUTO_ID + " DESC")
    List<FavouritesModel> getAll();

    @Query("SELECT * FROM " + DaoHelper.FAVOURITE_PRODUCT_TBL + " WHERE " + DaoHelper.COLUMN_PRODUCT_ID + " = :productId LIMIT 1")
    FavouritesModel getFavoriteProduct(int productId);

    @Query("DELETE FROM " + DaoHelper.FAVOURITE_PRODUCT_TBL + " WHERE " + DaoHelper.COLUMN_PRODUCT_ID + " = :productId")
    void deleteFavoriteProduct(int productId);

    @Delete
    void delete(FavouritesModel favouritesModel);
}
