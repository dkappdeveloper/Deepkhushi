package com.shoppingapp.deepkhushi.model.order;

/**
 * Created by Sahidul Islam on 17-Feb-20.
 */

public class PaymentMethodModel {

    private int id;
    private String title;
    private String method;
    private int icon;
    private Boolean isSelected;

    public PaymentMethodModel() {
    }

    public PaymentMethodModel(int id, String title, String method, int icon, Boolean isSelected) {
        this.id = id;
        this.title = title;
        this.method = method;
        this.icon = icon;
        this.isSelected = isSelected;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public Boolean getSelected() {
        return isSelected;
    }

    public void setSelected(Boolean selected) {
        isSelected = selected;
    }
}
