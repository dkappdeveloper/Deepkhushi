
package com.shoppingapp.deepkhushi.model.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductReviewModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("date_created")
    @Expose
    private String dateCreated;
    @SerializedName("date_created_gmt")
    @Expose
    private String dateCreatedGmt;
    @SerializedName("product_id")
    @Expose
    private Integer productId;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("reviewer")
    @Expose
    private String reviewer;
    @SerializedName("reviewer_email")
    @Expose
    private String reviewerEmail;
    @SerializedName("review")
    @Expose
    private String review;
    @SerializedName("rating")
    @Expose
    private Integer rating;
    @SerializedName("verified")
    @Expose
    private Boolean verified;
    @SerializedName("reviewer_avatar_urls")
    @Expose
    private ReviewerAvatarUrls reviewerAvatarUrls;
    public final static Creator<ProductReviewModel> CREATOR = new Creator<ProductReviewModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public ProductReviewModel createFromParcel(Parcel in) {
            return new ProductReviewModel(in);
        }

        public ProductReviewModel[] newArray(int size) {
            return (new ProductReviewModel[size]);
        }

    }
    ;

    protected ProductReviewModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.dateCreated = ((String) in.readValue((String.class.getClassLoader())));
        this.dateCreatedGmt = ((String) in.readValue((String.class.getClassLoader())));
        this.productId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.status = ((String) in.readValue((String.class.getClassLoader())));
        this.reviewer = ((String) in.readValue((String.class.getClassLoader())));
        this.reviewerEmail = ((String) in.readValue((String.class.getClassLoader())));
        this.review = ((String) in.readValue((String.class.getClassLoader())));
        this.rating = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.verified = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        this.reviewerAvatarUrls = ((ReviewerAvatarUrls) in.readValue((ReviewerAvatarUrls.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public ProductReviewModel() {
    }

    /**
     * 
     * @param id
     * @param reviewerEmail
     * @param dateCreatedGmt
     * @param status
     * @param verified
     * @param dateCreated
     * @param reviewer
     * @param reviewerAvatarUrls
     * @param rating
     * @param review
     * @param productId
     */
    public ProductReviewModel(Integer id, String dateCreated, String dateCreatedGmt, Integer productId, String status, String reviewer, String reviewerEmail, String review, Integer rating, Boolean verified, ReviewerAvatarUrls reviewerAvatarUrls) {
        super();
        this.id = id;
        this.dateCreated = dateCreated;
        this.dateCreatedGmt = dateCreatedGmt;
        this.productId = productId;
        this.status = status;
        this.reviewer = reviewer;
        this.reviewerEmail = reviewerEmail;
        this.review = review;
        this.rating = rating;
        this.verified = verified;
        this.reviewerAvatarUrls = reviewerAvatarUrls;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getDateCreatedGmt() {
        return dateCreatedGmt;
    }

    public void setDateCreatedGmt(String dateCreatedGmt) {
        this.dateCreatedGmt = dateCreatedGmt;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReviewer() {
        return reviewer;
    }

    public void setReviewer(String reviewer) {
        this.reviewer = reviewer;
    }

    public String getReviewerEmail() {
        return reviewerEmail;
    }

    public void setReviewerEmail(String reviewerEmail) {
        this.reviewerEmail = reviewerEmail;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Boolean getVerified() {
        return verified;
    }

    public void setVerified(Boolean verified) {
        this.verified = verified;
    }

    public ReviewerAvatarUrls getReviewerAvatarUrls() {
        return reviewerAvatarUrls;
    }

    public void setReviewerAvatarUrls(ReviewerAvatarUrls reviewerAvatarUrls) {
        this.reviewerAvatarUrls = reviewerAvatarUrls;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(dateCreated);
        dest.writeValue(dateCreatedGmt);
        dest.writeValue(productId);
        dest.writeValue(status);
        dest.writeValue(reviewer);
        dest.writeValue(reviewerEmail);
        dest.writeValue(review);
        dest.writeValue(rating);
        dest.writeValue(verified);
        dest.writeValue(reviewerAvatarUrls);
    }

    public int describeContents() {
        return  0;
    }

}
