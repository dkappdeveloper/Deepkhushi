package com.shoppingapp.deepkhushi.listener;

/**
 * Created by Deepak Kumar on 08-Mar-19.
 */
public interface FilterItemClickCallbackListener {
    void onFilterItemClickGetCallback(String termId, String attributeSlug);
}
