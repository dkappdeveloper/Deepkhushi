package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConfig;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.cache.preference.ProfilePreference;
import com.shoppingapp.deepkhushi.databinding.ActivityLoginLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.ValidationHelper;
import com.shoppingapp.deepkhushi.listener.LoginListener;
import com.shoppingapp.deepkhushi.model.customer.CustomerModel;
import com.shoppingapp.deepkhushi.model.customer.ErrorModel;
import com.shoppingapp.deepkhushi.model.customer.LoginModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.gson.Gson;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 19-Jan-19.
 */

public class LoginActivity extends BaseActivity implements LoginListener {

    ActivityLoginLayoutBinding binding;

    private CustomerModel model = null;

    private FirebaseAuth firebaseAuth;
    private String totalAmount;
    private Boolean checkOutOrder = false;
    private Boolean buyNow = false;
    private Boolean homeLogin = false;
    private List<HashMap> orderNotes;
    private List<ProductCartModel> orderList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
    }

    @Override
    public void onLoginResponse(@NonNull LoginModel loginModel) {
        if (loginModel.getEmail() != null) {
            checkAndCreateCustomer(loginModel);
        }
    }

    private void initVars() {
        firebaseAuth = FirebaseAuth.getInstance();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {

            if (bundle.containsKey(AppConstants.BUNDLE_ORDER_NOTES))
                orderNotes = (List<HashMap>) bundle.getSerializable(AppConstants.BUNDLE_ORDER_NOTES);

            if (bundle.containsKey(AppConstants.BUNDLE_CHECKOUT_PRODUCTS))
                orderList = (List<ProductCartModel>) bundle.getSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS);

            if (bundle.containsKey(AppConstants.BUNDLE_PAYMENT_TOTAL))
                totalAmount = bundle.getString(AppConstants.BUNDLE_PAYMENT_TOTAL);

            if (bundle.containsKey(AppConstants.BUNDLE_BUY_NOW))
                buyNow = bundle.getBoolean(AppConstants.BUNDLE_BUY_NOW);

            if (bundle.containsKey(AppConstants.BUNDLE_CHECKOUT_LOGIN))
                checkOutOrder = bundle.getBoolean(AppConstants.BUNDLE_CHECKOUT_LOGIN);

            if (bundle.containsKey(AppConstants.BUNDLE_HOME_LOGIN))
                homeLogin = bundle.getBoolean(AppConstants.BUNDLE_HOME_LOGIN);
        }
    }

    private void initView() {
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_login_layout);

        Boolean skippedLogin = AppPreference.getInstance(getApplicationContext()).getBoolean(PrefKey.SKIP_SIGN_IN);

        if (skippedLogin) binding.skipLogin.setVisibility(View.GONE);

        if (AppConfig.FACEBOOK_LOGIN) {
            initFbLogin();
            binding.fbLoginBtn.setVisibility(View.VISIBLE);
        } else {
            binding.fbLoginBtn.setVisibility(View.GONE);
        }

        if (AppConfig.GOOGLE_LOGIN) {
            setGoogleButtonText(binding.gpLoginBtn, getString(R.string.google_cap));
            binding.gpLoginBtn.setVisibility(View.VISIBLE);
        } else {
            binding.gpLoginBtn.setVisibility(View.GONE);
        }
    }

    private void initListener() {
        setLoginListener(this);
        binding.skipLogin.setOnClickListener(onViewItemClick());
        binding.gpLoginBtn.setOnClickListener(onViewItemClick());
        binding.txtForgotPassword.setOnClickListener(onViewItemClick());
        binding.txtCreateAccount.setOnClickListener(onViewItemClick());
        binding.btnCustomLogin.setOnClickListener(onViewItemClick());
    }

    private void initFbLogin() {
        binding.fbLoginBtn.setPermissions(Arrays.asList("public_profile", "email"));
        binding.fbLoginBtn.registerCallback(callbackManager, fbCallback());
    }

    private void createAccount() {
        Bundle bundle = new Bundle();
        bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
        bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) orderList);
        bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, String.valueOf(totalAmount));
        bundle.putBoolean(AppConstants.BUNDLE_CHECKOUT_LOGIN, checkOutOrder);
        bundle.putBoolean(AppConstants.BUNDLE_HOME_LOGIN, homeLogin);
        startActivity(new Intent(LoginActivity.this, CreateAccountActivity.class).putExtras(bundle));
        finish();
    }

    private void validateCustomer() {
        final String email = binding.inputLoginEmail.getText().toString().trim();
        final String password = binding.inputLoginPassword.getText().toString().trim();

        if (!ValidationHelper.isValidEmail(email)) {
            AppHelper.showLongToast(context, getString(R.string.msg_invalid_email));
        } else if (!ValidationHelper.isPassLengthOk(password)) {
            AppHelper.showLongToast(context, getString(R.string.msg_length_password));
        } else {
            progressDialog.show();

            firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                //  progressDialog.dismiss();
                                checkCustomer(email);
                            }
                        }
                    })
                    .addOnFailureListener(this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            AppHelper.showLongToast(context, e.getMessage());
                            progressDialog.dismiss();
                        }
                    });
        }
    }

    private void checkCustomer(String email) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            // progressDialog.show();

            HashMap<String, String> customerByEmail = ApiRequests.buildCustomerByEmail(email);
            ApiClient.getInstance().getApiInterface().getCustomer(customerByEmail).enqueue(new Callback<List<CustomerModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<CustomerModel>> call, @NonNull Response<List<CustomerModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null && response.body().size() != 0) {
                            model = response.body().get(0);
                            LoginModel loginModel = new LoginModel(model.getId().toString(), model.getFirstName(), model.getLastName(), model.getEmail(), model.getAvatarUrl());
                            saveAndLogin(loginModel);
                        } else {
                            AppHelper.showLongToast(context, getString(R.string.account_not_found));
                        }
                    } else {
                        ErrorModel message = new Gson().fromJson(response.errorBody().charStream(), ErrorModel.class);
                        AppHelper.showLongToast(context, message.getMessage());
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<List<CustomerModel>> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void checkAndCreateCustomer(final LoginModel loginModel) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();

            HashMap<String, String> customerByEmail = ApiRequests.buildCustomerByEmail(loginModel.getEmail());
            ApiClient.getInstance().getApiInterface().getCustomer(customerByEmail).enqueue(new Callback<List<CustomerModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<CustomerModel>> call, @NonNull Response<List<CustomerModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null && response.body().size() != 0) {
                            model = response.body().get(0);
                            saveAndLogin(loginModel);
                        } else {
                            createCustomer(loginModel);
                        }
                    } else {
                        ErrorModel message = new Gson().fromJson(response.errorBody().charStream(), ErrorModel.class);
                        AppHelper.showLongToast(context, message.getMessage());
                    }
                    progressDialog.show();
                }

                @Override
                public void onFailure(@NonNull Call<List<CustomerModel>> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void createCustomer(final LoginModel loginModel) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();

            String firstname = loginModel.getFirstName();
            String lastname = loginModel.getLastName();
            if (lastname.equals("")) lastname = firstname;
            if (firstname.equals("")) firstname = lastname;

            HashMap<String, String> newCustomer = ApiRequests.buildNewCustomer(loginModel.getEmail(), firstname, lastname, loginModel.getEmail(), AppConstants.DEFAULT_PASSWORD);
            ApiClient.getInstance().getApiInterface().createCustomer(newCustomer).enqueue(new Callback<CustomerModel>() {
                @Override
                public void onResponse(@NonNull Call<CustomerModel> call, @NonNull Response<CustomerModel> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            model = response.body();
                            saveAndLogin(loginModel);
                        }
                    } else {
                        ErrorModel message = new Gson().fromJson(response.errorBody().charStream(), ErrorModel.class);
                        AppHelper.showLongToast(context, message.getMessage());
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<CustomerModel> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void saveAndLogin(@NonNull LoginModel loginModel) {
        ProfilePreference.saveUserProfileData(getApplicationContext(), String.valueOf(model.getId()), loginModel.getFirstName(),
                loginModel.getLastName(), model.getUsername(), loginModel.getEmail(), loginModel.getProfileImage());
        AppPreference.getInstance(context).setBoolean(PrefKey.SIGNED_IN, true);

        AppPreference.getInstance(this).setString(PrefKey.FIRST_NAME_BILL, loginModel.getFirstName());
        AppPreference.getInstance(this).setString(PrefKey.LAST_NAME_BILL, loginModel.getLastName());
        AppPreference.getInstance(this).setString(PrefKey.EMAIL_BILL, loginModel.getEmail());

        if (checkOutOrder) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
            bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) orderList);
            bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, String.valueOf(totalAmount));
            bundle.putBoolean(AppConstants.BUNDLE_BUY_NOW, buyNow);
            startActivity(new Intent(LoginActivity.this, CheckoutAddressActivity.class).putExtras(bundle));
            finish();
        } else if (homeLogin) {
            finish();
        } else {
            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
            finish();
        }
    }

    private View.OnClickListener onViewItemClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.gp_login_btn:
                        invokeGPLogin();
                        break;
                    case R.id.skip_login:
                        AppPreference.getInstance(context).setBoolean(PrefKey.SKIP_SIGN_IN, true);
                        startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                        break;
                    case R.id.txt_create_account:
                        createAccount();
                        break;
                    case R.id.txt_forgot_password:
                        startActivity(new Intent(LoginActivity.this, ResetPasswordActivity.class));
                        break;
                    case R.id.btn_custom_login:
                        validateCustomer();
                        break;
                }
            }
        };
    }
}
