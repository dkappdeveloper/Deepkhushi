package com.shoppingapp.deepkhushi.network;

import com.shoppingapp.deepkhushi.helper.DataMapingHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.model.product.ProductCouponModel;
import com.shoppingapp.deepkhushi.model.product.ProductSearchModel;
import com.shoppingapp.deepkhushi.model.shipping.ShippingMethodModel;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.List;

/**
 * Created by Deepak Kumar on 23-Jan-19.
 */

public class ApiRequests {

    public static HashMap<String, String> buildNewCustomer(String email, String firstName, String lastName, String username, String password) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_EMAIL, email);
        hashMap.put(ApiConfig.KEY_FIRSTNAME, firstName);
        hashMap.put(ApiConfig.KEY_LASTNAME, lastName);
        hashMap.put(ApiConfig.KEY_USERNAME, username);
        hashMap.put(ApiConfig.KEY_PASSWORD, password);

        return hashMap;
    }

    public static HashMap<String, String> buildCustomerByEmail(String email) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_EMAIL, email);

        return hashMap;
    }

    public static HashMap<String, String> buildCustomerLogin(String email, String password) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_USERNAME, email);
        hashMap.put(ApiConfig.KEY_PASSWORD, password);

        return hashMap;
    }

    public static HashMap<String, String> buildCategoryList(Boolean hideEmpty, int perPage) {
        HashMap<String, String> hashMap = new HashMap<>();

        if (hideEmpty) hashMap.put(ApiConfig.KEY_HIDE_EMPTY, "true");
        hashMap.put(ApiConfig.KEY_PER_PAGE, String.valueOf(perPage));

        return hashMap;
    }

    public static HashMap<String, String> buildProductList(ProductSearchModel model) {
        HashMap<String, String> hashMap = new HashMap<>();
        // hashMap.put(KEY_ON_SALE, "true");

        if (model.getFeatured() != null)
            hashMap.put(ApiConfig.KEY_FEATURED, model.getFeatured());
        if (model.getOrderBy() != null) hashMap.put(ApiConfig.KEY_ORDER_BY, model.getOrderBy());
        if (model.getOrder() != null) hashMap.put(ApiConfig.KEY_ORDER, model.getOrder());
        if (model.getDateAfter() != null) hashMap.put(ApiConfig.KEY_AFTER, model.getDateAfter());
        if (model.getTagId() > 0) hashMap.put(ApiConfig.KEY_TAG, String.valueOf(model.getTagId()));
        if (model.getCategoryId() != null)
            hashMap.put(ApiConfig.KEY_CATEGORY, model.getCategoryId());
        if (model.getAttribute() != null)
            hashMap.put(ApiConfig.KEY_ATTRIBUTE, model.getAttribute());
        if (model.getAttributeTerm() != null)
            hashMap.put(ApiConfig.KEY_ATTRIBUTE_TERM, model.getAttributeTerm());
        if (model.getPage() > 0) hashMap.put(ApiConfig.KEY_PAGE, String.valueOf(model.getPage()));
        if (model.getPerPage() > 0)
            hashMap.put(ApiConfig.KEY_PER_PAGE, String.valueOf(model.getPerPage()));
        if (model.getSearchKey() != null) hashMap.put(ApiConfig.KEY_SEARCH, model.getSearchKey());
        if (model.getMinPrice() != null) hashMap.put(ApiConfig.KEY_MIN_PRICE, model.getMinPrice());
        if (model.getMaxPrice() != null) hashMap.put(ApiConfig.KEY_MAX_PRICE, model.getMaxPrice());

        return hashMap;
    }

    public static HashMap<String, String> buildProductTagBySlug(String slug) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_SLUG, slug);

        return hashMap;
    }

    public static HashMap<String, String> buildProductReview(int productId, String reviewer, String email, String rating, String review) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_PRODUCT_ID, String.valueOf(productId));
        hashMap.put(ApiConfig.KEY_REVIEWER, reviewer);
        hashMap.put(ApiConfig.KEY_REVIEWER_EMAIL, email);
        hashMap.put(ApiConfig.KEY_REVIEW_RATING, rating);
        hashMap.put(ApiConfig.KEY_REVIEW, review);

        return hashMap;
    }

    public static HashMap<String, String> buildProductReviewList(int productId, int pageNo) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_PRODUCT, String.valueOf(productId));
        hashMap.put(ApiConfig.KEY_PAGE, String.valueOf(pageNo));

        return hashMap;
    }

    public static HashMap<String, String> buildOrderNote(String noteItem) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_ORDER_NOTE, noteItem);
        hashMap.put(ApiConfig.KEY_CUSTOMER_NOTE, "true");

        return hashMap;
    }

    private static JsonObject getBilling(HashMap<String, String> billingAddress) {
        JsonObject jObject = new JsonObject();

        try {
            jObject.addProperty(DataMapingHelper.KEY_FIRST_NAME, billingAddress.get(DataMapingHelper.KEY_FIRST_NAME));
            jObject.addProperty(DataMapingHelper.KEY_LAST_NAME, billingAddress.get(DataMapingHelper.KEY_LAST_NAME));
            jObject.addProperty(DataMapingHelper.KEY_ADDRESS, billingAddress.get(DataMapingHelper.KEY_ADDRESS));
            jObject.addProperty(DataMapingHelper.KEY_CITY, billingAddress.get(DataMapingHelper.KEY_CITY));
            jObject.addProperty(DataMapingHelper.KEY_STATE_CODE, billingAddress.get(DataMapingHelper.KEY_STATE_CODE));
            jObject.addProperty(DataMapingHelper.KEY_POST_CODE, billingAddress.get(DataMapingHelper.KEY_POST_CODE));
            jObject.addProperty(DataMapingHelper.KEY_COUNTRY_CODE, billingAddress.get(DataMapingHelper.KEY_COUNTRY_CODE));
            jObject.addProperty(DataMapingHelper.KEY_EMAIL, billingAddress.get(DataMapingHelper.KEY_EMAIL));
            jObject.addProperty(DataMapingHelper.KEY_PHONE, billingAddress.get(DataMapingHelper.KEY_PHONE));

            return jObject;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static JsonObject getShipping(HashMap<String, String> shippingAddress) {
        JsonObject jObject = new JsonObject();

        try {
            jObject.addProperty(DataMapingHelper.KEY_FIRST_NAME, shippingAddress.get(DataMapingHelper.KEY_FIRST_NAME));
            jObject.addProperty(DataMapingHelper.KEY_LAST_NAME, shippingAddress.get(DataMapingHelper.KEY_LAST_NAME));
            jObject.addProperty(DataMapingHelper.KEY_ADDRESS, shippingAddress.get(DataMapingHelper.KEY_ADDRESS));
            jObject.addProperty(DataMapingHelper.KEY_CITY, shippingAddress.get(DataMapingHelper.KEY_CITY));
            jObject.addProperty(DataMapingHelper.KEY_STATE_CODE, shippingAddress.get(DataMapingHelper.KEY_STATE_CODE));
            jObject.addProperty(DataMapingHelper.KEY_POST_CODE, shippingAddress.get(DataMapingHelper.KEY_POST_CODE));
            jObject.addProperty(DataMapingHelper.KEY_COUNTRY_CODE, shippingAddress.get(DataMapingHelper.KEY_COUNTRY_CODE));

            return jObject;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static JsonArray getOrderLineItems(List<ProductCartModel> orderList) {
        JsonArray jArray = new JsonArray();

        try {
            for (ProductCartModel model : orderList) {
                JsonObject jObject = new JsonObject();

                jObject.addProperty(ApiConfig.KEY_PRODUCT_ID, model.getProductId());
                jObject.addProperty(DataMapingHelper.KEY_PRODUCT_NAME, model.getProductName());
                jObject.addProperty(DataMapingHelper.KEY_PRODUCT_QUANTITY, model.getProductQuantity());

                jArray.add(jObject);
            }

            return jArray;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static JsonArray getCouponLineItems(ProductCouponModel model, Double totalDiscount) {
        JsonArray jArray = new JsonArray();

        try {
            JsonObject jObject = new JsonObject();

            jObject.addProperty(ApiConfig.KEY_ID, model.getId());
            jObject.addProperty(ApiConfig.KEY_CODE, model.getCode());
            jObject.addProperty(ApiConfig.KEY_DISCOUNT, String.format("%.2f", totalDiscount));

            jArray.add(jObject);

            return jArray;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static JsonArray getShippingLineItems(ShippingMethodModel model) {
        JsonArray jArray = new JsonArray();

        try {
            JsonObject jObject = new JsonObject();

            jObject.addProperty(ApiConfig.KEY_METHOD_ID, model.getMethodId());
            jObject.addProperty(ApiConfig.KEY_METHOD_TITLE, model.getTitle());

            if (model.getSettings().getCost() != null) {
                Double shippingCost = Double.parseDouble(model.getSettings().getCost().getValue());
                jObject.addProperty(ApiConfig.KEY_TOTAL, String.format("%.2f", shippingCost));
            }

            jArray.add(jObject);

            return jArray;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static JsonObject buildOrderRequest(String customerId, String paymentMethod, String paymentMethodTitle, Boolean isPaid,
                                               HashMap<String, String> billingAddress, HashMap<String, String> shippingAddress,
                                               List<ProductCartModel> orderList, ProductCouponModel couponModel, ShippingMethodModel methodModel,
                                               Double totalDiscount, Double totalAmount, String transactionId) {
        JsonObject jObject = new JsonObject();
        try {
            jObject.addProperty(ApiConfig.KEY_CUSTOMER_ID, customerId);
            jObject.addProperty(ApiConfig.KEY_PAYMENT_SET_PAID, isPaid);
            jObject.addProperty(ApiConfig.KEY_PAYMENT_METHOD, paymentMethod);
            jObject.addProperty(ApiConfig.KEY_PAYMENT_METHOD_TITLE, paymentMethodTitle);
            jObject.addProperty(ApiConfig.KEY_TRANSACTION_ID, transactionId);
            jObject.addProperty(ApiConfig.KEY_TOTAL, String.format("%.2f", totalAmount));
            jObject.add(ApiConfig.KEY_ORDER_LINE_ITEM, getOrderLineItems(orderList));
            jObject.add(ApiConfig.KEY_ORDER_BILLING, getBilling(billingAddress));
            jObject.add(ApiConfig.KEY_ORDER_SHIPPING, getShipping(shippingAddress));

            if (couponModel != null) {
                jObject.addProperty(ApiConfig.KEY_DISCOUNT_TOTAL, String.format("%.2f", totalDiscount));
                jObject.add(ApiConfig.KEY_COUPON_LINE_ITEM, getCouponLineItems(couponModel, totalDiscount));
            }

            if (methodModel != null && methodModel.getSettings().getCost() != null) {
                Double shippingCost = Double.parseDouble(methodModel.getSettings().getCost().getValue());
                jObject.addProperty(ApiConfig.KEY_SHIPPING_TOTAL, String.format("%.2f", shippingCost));
            }

            if (methodModel != null) {
                jObject.add(ApiConfig.KEY_SHIPPING_LINE_ITEM, getShippingLineItems(methodModel));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return jObject;
    }

    public static HashMap<String, String> buildCancelOrder() {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_FORCE, "true");

        return hashMap;
    }

    public static HashMap<String, String> buildPaypalRequest(String type, String nonce, String amount) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_TYPE, type);
        if (!nonce.isEmpty()) hashMap.put(ApiConfig.KEY_NONCE, nonce);
        if (!amount.isEmpty()) hashMap.put(ApiConfig.KEY_AMOUNT, amount);

        return hashMap;
    }

    public static HashMap<String, String> buildStripeRequest(String token, String currency,
                                                             String paymentTitle, String amount) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put(ApiConfig.KEY_STRIPE_TOKEN, token);
        hashMap.put(ApiConfig.KEY_CURRENCY, currency);
        hashMap.put(ApiConfig.KEY_PAYMENT_TITLE, paymentTitle);
        hashMap.put(ApiConfig.KEY_AMOUNT, amount);

        return hashMap;
    }

}
