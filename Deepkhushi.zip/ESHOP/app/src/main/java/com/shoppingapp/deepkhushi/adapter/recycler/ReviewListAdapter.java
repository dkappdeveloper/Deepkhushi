package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemReviewListLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DateHelper;
import com.shoppingapp.deepkhushi.listener.ItemViewClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductReviewModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 03-Jul-19.
 */

public class ReviewListAdapter extends RecyclerView.Adapter<ReviewListAdapter.ReviewListViewHolder> {

    private Context context;
    private List<ProductReviewModel> arrayList;

    private ItemViewClickListener itemClickListener;

    public ReviewListAdapter(Context context) {
        this.context = context;
    }

    public ReviewListAdapter(Context context, List<ProductReviewModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemViewClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ReviewListAdapter.ReviewListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new ReviewListViewHolder((ItemReviewListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_review_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewListAdapter.ReviewListViewHolder holder, int position) {
        String reviewerImage = arrayList.get(position).getReviewerAvatarUrls().get96();
        String reviewerName = arrayList.get(position).getReviewer();
        String review = arrayList.get(position).getReview();
        String reviewDate = DateHelper.formateISODate(arrayList.get(position).getDateCreated());
        int reviewRating = arrayList.get(position).getRating();

        String categorySign = String.valueOf(reviewerName.charAt(0));
        ColorGenerator colorGenerator = ColorGenerator.MATERIAL;
        int color = colorGenerator.getRandomColor();

        TextDrawable textDrawable = TextDrawable.builder()
                .beginConfig()
                .textColor(color)
                .useFont(Typeface.DEFAULT)
                .bold()
                .toUpperCase()
                .withBorder(4)
                .endConfig()
                .buildRound(categorySign, Color.WHITE );

        holder.binding.avatarImage.setImageDrawable(textDrawable);

        holder.binding.reviewerName.setText(reviewerName);
        holder.binding.reviewDate.setText(reviewDate);
        holder.binding.reviewContent.setText(AppHelper.fromHtml(review));
        holder.binding.reviewRating.setRating(reviewRating);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ReviewListViewHolder extends RecyclerView.ViewHolder {

        ItemReviewListLayoutBinding binding;

        public ReviewListViewHolder(@NonNull ItemReviewListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;
        }
    }
}
