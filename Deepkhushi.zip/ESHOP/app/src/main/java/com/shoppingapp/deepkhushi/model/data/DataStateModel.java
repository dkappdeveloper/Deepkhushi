package com.shoppingapp.deepkhushi.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DataStateModel implements Parcelable {

    public final static Creator<DataStateModel> CREATOR = new Creator<DataStateModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public DataStateModel createFromParcel(Parcel in) {
            return new DataStateModel(in);
        }

        public DataStateModel[] newArray(int size) {
            return (new DataStateModel[size]);
        }

    };
    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("name")
    @Expose
    private String name;

    protected DataStateModel(Parcel in) {
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     */
    public DataStateModel() {
    }

    /**
     * @param name
     * @param code
     */
    public DataStateModel(String code, String name) {
        super();
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(code);
        dest.writeValue(name);
    }

    public int describeContents() {
        return 0;
    }

}
