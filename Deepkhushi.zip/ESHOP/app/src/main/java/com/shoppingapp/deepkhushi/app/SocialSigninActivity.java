package com.shoppingapp.deepkhushi.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.LoginListener;
import com.shoppingapp.deepkhushi.model.customer.LoginModel;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by Deepak Kumar on 21-Jan-19.
 */

public abstract class SocialSigninActivity extends AppCompatActivity {

    public CallbackManager callbackManager;
    private GoogleSignInClient googleSignInClient;
    private LoginListener loginListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        callbackManager = CallbackManager.Factory.create();
        initGPLogin();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == AppConstants.GP_REQUEST_CODE) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {
                getGPProfileInfo(result);
            } else {
                AppHelper.showShortToast(this, "Failed");
            }
        } else {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void initGPLogin() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    public void invokeGPLogin() {
        signOutGP();
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, AppConstants.GP_REQUEST_CODE);
    }

    public FacebookCallback<LoginResult> fbCallback() {
        return new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                AccessToken accessToken = loginResult.getAccessToken();

                GraphRequest request = GraphRequest.newMeRequest(
                        accessToken, new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                try {
                                    String id = object.getString("id");
                                    String firstName = object.getString("first_name");
                                    String lastName = object.getString("last_name");
                                    String email = object.getString("email");
                                    //String gender = object.getString("gender");

                                    loginListener.onLoginResponse(new LoginModel(id, firstName, lastName, email, getFBProfilePicture(id)));

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id, first_name, last_name, email, gender");
                request.setParameters(parameters);
                request.executeAsync();
            }

            @Override
            public void onCancel() {
                signOutFB();
            }

            @Override
            public void onError(FacebookException error) {
                signOutFB();
                Log.e("onError: ", error.getLocalizedMessage());
            }
        };
    }

    private void getGPProfileInfo(GoogleSignInResult result) {
        if (result.isSuccess()) {
            GoogleSignInAccount account = result.getSignInAccount();

            String id = account.getId();
            String name = account.getDisplayName();
            String email = account.getEmail();
            String photo = account.getPhotoUrl() == null ? "" : account.getPhotoUrl().toString() + "?sz=400";

            loginListener.onLoginResponse(new LoginModel(id, name, AppConstants.EMPTY_STRING, email, photo));
        }
    }

    public String getFBProfilePicture(String userID) {
        return "https://graph.facebook.com/" + userID + "/picture?width=" + 400 + "&height=" + 400;
    }

    private void signOutFB() {
        LoginManager.getInstance().logOut();
    }

    private void signOutGP() {
        googleSignInClient.signOut();
    }

    public void setGoogleButtonText(SignInButton view, String text) {
        if (view != null) {
            for (int i = 0; i < view.getChildCount(); i++) {
                View v = view.getChildAt(i);

                if (v instanceof TextView) {
                    TextView tv = (TextView) v;
                    tv.setText(text);
                    return;
                }
            }
        }
    }

    public void setLoginListener(LoginListener loginListener) {
        this.loginListener = loginListener;
    }
}
