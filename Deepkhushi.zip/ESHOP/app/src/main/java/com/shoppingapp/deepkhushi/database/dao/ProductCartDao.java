package com.shoppingapp.deepkhushi.database.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface ProductCartDao {

    @Insert
    void insert(ProductCartModel cartModel);

    @Insert
    void insertAll(ArrayList<ProductCartModel> cartModels);

    @Query("SELECT * FROM " + DaoHelper.PRODUCT_CART_TBL + " WHERE " + DaoHelper.COLUMN_PRODUCT_ID + " = :productId LIMIT 1")
    ProductCartModel getProduct(int productId);

    @Query("SELECT * FROM " + DaoHelper.PRODUCT_CART_TBL)
    List<ProductCartModel> getAll();

    @Query("UPDATE " + DaoHelper.PRODUCT_CART_TBL + " SET " + DaoHelper.COLUMN_PRODUCT_QUANTITY + "= :quantity , "
            + DaoHelper.COLUMN_TOTAL_PRICE + "=:totalprice  WHERE " + DaoHelper.COLUMN_PRODUCT_ID + "=:productId")
    void updateCartProduct(String quantity, String totalprice, int productId);

    @Query("DELETE FROM " + DaoHelper.PRODUCT_CART_TBL + " WHERE " + DaoHelper.COLUMN_PRODUCT_ID + " = :productId")
    void deleteCartProduct(int productId);

    @Query("DELETE FROM " + DaoHelper.PRODUCT_CART_TBL)
    void deleteAllCartItems();

    @Delete
    void delete(ProductCartModel cartModel);
}
