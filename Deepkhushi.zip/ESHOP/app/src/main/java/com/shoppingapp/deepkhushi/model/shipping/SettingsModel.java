
package com.shoppingapp.deepkhushi.model.shipping;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SettingsModel implements Parcelable
{

    @SerializedName("title")
    @Expose
    private TitleModel title;
    @SerializedName("tax_status")
    @Expose
    private TaxStatusModel taxStatus;
    @SerializedName("cost")
    @Expose
    private CostModel cost;
    @SerializedName("requires")
    @Expose
    private RequiresModel requires;
    @SerializedName("min_amount")
    @Expose
    private MinAmountModel minAmount;
    public final static Creator<SettingsModel> CREATOR = new Creator<SettingsModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public SettingsModel createFromParcel(Parcel in) {
            return new SettingsModel(in);
        }

        public SettingsModel[] newArray(int size) {
            return (new SettingsModel[size]);
        }

    }
    ;

    protected SettingsModel(Parcel in) {
        this.title = ((TitleModel) in.readValue((TitleModel.class.getClassLoader())));
        this.taxStatus = ((TaxStatusModel) in.readValue((TaxStatusModel.class.getClassLoader())));
        this.cost = ((CostModel) in.readValue((CostModel.class.getClassLoader())));
        this.requires = ((RequiresModel) in.readValue((RequiresModel.class.getClassLoader())));
        this.minAmount = ((MinAmountModel) in.readValue((MinAmountModel.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public SettingsModel() {
    }

    /**
     * 
     * @param minAmount
     * @param cost
     * @param title
     * @param taxStatus
     * @param requires
     */
    public SettingsModel(TitleModel title, TaxStatusModel taxStatus, CostModel cost, RequiresModel requires, MinAmountModel minAmount) {
        super();
        this.title = title;
        this.taxStatus = taxStatus;
        this.cost = cost;
        this.requires = requires;
        this.minAmount = minAmount;
    }

    public TitleModel getTitle() {
        return title;
    }

    public void setTitle(TitleModel title) {
        this.title = title;
    }

    public TaxStatusModel getTaxStatus() {
        return taxStatus;
    }

    public void setTaxStatus(TaxStatusModel taxStatus) {
        this.taxStatus = taxStatus;
    }

    public CostModel getCost() {
        return cost;
    }

    public void setCost(CostModel cost) {
        this.cost = cost;
    }

    public RequiresModel getRequires() {
        return requires;
    }

    public void setRequires(RequiresModel requires) {
        this.requires = requires;
    }

    public MinAmountModel getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(MinAmountModel minAmount) {
        this.minAmount = minAmount;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(title);
        dest.writeValue(taxStatus);
        dest.writeValue(cost);
        dest.writeValue(requires);
        dest.writeValue(minAmount);
    }

    public int describeContents() {
        return  0;
    }

}
