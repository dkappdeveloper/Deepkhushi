package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.ItemMyOrdersLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DateHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.order.OrderModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 24-May-19.
 */
public class MyOrdersAdapter extends RecyclerView.Adapter<MyOrdersAdapter.MyOrdersViewHolder> {

    private Context context;
    private List<OrderModel> arrayList;

    private ItemClickListener itemClickListener;

    public MyOrdersAdapter() {
    }

    public MyOrdersAdapter(Context context, List<OrderModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public MyOrdersAdapter.MyOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new MyOrdersViewHolder((ItemMyOrdersLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_my_orders_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyOrdersAdapter.MyOrdersViewHolder holder, int position) {
        String orderId = String.valueOf(arrayList.get(position).getId());
        String productNum = String.valueOf(arrayList.get(position).getLineItemModels().size());
        String totalPrice = arrayList.get(position).getTotal();
        String currency = arrayList.get(position).getCurrency();
        String paymentMethod = arrayList.get(position).getPaymentMethodTitle();
        String orderDate = DateHelper.formateISODate(arrayList.get(position).getDateCreated());
        String orderStatus = arrayList.get(position).getStatus();

        holder.binding.orderId.setText(AppHelper.fromHtml(context.getResources().getString(R.string.order_id) + orderId));
        holder.binding.orderDate.setText(orderDate);
        holder.binding.totalNumProduct.setText(productNum + " (" + context.getResources().getString(R.string.items) + ")");
        holder.binding.paymentAmount.setText(totalPrice + " (" + currency + ")");
        holder.binding.paymentMethod.setText(paymentMethod);

        switch (orderStatus) {
            case AppConstants.ORDER_STATUS_PENDING:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_pending));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_pending));
                break;
            case AppConstants.ORDER_STATUS_PROCESSING:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_processing));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_processing));
                break;
            case AppConstants.ORDER_STATUS_ONHOLD:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_onhold));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_onhold));
                break;
            case AppConstants.ORDER_STATUS_COMPLETED:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_completed));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_completed));
                break;
            case AppConstants.ORDER_STATUS_CANCELLED:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_cancelled));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_cancelled));
                break;
            case AppConstants.ORDER_STATUS_REFUNDED:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_refunded));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_refunded));
                break;
            case AppConstants.ORDER_STATUS_FAILED:
                holder.binding.orderStatus.setText(context.getResources().getString(R.string.order_status_failed));
                holder.binding.orderStatus.setBackground(context.getResources().getDrawable(R.drawable.bg_status_failed));
                break;
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyOrdersViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemMyOrdersLayoutBinding binding;

        MyOrdersViewHolder(@NonNull ItemMyOrdersLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.parentView.setOnClickListener(this);
            binding.orderDetail.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemClickGetPosition(getAdapterPosition());
        }
    }
}
