package com.shoppingapp.deepkhushi.listener;

/**
 * Created by Deepak Kumar on 21-Apr-19.
 */
public interface ProductAttributeSelectedListener {
    void onProductAttributeSelected(int position, String term);
}
