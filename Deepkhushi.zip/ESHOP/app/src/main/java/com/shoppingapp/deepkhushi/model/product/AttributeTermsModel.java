package com.shoppingapp.deepkhushi.model.product;

/**
 * Created by Md Sahidul Islam on 20-Apr-19.
 */
public class AttributeTermsModel {

    private String termsName;
    private Boolean isSelected = false;


    public AttributeTermsModel() {
    }

    public AttributeTermsModel(String termsName) {
        this.termsName = termsName;
    }

    public String getTermsName() {
        return termsName;
    }

    public void setTermsName(String termsName) {
        this.termsName = termsName;
    }

    public Boolean isSelected() {
        return isSelected;
    }

    public void setSelected(Boolean selected) {
        isSelected = selected;
    }
}
