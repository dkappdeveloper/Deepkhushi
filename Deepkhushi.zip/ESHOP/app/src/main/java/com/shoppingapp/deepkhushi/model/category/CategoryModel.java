
package com.shoppingapp.deepkhushi.model.category;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CategoryModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("parent")
    @Expose
    private Integer parent;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("image")
    @Expose
    private CategoryImageModel categoryImageModel;
    @SerializedName("menu_order")
    @Expose
    private Integer menuOrder;
    @SerializedName("count")
    @Expose
    private Integer count;

    private Boolean isSelected = false;

    public final static Creator<CategoryModel> CREATOR = new Creator<CategoryModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public CategoryModel createFromParcel(Parcel in) {
            return new CategoryModel(in);
        }

        public CategoryModel[] newArray(int size) {
            return (new CategoryModel[size]);
        }

    }
    ;

    protected CategoryModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.slug = ((String) in.readValue((String.class.getClassLoader())));
        this.parent = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.description = ((String) in.readValue((String.class.getClassLoader())));
        this.categoryImageModel = ((CategoryImageModel) in.readValue((CategoryImageModel.class.getClassLoader())));
        this.menuOrder = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.count = ((Integer) in.readValue((Integer.class.getClassLoader())));
        isSelected = in.readByte() != 0;
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public CategoryModel() {
    }

    /**
     * 
     * @param id
     * @param count
     * @param description
     * @param name
     * @param menuOrder
     * @param categoryImageModel
     * @param parent
     * @param slug
     */
    public CategoryModel(Integer id, String name, String slug, Integer parent, String description, CategoryImageModel categoryImageModel, Integer menuOrder, Integer count) {
        super();
        this.id = id;
        this.name = name;
        this.slug = slug;
        this.parent = parent;
        this.description = description;
        this.categoryImageModel = categoryImageModel;
        this.menuOrder = menuOrder;
        this.count = count;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public Integer getParent() {
        return parent;
    }

    public void setParent(Integer parent) {
        this.parent = parent;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CategoryImageModel getCategoryImageModel() {
        return categoryImageModel;
    }

    public void setCategoryImageModel(CategoryImageModel categoryImageModel) {
        this.categoryImageModel = categoryImageModel;
    }

    public Integer getMenuOrder() {
        return menuOrder;
    }

    public void setMenuOrder(Integer menuOrder) {
        this.menuOrder = menuOrder;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Boolean getSelected() {
        return isSelected;
    }

    public void setSelected(Boolean selected) {
        isSelected = selected;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(name);
        dest.writeValue(slug);
        dest.writeValue(parent);
        dest.writeValue(description);
        dest.writeValue(categoryImageModel);
        dest.writeValue(menuOrder);
        dest.writeValue(count);
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }

    public int describeContents() {
        return  0;
    }

}
