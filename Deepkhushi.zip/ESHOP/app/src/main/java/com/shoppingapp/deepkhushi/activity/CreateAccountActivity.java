package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.cache.preference.ProfilePreference;
import com.shoppingapp.deepkhushi.databinding.ActivityCreateAccountLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.ValidationHelper;
import com.shoppingapp.deepkhushi.model.customer.LoginModel;
import com.shoppingapp.deepkhushi.model.customer.CustomerModel;
import com.shoppingapp.deepkhushi.model.customer.ErrorModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.gson.Gson;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 11-Jan-20.
 */

public class CreateAccountActivity extends BaseActivity {

    ActivityCreateAccountLayoutBinding binding;

    private CustomerModel model = null;

    private FirebaseAuth firebaseAuth;
    private String totalAmount;
    private Boolean checkOutOrder = false;
    private Boolean buyNow = false;
    private Boolean homeLogin = false;
    private List<HashMap> orderNotes;
    private List<ProductCartModel> orderList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
    }

    private void initVars() {
        firebaseAuth = FirebaseAuth.getInstance();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {

            if (bundle.containsKey(AppConstants.BUNDLE_ORDER_NOTES))
                orderNotes = (List<HashMap>) bundle.getSerializable(AppConstants.BUNDLE_ORDER_NOTES);

            if (bundle.containsKey(AppConstants.BUNDLE_CHECKOUT_PRODUCTS))
                orderList = (List<ProductCartModel>) bundle.getSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS);

            if (bundle.containsKey(AppConstants.BUNDLE_PAYMENT_TOTAL))
                totalAmount = bundle.getString(AppConstants.BUNDLE_PAYMENT_TOTAL);

            if (bundle.containsKey(AppConstants.BUNDLE_BUY_NOW))
                buyNow = bundle.getBoolean(AppConstants.BUNDLE_BUY_NOW);

            if (bundle.containsKey(AppConstants.BUNDLE_CHECKOUT_LOGIN))
                checkOutOrder = bundle.getBoolean(AppConstants.BUNDLE_CHECKOUT_LOGIN);

            if (bundle.containsKey(AppConstants.BUNDLE_HOME_LOGIN))
                homeLogin = bundle.getBoolean(AppConstants.BUNDLE_HOME_LOGIN);
        }
    }

    private void initView() {
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_create_account_layout);
    }

    private void initListener() {
        binding.txtAccountLogin.setOnClickListener(onViewItemClick());
        binding.btnCreateAccount.setOnClickListener(onViewItemClick());
    }

    private void accountLogin() {
        Bundle bundle = new Bundle();
        bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
        bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) orderList);
        bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, String.valueOf(totalAmount));
        bundle.putBoolean(AppConstants.BUNDLE_CHECKOUT_LOGIN, checkOutOrder);
        bundle.putBoolean(AppConstants.BUNDLE_HOME_LOGIN, homeLogin);
        startActivity(new Intent(CreateAccountActivity.this, LoginActivity.class).putExtras(bundle));
        finish();
    }

    private void validateCustomer() {
        final String firstName = binding.inputAccountFirstname.getText().toString().trim();
        final String lastName = binding.inputAccountLastname.getText().toString().trim();
        final String email = binding.inputAccountEmail.getText().toString().trim();
        final String password = binding.inputAccountPassword.getText().toString().trim();

        if (ValidationHelper.isEmpty(firstName)) {
            AppHelper.showLongToast(context, getString(R.string.msg_first_name));
        } else if (ValidationHelper.isEmpty(lastName)) {
            AppHelper.showLongToast(context, getString(R.string.msg_last_name));
        } else if (!ValidationHelper.isValidEmail(email)) {
            AppHelper.showLongToast(context, getString(R.string.msg_invalid_email));
        } else if (!ValidationHelper.isPassLengthOk(password)) {
            AppHelper.showLongToast(context, getString(R.string.msg_length_password));
        } else {
            progressDialog.show();
            firebaseAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // progressDialog.dismiss();
                                createCustomer(firstName, lastName, email, password);
                            }
                        }
                    })
                    .addOnFailureListener(this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            AppHelper.showLongToast(context, e.getMessage());
                            progressDialog.dismiss();
                        }
                    });
        }
    }

    private void createCustomer(String firstName, String lastName, String email, String password) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            progressDialog.show();

            HashMap<String, String> newCustomer = ApiRequests.buildNewCustomer(email, firstName, lastName, email, password);

            ApiClient.getInstance().getApiInterface().createCustomer(newCustomer).enqueue(new Callback<CustomerModel>() {
                @Override
                public void onResponse(@NonNull Call<CustomerModel> call, @NonNull Response<CustomerModel> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            model = response.body();

                            LoginModel loginModel = new LoginModel(model.getId().toString(), model.getFirstName(), model.getLastName(), model.getEmail(), model.getAvatarUrl());
                            saveAndLogin(loginModel);
                        }
                    } else {
                        ErrorModel message = new Gson().fromJson(response.errorBody().charStream(), ErrorModel.class);
                        AppHelper.showShortToast(context, message.getMessage());
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(@NonNull Call<CustomerModel> call, @NonNull Throwable t) {
                    progressDialog.dismiss();
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void saveAndLogin(@NonNull LoginModel loginModel) {
        ProfilePreference.saveUserProfileData(getApplicationContext(), String.valueOf(model.getId()), loginModel.getFirstName(),
                loginModel.getLastName(), model.getUsername(), loginModel.getEmail(), loginModel.getProfileImage());
        AppPreference.getInstance(context).setBoolean(PrefKey.SIGNED_IN, true);

        AppPreference.getInstance(this).setString(PrefKey.FIRST_NAME_BILL, loginModel.getFirstName());
        AppPreference.getInstance(this).setString(PrefKey.LAST_NAME_BILL, loginModel.getLastName());
        AppPreference.getInstance(this).setString(PrefKey.EMAIL_BILL, loginModel.getEmail());

        if (checkOutOrder) {
            Bundle bundle = new Bundle();
            bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
            bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) orderList);
            bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, String.valueOf(totalAmount));
            bundle.putBoolean(AppConstants.BUNDLE_BUY_NOW, buyNow);
            startActivity(new Intent(CreateAccountActivity.this, CheckoutAddressActivity.class).putExtras(bundle));
            finish();
        } else if (homeLogin) {
            finish();
        } else {
            startActivity(new Intent(CreateAccountActivity.this, HomeActivity.class));
            finish();
        }
    }

    private View.OnClickListener onViewItemClick() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.gp_login_btn:
                        invokeGPLogin();
                        break;
                    case R.id.txt_account_login:
                        accountLogin();
                        break;
                    case R.id.btn_create_account:
                        validateCustomer();
                        break;
                }
            }
        };
    }
}
