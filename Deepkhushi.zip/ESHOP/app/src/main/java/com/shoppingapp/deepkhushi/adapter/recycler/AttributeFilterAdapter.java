package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemFilterAttributeListLayoutBinding;
import com.shoppingapp.deepkhushi.listener.FilterItemClickCallbackListener;
import com.shoppingapp.deepkhushi.listener.FilterItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductAttributeModel;

import java.util.List;

/**
 * Created by Deepak Kumar on 06-Mar-19.
 */

public class AttributeFilterAdapter extends RecyclerView.Adapter<AttributeFilterAdapter.AttributeFilterViewHolder> {

    private Context context;
    private List<ProductAttributeModel> arrayList;

    private FilterItemClickCallbackListener callbackListener;

    public AttributeFilterAdapter(Context context) {
        this.context = context;
    }

    public AttributeFilterAdapter(Context context, List<ProductAttributeModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setFilterItemClickListener(FilterItemClickCallbackListener callbackListener) {
        this.callbackListener = callbackListener;
    }

    @NonNull
    @Override
    public AttributeFilterAdapter.AttributeFilterViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new AttributeFilterViewHolder((ItemFilterAttributeListLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_filter_attribute_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final AttributeFilterAdapter.AttributeFilterViewHolder holder, final int position) {
        holder.binding.attributeName.setText(arrayList.get(position).getName());

        holder.termsFilterAdapter = new AttributeTermsFilterAdapter(context, arrayList.get(position).getAttributeTerms());
        holder.binding.attributeTermsRecycler.setLayoutManager(new GridLayoutManager(context, 3));
        holder.binding.attributeTermsRecycler.setAdapter(holder.termsFilterAdapter);

        holder.termsFilterAdapter.setFilterItemClickListener(new FilterItemClickListener() {
            @Override
            public void onFilterItemClickGetPosition(String id, int clickposition) {

                for (ProductAttributeModel attributeModel : arrayList)
                    for (ProductAttributeModel termModel : attributeModel.getAttributeTerms())
                        termModel.setSelected(false);
                notifyDataSetChanged();

                ProductAttributeModel attributeModel = arrayList.get(position).getAttributeTerms().get(clickposition);
                attributeModel.setSelected(true);
                holder.termsFilterAdapter.notifyItemChanged(clickposition);

                if (callbackListener != null)
                    callbackListener.onFilterItemClickGetCallback(id, arrayList.get(holder.getLayoutPosition()).getSlug());
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class AttributeFilterViewHolder extends RecyclerView.ViewHolder {

        ItemFilterAttributeListLayoutBinding binding;
        AttributeTermsFilterAdapter termsFilterAdapter;

        AttributeFilterViewHolder(@NonNull ItemFilterAttributeListLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;
        }
    }
}
