package com.shoppingapp.deepkhushi.database.converters;

import androidx.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

/**
 * Created by Deepak Kumar on 12-Nov-19.
 */
public class IntegerArrayConverter {

    @TypeConverter
    public String fromOptionValuesList(List<Integer> optionValues) {
        if (optionValues == null) {
            return (null);
        }
        Gson gson = new Gson();
        Type type = new TypeToken<List<Integer>>() {
        }.getType();

        return gson.toJson(optionValues, type);
    }

    @TypeConverter
    public List<Integer> toOptionValuesList(String optionValuesString) {
        if (optionValuesString == null) {
            return (null);
        }
        Gson gson = new Gson();
        Type type = new TypeToken<List<Integer>>() {
        }.getType();

        return gson.fromJson(optionValuesString, type);
    }
}
