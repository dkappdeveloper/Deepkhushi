package com.shoppingapp.deepkhushi.adapter.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.databinding.ItemProductCartLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemViewClickListener;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Deepak Kumar on 16-May-19.
 */
public class ProductCartAdapter extends RecyclerView.Adapter<ProductCartAdapter.ProductCartViewHolder> {

    private Context context;
    private List<ProductCartModel> arrayList;

    private ItemViewClickListener itemClickListener;

    public ProductCartAdapter() {
    }

    public ProductCartAdapter(Context context, List<ProductCartModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    public void setItemClickListener(ItemViewClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ProductCartAdapter.ProductCartViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        return new ProductCartViewHolder((ItemProductCartLayoutBinding) DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_product_cart_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ProductCartAdapter.ProductCartViewHolder holder, int position) {
        String title = arrayList.get(position).getProductName();
        String productImage = arrayList.get(position).getProductImage();
        String productPrice = arrayList.get(position).getProductPrice();
        String totalPrice = arrayList.get(position).getTotalPrice();
        String quantity = arrayList.get(position).getProductQuantity();
        String currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);

        String attributes = arrayList.get(position).getProductAttribute();
        attributes = attributes.substring(1, attributes.length() - 1).replace("=", ":");

        if (productImage != null && !productImage.isEmpty()) {
            Picasso.get().load(productImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(holder.binding.productImage);
        }

        holder.binding.productTitle.setText(AppHelper.fromHtml(title));
        holder.binding.productQuantity.setText(quantity);
        holder.binding.productSalePrice.setText(currencySymbol + productPrice);
        holder.binding.productSubtotalPrice.setText(currencySymbol + totalPrice);

        if (!attributes.isEmpty()) {
            attributes = attributes.replace("=", ":");
            holder.binding.productAttributes.setText(attributes);
            holder.binding.productAttributes.setVisibility(View.VISIBLE);
        } else {
            holder.binding.productAttributes.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ProductCartViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ItemProductCartLayoutBinding binding;

        ProductCartViewHolder(@NonNull ItemProductCartLayoutBinding layoutBinding) {
            super(layoutBinding.getRoot());
            binding = layoutBinding;

            binding.removeProduct.setOnClickListener(this);
            binding.plusQuantity.setOnClickListener(this);
            binding.minusQuantity.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null)
                itemClickListener.onItemViewClickGetPosition(getLayoutPosition(), view);
        }
    }
}
