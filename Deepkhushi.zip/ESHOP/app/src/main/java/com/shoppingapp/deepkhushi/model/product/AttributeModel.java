package com.shoppingapp.deepkhushi.model.product;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class AttributeModel implements Parcelable {


    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("position")
    @Expose
    private Integer position;
    @SerializedName("visible")
    @Expose
    private Boolean visible;
    @SerializedName("variation")
    @Expose
    private Boolean variation;
    @SerializedName("options")
    @Expose
    private List<String> options = new ArrayList<>();


    /**
     * No args constructor for use in serialization
     */
    public AttributeModel() {
    }

    /**
     * @param position
     * @param id
     * @param visible
     * @param variation
     * @param name
     * @param options
     */
    public AttributeModel(Integer id, String name, Integer position, Boolean visible, Boolean variation, List<String> options) {
        super();
        this.id = id;
        this.name = name;
        this.position = position;
        this.visible = visible;
        this.variation = variation;
        this.options = options;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Boolean getVariation() {
        return variation;
    }

    public void setVariation(Boolean variation) {
        this.variation = variation;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public final static Creator<AttributeModel> CREATOR = new Creator<AttributeModel>() {


        @SuppressWarnings({
                "unchecked"
        })
        public AttributeModel createFromParcel(Parcel in) {
            return new AttributeModel(in);
        }

        public AttributeModel[] newArray(int size) {
            return (new AttributeModel[size]);
        }

    };

    protected AttributeModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.position = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.visible = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        this.variation = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        in.readList(this.options, (String.class.getClassLoader()));
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(name);
        dest.writeValue(position);
        dest.writeValue(visible);
        dest.writeValue(variation);
        dest.writeList(options);
    }

    public int describeContents() {
        return 0;
    }

}
