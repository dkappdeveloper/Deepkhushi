package com.shoppingapp.deepkhushi.listener;

import com.shoppingapp.deepkhushi.model.customer.LoginModel;

/**
 * Created by Deepak Kumar on 21-Jan-19.
 */

public interface LoginListener {
    void onLoginResponse(LoginModel loginModel);
}
