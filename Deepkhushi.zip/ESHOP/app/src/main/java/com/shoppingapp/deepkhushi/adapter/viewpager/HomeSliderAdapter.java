package com.shoppingapp.deepkhushi.adapter.viewpager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.viewpager.widget.PagerAdapter;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.databinding.ItemImageSliderBinding;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.product.ProductImageModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.squareup.picasso.Picasso;

import java.util.List;


/**
 * Created by Md Sahidul Islam on 12-Feb-19.
 */

public class HomeSliderAdapter extends PagerAdapter {

    private Context context;
    private List<ProductModel> modelList;
    private Boolean clickable = false;
    private ItemClickListener itemClickListener;

    public HomeSliderAdapter(Context context) {
        this.context = context;
    }

    public HomeSliderAdapter(Context context, List<ProductModel> modelList, Boolean clickable) {
        this.context = context;
        this.modelList = modelList;
        this.clickable = clickable;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        ItemImageSliderBinding binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.item_image_slider, container, false);

        List<ProductImageModel> imageModel = modelList.get(position).getProductImageModels();

        if (imageModel.size() > 0) {
            String productImage = imageModel.get(0).getSrc();
            Picasso.get().load(productImage)
                    .placeholder(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .error(context.getResources().getDrawable(R.drawable.image_placeholder))
                    .into(binding.sliderImage);
        }

        if (clickable)
            binding.parentView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (itemClickListener != null)
                        itemClickListener.onItemClickGetPosition(position);
                }
            });

        container.addView(binding.getRoot());
        return binding.getRoot();
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return modelList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    public void setSliderItemClickListerner(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
}
