
package com.shoppingapp.deepkhushi.model.shipping;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ShippingMethodModel implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("instance_id")
    @Expose
    private Integer instanceId;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("order")
    @Expose
    private Integer order;
    @SerializedName("enabled")
    @Expose
    private Boolean enabled;
    @SerializedName("method_id")
    @Expose
    private String methodId;
    @SerializedName("method_title")
    @Expose
    private String methodTitle;
    @SerializedName("method_description")
    @Expose
    private String methodDescription;
    @SerializedName("settings")
    @Expose
    private SettingsModel settings;
    public final static Creator<ShippingMethodModel> CREATOR = new Creator<ShippingMethodModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public ShippingMethodModel createFromParcel(Parcel in) {
            return new ShippingMethodModel(in);
        }

        public ShippingMethodModel[] newArray(int size) {
            return (new ShippingMethodModel[size]);
        }

    }
    ;

    protected ShippingMethodModel(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.instanceId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.title = ((String) in.readValue((String.class.getClassLoader())));
        this.order = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.enabled = ((Boolean) in.readValue((Boolean.class.getClassLoader())));
        this.methodId = ((String) in.readValue((String.class.getClassLoader())));
        this.methodTitle = ((String) in.readValue((String.class.getClassLoader())));
        this.methodDescription = ((String) in.readValue((String.class.getClassLoader())));
        this.settings = ((SettingsModel) in.readValue((SettingsModel.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public ShippingMethodModel() {
    }

    /**
     * 
     * @param settings
     * @param methodDescription
     * @param instanceId
     * @param methodTitle
     * @param methodId
     * @param id
     * @param title
     * @param enabled
     * @param order
     */
    public ShippingMethodModel(Integer id, Integer instanceId, String title, Integer order, Boolean enabled, String methodId, String methodTitle, String methodDescription, SettingsModel settings) {
        super();
        this.id = id;
        this.instanceId = instanceId;
        this.title = title;
        this.order = order;
        this.enabled = enabled;
        this.methodId = methodId;
        this.methodTitle = methodTitle;
        this.methodDescription = methodDescription;
        this.settings = settings;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(Integer instanceId) {
        this.instanceId = instanceId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getMethodId() {
        return methodId;
    }

    public void setMethodId(String methodId) {
        this.methodId = methodId;
    }

    public String getMethodTitle() {
        return methodTitle;
    }

    public void setMethodTitle(String methodTitle) {
        this.methodTitle = methodTitle;
    }

    public String getMethodDescription() {
        return methodDescription;
    }

    public void setMethodDescription(String methodDescription) {
        this.methodDescription = methodDescription;
    }

    public SettingsModel getSettings() {
        return settings;
    }

    public void setSettings(SettingsModel settings) {
        this.settings = settings;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(instanceId);
        dest.writeValue(title);
        dest.writeValue(order);
        dest.writeValue(enabled);
        dest.writeValue(methodId);
        dest.writeValue(methodTitle);
        dest.writeValue(methodDescription);
        dest.writeValue(settings);
    }

    public int describeContents() {
        return  0;
    }

}
