
package com.shoppingapp.deepkhushi.model.customer;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ErrorModel implements Parcelable
{
    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("message")
    @Expose
    private String message;
    public final static Creator<ErrorModel> CREATOR = new Creator<ErrorModel>() {


        @SuppressWarnings({
            "unchecked"
        })
        public ErrorModel createFromParcel(Parcel in) {
            return new ErrorModel(in);
        }

        public ErrorModel[] newArray(int size) {
            return (new ErrorModel[size]);
        }

    };

    protected ErrorModel(@NonNull Parcel in) {
        this.code = ((String) in.readValue((String.class.getClassLoader())));
        this.message = ((String) in.readValue((String.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public ErrorModel() {
    }

    /**
     * 
     * @param code
     * @param message
     */
    public ErrorModel(String code, String message) {
        super();
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(code);
        dest.writeValue(message);
    }

    public int describeContents() {
        return  0;
    }
}
