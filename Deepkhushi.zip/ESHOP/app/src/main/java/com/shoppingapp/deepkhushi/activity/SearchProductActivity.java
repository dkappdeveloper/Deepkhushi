package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.ProductListAdapter;
import com.shoppingapp.deepkhushi.adapter.recycler.SearchCategoryListAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.databinding.ActivitySearchProductLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.model.category.CategoryModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.shoppingapp.deepkhushi.model.product.ProductSearchModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.network.ApiRequests;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.android.material.appbar.AppBarLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 15-May-19.
 */
public class SearchProductActivity extends BaseActivity {

    ActivitySearchProductLayoutBinding binding;

    SearchCategoryListAdapter categoryListAdapter;
    ProductListAdapter productListAdapter;

    private List<ProductModel> productList;
    private List<CategoryModel> categoryList;
    private ArrayAdapter<String> listOrderAdapter;
    private List<String> listOrder;
    private ProductSearchModel searchModel;

    private GridLayoutManager gridLayoutManager;
    private LinearLayoutManager linearLayoutManager;
    private RecyclerView.LayoutManager mLayoutManager;

    private int pageNumber = AppConstants.PAGE_NUMBER;
    private Boolean listOrderSpinnerTouched = false;
    private Boolean isDataLoading = false;
    private Boolean canLoadMore = false;
    private Boolean viewLoadingFirstTime = true;
    private AppConstants.ListLayoutType currentLayoutType;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                AppHelper.hideKeyboard(SearchProductActivity.this);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (this.binding.drawerLayout.isDrawerOpen(GravityCompat.END)) {
            this.binding.drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            finish();
        }
    }

    private void initVars() {
        searchModel = new ProductSearchModel();
        categoryList = new ArrayList<>();
        productList = new ArrayList<>();
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_search_product_layout);

        setSupportActionBar(binding.searchToolbar.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AppHelper.showKeyboard(SearchProductActivity.this);
        initRecyclerView(AppConstants.ListLayoutType.GRID);
        initFilterSpinner();
        intFilterView(false);
        initRecyclerView();

        loadCategories();
    }

    private void initListener() {
        binding.searchToolbar.searchTerm.addTextChangedListener(textChangeListener());
        binding.searchToolbar.clearSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.searchToolbar.searchTerm.getText().clear();
                if (productList.size() > 0) {
                    searchModel.setSearchKey(null);
                }
            }
        });

        binding.okSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String minPrice = binding.searchMinPrice.getText().toString();
                String maxPrice = binding.searchMaxPrice.getText().toString();

                if (!minPrice.isEmpty() && !maxPrice.isEmpty()) {
                    searchModel.setMinPrice(minPrice);
                    searchModel.setMaxPrice(maxPrice);

                    if (!searchModel.getSearchKey().isEmpty())
                        loadProductData();
                }

                binding.drawerLayout.closeDrawer(GravityCompat.END);
            }
        });

        binding.primaryFilterbar.filterList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.drawerLayout.openDrawer(GravityCompat.END);
            }
        });


        binding.primaryFilterbar.toggleListLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleListLayout();
            }
        });

        binding.resetSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchModel.setCategoryId(null);
                searchModel.setMinPrice(null);
                searchModel.setMaxPrice(null);

                binding.searchMinPrice.setText("");
                binding.searchMaxPrice.setText("");

                for (CategoryModel categoryModel : categoryList) {
                    categoryModel.setSelected(false);
                }
                categoryListAdapter.notifyDataSetChanged();
            }
        });

        binding.primaryFilterbar.listOrderSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    listOrderSpinnerTouched = true;
                }
                return false;
            }
        });

        binding.primaryFilterbar.listOrderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (listOrderSpinnerTouched) {
                    setListOrderSpinnerSelection(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        categoryListAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                for (CategoryModel categoryModel : categoryList)
                    categoryModel.setSelected(false);
                categoryListAdapter.notifyDataSetChanged();

                CategoryModel categoryModel = categoryList.get(position);
                categoryModel.setSelected(true);
                categoryListAdapter.notifyItemChanged(position);

                searchModel.setCategoryId(String.valueOf(categoryModel.getId()));
                loadProductData();
            }
        });
    }

    private void initRecyclerView() {
        categoryListAdapter = new SearchCategoryListAdapter(this, categoryList);
        binding.categoryRecyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.categoryRecyclerView.setNestedScrollingEnabled(false);
        binding.categoryRecyclerView.setAdapter(categoryListAdapter);
    }

    private void initRecyclerView(AppConstants.ListLayoutType layoutManagerType) {
        productListAdapter = new ProductListAdapter(getApplicationContext(), productList, layoutManagerType);
        setRecyclerViewLayoutManager(binding.primaryRecycler, layoutManagerType);
        binding.primaryRecycler.setItemAnimator(new DefaultItemAnimator());
        binding.primaryRecycler.setNestedScrollingEnabled(false);
        binding.primaryRecycler.setAdapter(productListAdapter);
        binding.nestedScrollView.setOnScrollChangeListener(onNestedScrollChange());

        productListAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = productList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(SearchProductActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });
    }

    public void setRecyclerViewLayoutManager(RecyclerView mRecyclerView, AppConstants.ListLayoutType layoutManagerType) {
        int scrollPosition = 0;

        if (mRecyclerView.getLayoutManager() != null) {
            scrollPosition = ((LinearLayoutManager) mRecyclerView.getLayoutManager())
                    .findFirstCompletelyVisibleItemPosition();
        }

        switch (layoutManagerType) {
            case GRID:
                gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
                mLayoutManager = gridLayoutManager;
                currentLayoutType = AppConstants.ListLayoutType.GRID;
                break;
            case LINEAR:
                linearLayoutManager = new LinearLayoutManager(getApplicationContext());
                mLayoutManager = linearLayoutManager;
                currentLayoutType = AppConstants.ListLayoutType.LINEAR;
                break;
            default:
                linearLayoutManager = new LinearLayoutManager(getApplicationContext());
                mLayoutManager = linearLayoutManager;
                currentLayoutType = AppConstants.ListLayoutType.LINEAR;
        }

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.scrollToPosition(scrollPosition);
    }

    private void intFilterView(Boolean showFilterLayout) {
        AppBarLayout.LayoutParams params = (AppBarLayout.LayoutParams) binding.searchToolbar.toolbar.getLayoutParams();
        CoordinatorLayout.LayoutParams appBarLayoutParams = (CoordinatorLayout.LayoutParams) binding.appbarLayout.getLayoutParams();

        if (showFilterLayout) {
            params.setScrollFlags(AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL | AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS);
            appBarLayoutParams.setBehavior(new AppBarLayout.Behavior());
            binding.primaryFilterbar.filterListLayout.setVisibility(View.VISIBLE);
        } else {
            appBarLayoutParams.setBehavior(null);
            params.setScrollFlags(0);
            binding.primaryFilterbar.filterListLayout.setVisibility(View.GONE);
        }

        binding.appbarLayout.setLayoutParams(appBarLayoutParams);
    }

    private void initFilterSpinner() {
        listOrder = Arrays.asList(getResources().getStringArray(R.array.list_order_type));
        listOrderAdapter = spinnerAdapter(new ArrayList<String>(listOrder));
        binding.primaryFilterbar.listOrderSpinner.setPopupBackgroundResource(R.drawable.spinner_background);
        binding.primaryFilterbar.listOrderSpinner.setAdapter(listOrderAdapter);
    }

    private void loadCategories() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            HashMap<String, String> categoryListMap = ApiRequests.buildCategoryList(true, AppConstants.CATEGORY_PER_PAGE);
            ApiClient.getInstance().getApiInterface().getCategories(categoryListMap).enqueue(new Callback<List<CategoryModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<CategoryModel>> call, @NonNull Response<List<CategoryModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            categoryList.addAll(response.body());

                            if (categoryList != null && categoryList.size() > 0) {
                                categoryListAdapter.notifyDataSetChanged();
                            }
                        }
                    } else {

                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<CategoryModel>> call, @NonNull Throwable t) {
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadProductData() {
        productList.clear();
        toggleShimmerLayout(false);
        binding.primaryRecycler.setVisibility(View.GONE);

        if (!isDataLoading) {
            isDataLoading = true;
            pageNumber = AppConstants.PAGE_NUMBER;
            loadProducts(pageNumber);
        }
    }

    private void loadProducts(int pageNumber) {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            if (binding.emptyListLayout.getVisibility() == View.VISIBLE)
                binding.emptyListLayout.setVisibility(View.GONE);

            searchModel.setPage(pageNumber);
            searchModel.setPerPage(AppConstants.PER_PAGE);
            HashMap<String, String> featuredProduct = ApiRequests.buildProductList(searchModel);

            ApiClient.getInstance().getApiInterface().getProducts(featuredProduct).enqueue(new Callback<List<ProductModel>>() {
                @Override
                public void onResponse(@NonNull Call<List<ProductModel>> call, @NonNull Response<List<ProductModel>> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            if (response.body().size() > 0) {
                                canLoadMore = true;

                                productList.addAll(response.body());
                                productListAdapter.notifyDataSetChanged();
                                toggleShimmerLayout(true);
                                binding.primaryRecycler.setVisibility(View.VISIBLE);

                                if (viewLoadingFirstTime) {
                                    viewLoadingFirstTime = false;
                                    intFilterView(true);
                                }
                            } else {
                                if (productList.size() == 0) {
                                    binding.emptyListLayout.removeAllViews();
                                    binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.no_data)));
                                    toggleShimmerLayout(true);
                                    binding.emptyListLayout.setVisibility(View.VISIBLE);
                                }
                                canLoadMore = false;
                            }

                            isDataLoading = false;
                            binding.progressBar.setVisibility(View.GONE);
                        }
                    } else {
                        AppHelper.showShortToast(context, getString(R.string.failed_msg));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<ProductModel>> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(context, getString(R.string.failed_msg));
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void toggleShimmerLayout(Boolean hide) {
        if (currentLayoutType == AppConstants.ListLayoutType.LINEAR) {
            if (hide)
                binding.listShimmerLayout.shimmerLinearLayout.setVisibility(View.GONE);
            else
                binding.listShimmerLayout.shimmerLinearLayout.setVisibility(View.VISIBLE);
        } else {
            if (hide)
                binding.gridShimmerLayout.shimmerGridLayout.setVisibility(View.GONE);
            else
                binding.gridShimmerLayout.shimmerGridLayout.setVisibility(View.VISIBLE);
        }
    }

    private void toggleListLayout() {
        if (currentLayoutType == AppConstants.ListLayoutType.LINEAR) {
            binding.primaryFilterbar.toggleListLayout.setImageResource(R.drawable.ic_list_menu);
            setRecyclerViewLayoutManager(binding.primaryRecycler, AppConstants.ListLayoutType.GRID);
            initRecyclerView(AppConstants.ListLayoutType.GRID);

        } else {
            binding.primaryFilterbar.toggleListLayout.setImageResource(R.drawable.ic_grid_menu);
            setRecyclerViewLayoutManager(binding.primaryRecycler, AppConstants.ListLayoutType.LINEAR);
            initRecyclerView(AppConstants.ListLayoutType.LINEAR);
        }
    }

    private void setListOrderSpinnerSelection(int position) {

        switch (position) {
            case 0:
                searchModel.setOrder(AppConstants.KEY_ASC);
                searchModel.setOrderBy(AppConstants.KEY_DATE);
                break;
            case 1:
                searchModel.setOrder(AppConstants.KEY_ASC);
                searchModel.setOrderBy(AppConstants.KEY_TITLE);
                break;
            case 2:
                searchModel.setOrder(AppConstants.KEY_DESC);
                searchModel.setOrderBy(AppConstants.KEY_TITLE);
                break;
            case 3:
                searchModel.setOrder(AppConstants.KEY_ASC);
                searchModel.setOrderBy(AppConstants.KEY_PRICE);
                break;
            case 4:
                searchModel.setOrder(AppConstants.KEY_DESC);
                searchModel.setOrderBy(AppConstants.KEY_PRICE);
                break;
        }
        loadProductData();
    }

    public ArrayAdapter<String> spinnerAdapter(ArrayList<String> arrayList) {
        return new ArrayAdapter<String>(this, R.layout.spinner_item_layout, arrayList) {
            @Override
            public boolean isEnabled(int position) {
                return position != -1;
            }

            @Override
            public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(getResources().getColor(R.color.colorBlack));

                return view;
            }
        };
    }

    private TextWatcher textChangeListener() {
        return new TextWatcher() {
            Handler handler = new Handler();
            Runnable runnable;

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                handler.removeCallbacks(runnable);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                final String searchTerm = editable.toString().trim();

                if (!searchTerm.isEmpty())
                    binding.searchToolbar.clearSearch.setVisibility(View.VISIBLE);
                else binding.searchToolbar.clearSearch.setVisibility(View.GONE);

                runnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!searchTerm.isEmpty()) {
                            searchModel.setSearchKey(searchTerm);
                            loadProductData();
                            AppHelper.hideKeyboard(SearchProductActivity.this);
                        } else {
                            searchModel.setSearchKey(null);
                        }
                    }
                };
                handler.postDelayed(runnable, 1000);
            }
        };
    }

    private NestedScrollView.OnScrollChangeListener onNestedScrollChange() {
        return new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView scrollView, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY > 0) {
                    if (!scrollView.canScrollVertically(NestedScrollView.FOCUS_DOWN)) {
                        if (canLoadMore && !isDataLoading) {
                            isDataLoading = true;
                            binding.progressBar.setVisibility(View.VISIBLE);
                            pageNumber += 1;
                            loadProducts(pageNumber);
                        }
                    }
                }
            }
        };
    }
}

