package com.shoppingapp.deepkhushi.listener;

/**
 * Created by Deepak Kumar on 10/22/2016.
 */
public interface ItemClickListener {
    void onItemClickGetPosition(int position);
}
