package com.shoppingapp.deepkhushi.model.order;

/**
 * Created by Md Sahidul Islam on 03-May-19.
 */
public class ZoneModel {

    private String value;
    private String name;

    public ZoneModel() {
    }

    public ZoneModel(String value, String name) {
        this.value = value;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
