package com.shoppingapp.deepkhushi.helper;

import android.text.TextUtils;
import android.util.Patterns;
import android.webkit.URLUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

/**
 * Created by Deepak Kumar on 12/2/2017.
 */

public class ValidationHelper {

    public static String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        return sdf.format(new Date());
    }

    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    public static boolean isValidWebAddress(CharSequence target) {
        return URLUtil.isValidUrl(String.valueOf(target));
    }

    public static boolean isEmpty(CharSequence target) {
        return TextUtils.isEmpty(target) && target.length() == 0;
    }

    public static boolean isPassLengthOk(CharSequence target) {
        return !isEmpty(target) && target.length() > 5;
    }

    public static boolean isPhoneLengthOk(CharSequence target) {
        return target.length() == 11;
    }

    public static String getUsername(String target) {
        return target.substring(0, target.indexOf("@"));
    }

    public static boolean isNumeric(String strNum) {
        Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
        if (strNum == null) {
            return false;
        }
        return pattern.matcher(strNum).matches();
    }
}
