package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.ProductCartAdapter;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.ProductCartItemLoader;
import com.shoppingapp.deepkhushi.databinding.ActivityProductCartLayoutBinding;
import com.shoppingapp.deepkhushi.helper.ADHelper;
import com.shoppingapp.deepkhushi.helper.DataMapingHelper;
import com.shoppingapp.deepkhushi.listener.ItemViewClickListener;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Deepak Kumar on 15-May-19.
 */
public class ProductCartActivity extends BaseActivity {

    ActivityProductCartLayoutBinding binding;

    ProductCartAdapter productCartAdapter;
    private Double totalAmount = 0.0;
    private List<ProductCartModel> cartModelList;
    private List<HashMap> orderNotes;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVars();
        initView();
        initListener();
        initRecyclerView();
        loadCartProducts();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initVars() {
        orderNotes = new ArrayList<>();
        cartModelList = new ArrayList<>();
    }

    private void initView() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_product_cart_layout);

        setToolbar(binding.primaryToolbar.toolbar, binding.primaryToolbar.toolbarTitle, getString(R.string.toolbar_cart_list));
    }

    private void initListener() {
        binding.cartCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createOrderItems();

                Bundle bundle = new Bundle();
                bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
                bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) cartModelList);
                bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, String.valueOf(totalAmount));

                Boolean isLoggedIn = AppPreference.getInstance(getApplicationContext()).getBoolean(PrefKey.SIGNED_IN);
                if (isLoggedIn) {
                    startActivity(new Intent(ProductCartActivity.this, CheckoutAddressActivity.class).putExtras(bundle));
                } else {
                    bundle.putBoolean(AppConstants.BUNDLE_CHECKOUT_LOGIN, true);
                    startActivity(new Intent(ProductCartActivity.this, LoginActivity.class).putExtras(bundle));
                }
            }
        });
    }

    private void initRecyclerView() {
        productCartAdapter = new ProductCartAdapter(this, cartModelList);
        binding.productCartRecycler.setLayoutManager(new LinearLayoutManager(this));
        binding.productCartRecycler.setAdapter(productCartAdapter);

        productCartAdapter.setItemClickListener(new ItemViewClickListener() {
            @Override
            public void onItemViewClickGetPosition(int position, View view) {
                switch (view.getId()) {
                    case R.id.remove_product:
                        removeCartProduct(position);
                        break;
                    case R.id.plus_quantity:
                        addProductQuantity(position);
                        break;
                    case R.id.minus_quantity:
                        minusProductQuantity(position);
                        break;
                }
            }
        });
    }

    private void loadCartProducts() {
        ProductCartItemLoader productCartItemLoader = new ProductCartItemLoader(this);
        productCartItemLoader.execute(DaoHelper.FETCH_ALL);
        productCartItemLoader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {
                    List<ProductCartModel> modelList = (List<ProductCartModel>) object;

                    if (modelList.size() > 0) {
                        cartModelList.clear();
                        cartModelList.addAll(modelList);
                        productCartAdapter.notifyDataSetChanged();
                        binding.emptyListLayout.setVisibility(View.GONE);
                        binding.productCartRecycler.setVisibility(View.VISIBLE);

                        for (int i = 0; i < cartModelList.size(); i++) {
                            totalAmount += Double.parseDouble(cartModelList.get(i).getTotalPrice());
                        }
                        updateCheckOut();
                    } else {
                        binding.emptyListLayout.removeAllViews();
                        binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.cart_empty)));
                        binding.productCartRecycler.setVisibility(View.GONE);
                        binding.emptyListLayout.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }

    private void updateCheckOut() {
        if (cartModelList.size() > 0) {
            String currency = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);
            binding.cartTotalPrice.setText(String.valueOf("Total: " + currency + totalAmount));
            binding.cartCheckoutLayout.setVisibility(View.VISIBLE);
        } else {
            binding.emptyListLayout.removeAllViews();
            binding.emptyListLayout.addView(setEmptyLayout(getApplicationContext(), getString(R.string.cart_empty)));
            binding.cartCheckoutLayout.setVisibility(View.GONE);
            binding.productCartRecycler.setVisibility(View.GONE);
            binding.emptyListLayout.setVisibility(View.VISIBLE);
        }
    }

    private void createOrderItems() {
        for (ProductCartModel model : cartModelList) {
            String product = model.getProductName() + " ( " + model.getProductId() + " ) ";
            orderNotes.add(DataMapingHelper.getProductAttribute(product, model.getProductAttribute()));
        }
    }

    private void removeCartProduct(int position) {
        ProductCartModel model = cartModelList.get(position);

        totalAmount -= Double.parseDouble(model.getTotalPrice());

        ProductCartItemLoader productCartItemLoader = new ProductCartItemLoader(this);
        productCartItemLoader.execute(DaoHelper.DELETE, model.getProductId());
        cartModelList.remove(position);
        productCartAdapter.notifyItemRemoved(position);

        updateCheckOut();
    }

    private void addProductQuantity(int position) {
        ProductCartModel model = cartModelList.get(position);

        totalAmount += Double.parseDouble(model.getProductPrice());
        int quantity = Integer.parseInt(model.getProductQuantity()) + 1;
        double totalPrice = Double.parseDouble(model.getProductPrice()) * quantity;

        model.setProductQuantity(String.valueOf(quantity));
        model.setTotalPrice(String.valueOf(totalPrice));

        ProductCartItemLoader productCartItemLoader = new ProductCartItemLoader(this);
        productCartItemLoader.execute(DaoHelper.UPDATE, model);
        productCartAdapter.notifyItemChanged(position);
        updateCheckOut();
    }

    private void minusProductQuantity(int position) {
        ProductCartModel model = cartModelList.get(position);

        int quantity = Integer.parseInt(model.getProductQuantity()) - 1;
        if (quantity > 0) {
            totalAmount -= Double.parseDouble(model.getProductPrice());
            double totalPrice = Double.parseDouble(model.getProductPrice()) * quantity;

            model.setProductQuantity(String.valueOf(quantity));
            model.setTotalPrice(String.valueOf(totalPrice));

            ProductCartItemLoader productCartItemLoader = new ProductCartItemLoader(this);
            productCartItemLoader.execute(DaoHelper.UPDATE, model);
            productCartAdapter.notifyItemChanged(position);
            updateCheckOut();
        }
    }
}
