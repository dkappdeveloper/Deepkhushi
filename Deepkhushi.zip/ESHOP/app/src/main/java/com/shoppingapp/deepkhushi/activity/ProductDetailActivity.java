package com.shoppingapp.deepkhushi.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shoppingapp.deepkhushi.R;
import com.shoppingapp.deepkhushi.adapter.recycler.ProductAttributeAdapter;
import com.shoppingapp.deepkhushi.adapter.recycler.RelatedProductListAdapter;
import com.shoppingapp.deepkhushi.adapter.viewpager.ProductImageSliderAdpater;
import com.shoppingapp.deepkhushi.app.BaseActivity;
import com.shoppingapp.deepkhushi.cache.constant.AppConstants;
import com.shoppingapp.deepkhushi.cache.preference.AppPreference;
import com.shoppingapp.deepkhushi.cache.preference.PrefKey;
import com.shoppingapp.deepkhushi.database.helpers.DaoHelper;
import com.shoppingapp.deepkhushi.database.helpers.DbLoaderInterface;
import com.shoppingapp.deepkhushi.database.loader.FavouriteItemLoader;
import com.shoppingapp.deepkhushi.database.loader.ProductCartItemLoader;
import com.shoppingapp.deepkhushi.databinding.ActivityProductDeatilLayoutBinding;
import com.shoppingapp.deepkhushi.helper.AppHelper;
import com.shoppingapp.deepkhushi.helper.DataMapingHelper;
import com.shoppingapp.deepkhushi.listener.ItemClickListener;
import com.shoppingapp.deepkhushi.listener.ProductAttributeSelectedListener;
import com.shoppingapp.deepkhushi.model.dbEntity.FavouritesModel;
import com.shoppingapp.deepkhushi.model.dbEntity.ProductCartModel;
import com.shoppingapp.deepkhushi.model.product.AttributeModel;
import com.shoppingapp.deepkhushi.model.product.ProductCategoryModel;
import com.shoppingapp.deepkhushi.model.product.ProductImageModel;
import com.shoppingapp.deepkhushi.model.product.ProductModel;
import com.shoppingapp.deepkhushi.network.ApiClient;
import com.shoppingapp.deepkhushi.receiver.NetworkChangeReceiver;
import com.google.android.material.appbar.AppBarLayout;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Deepak Kumar on 08-Mar-19.
 */

public class ProductDetailActivity extends BaseActivity {

    ActivityProductDeatilLayoutBinding binding;

    ProductImageSliderAdpater sliderAdapter;
    RelatedProductListAdapter relatedProductAdapter;
    ProductAttributeAdapter attributeAdapter;

    private ProductModel productModel;
    private List<ProductModel> relatedProductList;
    private List<ProductImageModel> productImageList;
    private List<AttributeModel> attributeList;
    private List<ProductCartModel> orderList;
    private String pageTitle, currencySymbol = "";
    private Boolean isfromNotification = false;

    private String productPrice, totalAmount;
    private Boolean isFavourite = false;
    private int productId = 0;
    private int NUM_PAGES = 0, CURRENT_PAGE = 0;

    private HashMap<String, String> selectedAttributeTerms;
    private List<HashMap> orderNotes;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_product_deatil_layout);

        initVars();
        initRecyclerView();
        loadProductDetail();
        initSliderViewPager();
        initListener();
        checkFavourite();
    }

    @Override
    protected void onResume() {
        super.onResume();

        updateToolbarCartCount(binding.detailToolbar.cartCounter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (isfromNotification)
                    startActivity(new Intent(ProductDetailActivity.this, HomeActivity.class));
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (isfromNotification)
            startActivity(new Intent(ProductDetailActivity.this, HomeActivity.class));
        finish();
    }

    private void initVars() {
        productModel = new ProductModel();
        relatedProductList = new ArrayList<>();
        productImageList = new ArrayList<>();
        attributeList = new ArrayList<>();
        orderNotes = new ArrayList<>();
        orderList = new ArrayList<>();
        selectedAttributeTerms = new HashMap<>();

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            if (bundle.containsKey(AppConstants.BUNDLE_PAGE_TITLE))
                pageTitle = bundle.getString(AppConstants.BUNDLE_PAGE_TITLE);

            if (bundle.containsKey(AppConstants.BUNDLE_PRODUCT_ID))
                productId = bundle.getInt(AppConstants.BUNDLE_PRODUCT_ID);

            if (bundle.containsKey(AppConstants.BUNDLE_FROM_NOTIFICATION)) {
                isfromNotification = bundle.getBoolean(AppConstants.BUNDLE_FROM_NOTIFICATION, false);
            }
        }

        if (productId == 0) {
            finish();
            AppHelper.showShortToast(this, getString(R.string.failed_msg));
        }
    }

    private void initDetailView() {
        setSupportActionBar(binding.detailToolbar.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        binding.productDescription.getSettings();
        binding.productDescription.setBackgroundColor(Color.TRANSPARENT);
        binding.productDescription.setVerticalScrollBarEnabled(false);
        binding.productDescription.setHorizontalScrollBarEnabled(false);
        binding.productDescription.getSettings().setJavaScriptEnabled(true);
        binding.productDescription.getSettings().setAppCacheEnabled(true);
        binding.productDescription.getSettings().setLoadWithOverviewMode(true);

        if (productModel.getId() != null && productModel.getId() > 0) {
            binding.detailShimmerLayout.productDetailShimmerView.setVisibility(View.GONE);
            binding.productDetailLayout.setVisibility(View.VISIBLE);

            productImageList.addAll(productModel.getProductImageModels());
            showSlider();

            if (productModel.getRelatedIds().size() > 0) {
                loadRelatedProducts();
            } else {
                binding.shimmerRelatedProducts.shimmerRelatedProductsLayout.setVisibility(View.GONE);
                binding.relatedProductsLayout.setVisibility(View.GONE);
            }

            binding.productTitle.setText(productModel.getName());

            String type = productModel.getType();
            String basePrice = productModel.getPrice();
            String salePrice = productModel.getSalePrice();
            String regularPrice = productModel.getRegularPrice();
            currencySymbol = AppPreference.getInstance(context).getString(PrefKey.CURRENCY_SYMBOL);

            if (type.equals(AppConstants.PRODUCT_TYPE_VARIABLE)) {
                binding.productSalePrice.setText(currencySymbol + basePrice);
                binding.productQuantityPrice.setText(currencySymbol + basePrice);
                binding.productRegularPrice.setVisibility(View.GONE);
            } else if (type.equals(AppConstants.PRODUCT_TYPE_SIMPLE)) {
                if (salePrice != null && !salePrice.isEmpty()) {
                    int discountPercent = (int) Math.round((Float.parseFloat(salePrice) - Float.parseFloat(regularPrice)) / (Float.parseFloat(regularPrice) * .01));
                    binding.productSalePrice.setText(currencySymbol + salePrice);
                    binding.productRegularPrice.setText(currencySymbol + regularPrice);
                    binding.productDiscountPercent.setText("-" + Math.abs(discountPercent) + AppConstants.PERCENTAGE_SYMBOLE);
                    binding.productDiscount.setVisibility(View.VISIBLE);
                } else {
                    binding.productSalePrice.setText(currencySymbol + regularPrice);
                    binding.productQuantityPrice.setText(currencySymbol + regularPrice);
                    binding.productRegularPrice.setVisibility(View.GONE);
                }
            }

            if (!basePrice.isEmpty()) {
                binding.favShareLayout.setVisibility(View.VISIBLE);
                binding.buyCartLayout.setVisibility(View.VISIBLE);
                binding.quantityLayout.setVisibility(View.VISIBLE);
                binding.outStockLayout.setVisibility(View.GONE);
            } else {
                binding.productSalePrice.setVisibility(View.GONE);
                binding.productRegularPrice.setVisibility(View.GONE);
                binding.favShareLayout.setVisibility(View.GONE);
                binding.buyCartLayout.setVisibility(View.GONE);
                binding.quantityLayout.setVisibility(View.GONE);
                binding.outStockLayout.setVisibility(View.VISIBLE);
            }

            binding.productQuantityPrice.setText(currencySymbol + " " + Double.valueOf(productModel.getPrice() == null ? "0.0" : productModel.getPrice()));
            binding.productOrderCount.setText(productModel.getTotalSales() + getString(R.string.orders));
            binding.productReviewCount.setText(productModel.getRatingCount() + getString(R.string.reviews));
            binding.productRatingText.setText(productModel.getAverageRating());
            binding.productRating.setRating(Float.parseFloat(productModel.getAverageRating()));

            String shortDescription = Html.fromHtml(productModel.getShortDescription()).toString().trim();
            String fullDescription = Html.fromHtml(productModel.getDescription()).toString().trim();

            if (shortDescription.length() == 0)
                binding.shortDescriptionLayout.setVisibility(View.GONE);

            if (fullDescription.length() == 0)
                binding.descriptionLayout.setVisibility(View.GONE);

            binding.productShortDescription.setText(Html.fromHtml(productModel.getShortDescription()).toString().trim());

            String productDetail = productModel.getDescription();
            productDetail = new StringBuilder().append(AppConstants.CSS_PROPERTIES).append(productDetail).toString();

            /*Un-Comment below line to see product detail in RTL*/
            //productDetail = "<html><body dir=\"rtl\"; style=\"text-align:justify;\">" + productDetail + "</body></html>";

            binding.productDescription.loadDataWithBaseURL(null, productDetail, "text/html; charset=utf-8", "UTF-8", null);

            if (productModel.getAttributes().size() > 0) {
                attributeList.clear();
                attributeList.addAll(productModel.getAttributes());
                attributeAdapter.notifyDataSetChanged();
                binding.attributeLayout.setVisibility(View.VISIBLE);
            } else {
                binding.attributeLayout.setVisibility(View.GONE);
            }
        } else {
            binding.favShareLayout.setVisibility(View.GONE);
            binding.productDetailLayout.setVisibility(View.GONE);
            binding.detailShimmerLayout.productDetailShimmerView.setVisibility(View.VISIBLE);
            binding.favShareLayout.setVisibility(View.GONE);
            AppHelper.showShortToast(this, getString(R.string.failed_msg));
        }
    }

    private void initListener() {
        binding.appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = true;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffset == 0) {
                    binding.collapsingToolbar.setTitle(productModel.getName());
                    isShow = true;
                } else if (isShow) {
                    binding.collapsingToolbar.setTitle("");
                    isShow = false;
                }
            }
        });

        binding.minusQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int quantity = Integer.parseInt(binding.productQuantity.getText().toString().trim());

                if (quantity > 1) {
                    quantity -= 1;
                    double quantityPrice = Double.parseDouble(productModel.getPrice()) * quantity;

                    binding.productQuantity.setText(String.valueOf(quantity));
                    binding.productQuantityPrice.setText(currencySymbol + " " + quantityPrice);
                }
            }
        });

        binding.plusQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int quantity = Integer.parseInt(binding.productQuantity.getText().toString().trim());

                quantity += 1;
                double quantityPrice = Double.parseDouble(productModel.getPrice()) * quantity;

                binding.productQuantity.setText(String.valueOf(quantity));
                binding.productQuantityPrice.setText(currencySymbol + " " + quantityPrice);
            }
        });

        binding.productFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleFavourite();
            }
        });

        binding.productShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sharePost(productModel);
            }
        });

        binding.ratingReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, productId);
                startActivity(new Intent(ProductDetailActivity.this, ProductReviewActivity.class).putExtras(bundle));
            }
        });

        binding.buyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValidOrder()) {
                    createOrderItems();

                    Bundle bundle = new Bundle();
                    bundle.putSerializable(AppConstants.BUNDLE_ORDER_NOTES, (Serializable) orderNotes);
                    bundle.putSerializable(AppConstants.BUNDLE_CHECKOUT_PRODUCTS, (Serializable) orderList);
                    bundle.putString(AppConstants.BUNDLE_PAYMENT_TOTAL, totalAmount);
                    bundle.putBoolean(AppConstants.BUNDLE_BUY_NOW, true);

                    Boolean isLoggedIn = AppPreference.getInstance(getApplicationContext()).getBoolean(PrefKey.SIGNED_IN);
                    if (isLoggedIn) {
                        startActivity(new Intent(ProductDetailActivity.this, CheckoutAddressActivity.class).putExtras(bundle));
                    } else {
                        bundle.putBoolean(AppConstants.BUNDLE_CHECKOUT_LOGIN, true);
                        startActivity(new Intent(ProductDetailActivity.this, LoginActivity.class).putExtras(bundle));
                    }
                }
            }
        });

        binding.cartProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processCart();
            }
        });

        binding.detailToolbar.toolbarMenuCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ProductDetailActivity.this, ProductCartActivity.class));
            }
        });

        binding.detailToolbar.toolbarMenuSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ProductDetailActivity.this, SearchProductActivity.class));
            }
        });
    }

    private void initRecyclerView() {
        attributeAdapter = new ProductAttributeAdapter(this, attributeList);
        binding.productAttributesRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        binding.productAttributesRecycler.setAdapter(attributeAdapter);
        binding.productAttributesRecycler.setNestedScrollingEnabled(false);

        attributeAdapter.setItemSelectedListener(new ProductAttributeSelectedListener() {
            @Override
            public void onProductAttributeSelected(int position, String term) {
                String attribute = productModel.getAttributes().get(position).getName();
                selectedAttributeTerms.remove(attribute);    //removes a key if exists
                selectedAttributeTerms.put(attribute, term);
            }
        });

        relatedProductAdapter = new RelatedProductListAdapter(this, relatedProductList);
        binding.relatedProducts.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        binding.relatedProducts.setHasFixedSize(true);

        DividerItemDecoration verticalDivider = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        verticalDivider.setDrawable(ContextCompat.getDrawable(getBaseContext(), R.drawable.line_divider));
        binding.relatedProducts.addItemDecoration(verticalDivider);

        DividerItemDecoration horizontalDivider = new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL);
        horizontalDivider.setDrawable(ContextCompat.getDrawable(getBaseContext(), R.drawable.line_divider));
        binding.relatedProducts.addItemDecoration(horizontalDivider);

        binding.relatedProducts.setNestedScrollingEnabled(false);
        binding.relatedProducts.setAdapter(relatedProductAdapter);

        relatedProductAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickGetPosition(int position) {
                ProductModel model = relatedProductList.get(position);

                Bundle bundle = new Bundle();
                bundle.putString(AppConstants.BUNDLE_PAGE_TITLE, model.getName());
                bundle.putInt(AppConstants.BUNDLE_PRODUCT_ID, model.getId());
                startActivity(new Intent(ProductDetailActivity.this, ProductDetailActivity.class).putExtras(bundle));
            }
        });
    }

    private void initSliderViewPager() {
        sliderAdapter = new ProductImageSliderAdpater(this, productImageList);
        binding.productImageSlider.setAdapter(sliderAdapter);
    }

    private void showSlider() {
        NUM_PAGES = productImageList.size();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(5000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    CURRENT_PAGE = binding.productImageSlider.getCurrentItem();
                    if (CURRENT_PAGE == (NUM_PAGES - 1)) {
                        CURRENT_PAGE = 0;
                    } else {
                        CURRENT_PAGE++;
                    }

                    (ProductDetailActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            binding.productImageSlider.setCurrentItem(CURRENT_PAGE, true);
                        }
                    });
                }
            }
        }).start();

        sliderAdapter.notifyDataSetChanged();
        binding.sliderIndicator.setViewPager(binding.productImageSlider);
    }

    private void loadProductDetail() {
        if (NetworkChangeReceiver.isNetworkConnected()) {
            ApiClient.getInstance().getApiInterface().getProductDetail(productId).enqueue(new Callback<ProductModel>() {
                @Override
                public void onResponse(@NonNull Call<ProductModel> call, @NonNull Response<ProductModel> response) {
                    if (response.isSuccessful()) {
                        productModel = response.body();
                        initDetailView();
                    } else {
                        if (isfromNotification) {
                            startActivity(new Intent(ProductDetailActivity.this, SplashActivity.class));
                        } else {
                            AppHelper.showShortToast(ProductDetailActivity.this, getString(R.string.failed_msg));
                            finish();
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<ProductModel> call, @NonNull Throwable t) {
                    AppHelper.showShortToast(ProductDetailActivity.this, getString(R.string.failed_msg));
                    finish();
                }
            });
        }
        AppHelper.noInternetWarning(context, binding.getRoot());
    }

    private void loadRelatedProducts() {
        for (int i = 0; i < productModel.getRelatedIds().size(); i++) {
            ApiClient.getInstance().getApiInterface().getProductDetail(productModel.getRelatedIds().get(i)).enqueue(new Callback<ProductModel>() {
                @Override
                public void onResponse(@NonNull Call<ProductModel> call, @NonNull Response<ProductModel> response) {
                    if (response.isSuccessful()) {
                        relatedProductList.add(response.body());

                        if (relatedProductList.size() > 0) {
                            relatedProductAdapter.notifyDataSetChanged();
                            binding.shimmerRelatedProducts.shimmerRelatedProductsLayout.setVisibility(View.GONE);
                            binding.relatedProductsLayout.setVisibility(View.VISIBLE);
                        } else {
                            binding.relatedProductsLayout.setVisibility(View.GONE);
                            binding.shimmerRelatedProducts.shimmerRelatedProductsLayout.setVisibility(View.VISIBLE);
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<ProductModel> call, @NonNull Throwable t) {

                }
            });
        }
    }

    private void createOrderItems() {
        String quantity = binding.productQuantity.getText().toString();
        productPrice = productModel.getSalePrice().isEmpty() ? productModel.getPrice() : productModel.getSalePrice();
        totalAmount = String.valueOf(Double.parseDouble(productPrice) * Integer.parseInt(quantity));
        String productImage = productModel.getProductImageModels().size() > 0 ? productModel.getProductImageModels().get(0).getSrc() : "";
        Boolean isSale = productModel.getOnSale();

        List<Integer> categoryIds = new ArrayList<>();
        for (ProductCategoryModel model : productModel.getCategories()) {
            categoryIds.add(model.getId());
        }

        ProductCartModel cartModel = new ProductCartModel();
        cartModel.setProductId(productId);
        cartModel.setCategoryIds(categoryIds);
        cartModel.setProductName(productModel.getName());
        cartModel.setProductPrice(productPrice);
        cartModel.setTotalPrice(totalAmount);
        cartModel.setProductQuantity(quantity);
        cartModel.setProductAttribute(selectedAttributeTerms.toString());
        cartModel.setProductImage(productImage);
        cartModel.setSale(isSale);

        orderList.clear();
        orderList.add(cartModel);

        String product = productModel.getName() + " ( " + productModel.getId() + " ) ";
        orderNotes.add(DataMapingHelper.getProductAttribute(product, selectedAttributeTerms.toString()));
    }

    private void checkFavourite() {
        FavouriteItemLoader favouriteItemLoader = new FavouriteItemLoader(this);
        favouriteItemLoader.execute(DaoHelper.FETCH, productId);
        favouriteItemLoader.setDbLoaderInterface(new DbLoaderInterface() {
            @Override
            public void onFinished(Object object) {
                if (object != null) {
                    isFavourite = true;
                    binding.productFavourite.setImageResource(R.drawable.ic_fav_marked_128);
                } else {
                    isFavourite = false;
                    binding.productFavourite.setImageResource(R.drawable.ic_fav_unmarked_128);
                }
            }
        });
    }

    private void toggleFavourite() {
        FavouriteItemLoader favouriteItemLoader = new FavouriteItemLoader(this);
        if (isFavourite) {
            favouriteItemLoader.execute(DaoHelper.DELETE, productId);
        } else {
            String productName = productModel.getName();
            String productImage = productModel.getProductImageModels().get(0).getSrc();

            String salePrice = productModel.getSalePrice();
            String regularPrice = productModel.getRegularPrice();

            FavouritesModel model = new FavouritesModel(productId, productName, salePrice, regularPrice, productImage);
            favouriteItemLoader.execute(DaoHelper.INSERT, model);
        }

        checkFavourite();
    }

    private void processCart() {
        if (isValidOrder()) {
            ProductCartItemLoader cartItemLoader = new ProductCartItemLoader(this);
            cartItemLoader.execute(DaoHelper.FETCH, productId);
            cartItemLoader.setDbLoaderInterface(new DbLoaderInterface() {
                @Override
                public void onFinished(Object object) {
                    if (object != null) {
                        AppHelper.showLongToast(getApplicationContext(), getString(R.string.product_already_in_cart));
                    } else {
                        saveToCart();
                    }
                }
            });
        }
    }

    private void saveToCart() {
        ProductCartItemLoader cartItemLoader = new ProductCartItemLoader(this);

        List<Integer> categoryIds = new ArrayList<>();
        for (ProductCategoryModel model : productModel.getCategories()) {
            categoryIds.add(model.getId());
        }

        String productName = productModel.getName();
        String productImage = productModel.getProductImageModels().get(0).getSrc();

        String salePrice = productModel.getSalePrice();
        String regularPrice = productModel.getPrice();
        String quantity = binding.productQuantity.getText().toString().trim();
        double price = salePrice.isEmpty() ? Double.parseDouble(regularPrice) : Double.parseDouble(salePrice);
        double totalPrice = price * Integer.parseInt(quantity);
        Boolean isSale = productModel.getOnSale();

        ProductCartModel model = new ProductCartModel(productId, categoryIds, productName, String.valueOf(price), String.valueOf(totalPrice), quantity, selectedAttributeTerms.toString(), productImage, isSale);
        cartItemLoader.execute(DaoHelper.INSERT, model);

        updateToolbarCartCount(binding.detailToolbar.cartCounter);
        AppHelper.showLongToast(getApplicationContext(), getString(R.string.product_added_in_cart));
    }

    private Boolean isValidOrder() {
        if (attributeList.isEmpty()) {
            return true;
        } else if (selectedAttributeTerms.size() > 0) {
            return true;
        } else {
            AppHelper.showLongToast(this, getString(R.string.select_product_option));
            return false;
        }
    }
}

